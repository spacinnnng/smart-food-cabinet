# 测试文档

本目录包含智能食品柜系统的各种测试文件。

## 测试文件结构

```
test_documents/
├── websocket测试文件/          # WebSocket通信测试
│   ├── client.py              # 客户端测试程序
│   ├── server.py              # 服务器测试程序
│   ├── README.md              # 使用说明
│   └── requirements.txt       # 依赖包
├── web网站测试文件/            # Web界面测试
│   ├── test_web_only.py       # 纯Web服务器测试
│   ├── test_web_server.py     # Web服务器测试
│   └── README.md              # 使用说明
├── 数据库测试文件/             # 数据库模块测试
│   ├── test_database.py       # 数据库管理器测试
│   └── README.md              # 使用说明
├── RFID测试文件/              # RFID模块测试
│   ├── test_rfid.py           # RFID管理器测试
│   └── README.md              # 使用说明
├── 信息处理测试文件/           # 信息处理模块测试
│   ├── test_info_processor.py # 信息处理器测试
│   └── README.md              # 使用说明
├── 硬件控制测试文件/           # 硬件控制模块测试
│   ├── test_hardware.py       # 硬件管理器测试
│   └── README.md              # 使用说明
├── run_all_tests.py           # 运行所有单元测试
└── README.md                  # 本文件
```

## 测试类型说明

### 1. WebSocket通信测试
- **用途**: 测试树莓派与客户端之间的WebSocket通信
- **环境**: 需要树莓派和客户端同时运行
- **功能**: 连接测试、消息传输、广播功能

### 2. Web界面测试
- **用途**: 测试Web界面的基本功能
- **环境**: 可在Mac或树莓派上运行
- **功能**: HTTP服务器、静态文件服务、页面访问

### 3. 数据库模块测试
- **用途**: 测试数据库管理器的基本功能
- **环境**: 可在任何支持Python的环境运行
- **功能**: 数据库创建、CRUD操作、数据验证

### 4. RFID模块测试
- **用途**: 测试RFID管理器的基本功能
- **环境**: 使用模拟RFID，可在任何环境运行
- **功能**: 连接管理、标签读取、工作流程

### 5. 信息处理测试
- **用途**: 测试OCR识别和字段映射功能
- **环境**: 可在任何环境运行
- **功能**: 字段映射、数据转换、结果验证

### 6. 硬件控制测试
- **用途**: 测试硬件控制器的基本功能
- **环境**: 使用模拟硬件，可在任何环境运行
- **功能**: LED控制、蜂鸣器、传感器读取

## 运行测试

### 运行所有单元测试

```bash
cd test_documents/
python run_all_tests.py
```

### 运行单个模块测试

```bash
# 数据库测试
cd 数据库测试文件/
python test_database.py

# RFID测试
cd ../RFID测试文件/
python test_rfid.py

# 信息处理测试
cd ../信息处理测试文件/
python test_info_processor.py

# 硬件控制测试
cd ../硬件控制测试文件/
python test_hardware.py
```

### 运行WebSocket测试

```bash
# 在树莓派上启动服务器
cd websocket测试文件/
python server.py

# 在客户端运行测试
python client.py
```

### 运行Web界面测试

```bash
cd web网站测试文件/
python test_web_only.py
```

## 测试环境要求

### 通用要求
- Python 3.8+
- 项目依赖包

### 特定要求
- **WebSocket测试**: 需要网络连接
- **数据库测试**: 需要SQLite支持
- **RFID测试**: 使用模拟模式，无需实际硬件
- **硬件测试**: 使用模拟模式，无需实际硬件

## 测试结果说明

### 单元测试结果
- ✅ 通过
- ❌ 失败
- ⚠️ 错误

### 集成测试结果
- 连接状态
- 消息传输状态
- 功能验证结果

## 故障排除

### 常见问题

1. **导入错误**
   - 确保项目根目录在Python路径中
   - 检查依赖包是否安装

2. **测试失败**
   - 查看详细错误信息
   - 检查测试数据是否正确

3. **连接问题**
   - 检查网络连接
   - 验证IP地址和端口

### 调试技巧

1. **启用详细输出**
   ```bash
   python -m unittest -v test_module.py
   ```

2. **运行单个测试**
   ```bash
   python -m unittest test_module.TestClass.test_method
   ```

3. **查看测试覆盖率**
   ```bash
   pip install coverage
   coverage run -m unittest discover
   coverage report
   ```

## 贡献测试

### 添加新测试

1. 在对应模块目录下创建测试文件
2. 遵循命名规范：`test_*.py`
3. 继承`unittest.TestCase`
4. 添加测试用例和文档

### 测试规范

1. **命名规范**
   - 测试文件：`test_*.py`
   - 测试类：`Test*`
   - 测试方法：`test_*`

2. **测试结构**
   - `setUp()`: 测试前准备
   - `tearDown()`: 测试后清理
   - 测试方法：具体测试逻辑

3. **断言使用**
   - 使用`unittest`提供的断言方法
   - 提供清晰的错误信息

