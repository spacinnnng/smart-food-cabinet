#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
测试网页服务器
用于验证HTTP服务器和WebSocket服务器是否正常工作
"""

import asyncio
import sys
import os
from pathlib import Path

# 添加项目根目录到Python路径，以便导入其他模块
# 从test_documents/web网站测试文件/ 回到项目根目录
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from modules.websocket.websocket import start_websocket_and_web_server

async def test_servers():
    """测试服务器启动"""
    print("正在启动WebSocket和HTTP服务器...")
    print("WebSocket服务器端口: 5001")
    print("HTTP服务器端口: 8080")
    print("网页访问地址: http://localhost:8080")
    print("按 Ctrl+C 停止服务器")
    
    try:
        await start_websocket_and_web_server()
    except KeyboardInterrupt:
        print("\n服务器已停止")

if __name__ == "__main__":
    asyncio.run(test_servers())
