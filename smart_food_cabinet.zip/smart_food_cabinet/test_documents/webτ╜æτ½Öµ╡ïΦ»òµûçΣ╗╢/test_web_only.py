#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
测试网页服务器（仅HTTP部分）
用于在非树莓派环境（如Mac）上测试网页功能
"""

import asyncio
import aiohttp
from aiohttp import web
import logging
import sys
import os
from pathlib import Path

# 添加项目根目录到Python路径，以便导入其他模块
# 从test_documents/web网站测试文件/ 回到项目根目录
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# 配置
HOST = '0.0.0.0'
HTTP_PORT = 8080
WEB_DIR = Path(__file__).parent / "http"

class SimpleWebServer:
    """简单的HTTP服务器，用于提供网页文件"""
    
    def __init__(self):
        self.app = web.Application()
        self.setup_routes()
    
    def setup_routes(self):
        """设置路由"""
        # 静态文件服务
        self.app.router.add_static('/static/', path=WEB_DIR, name='static')
        
        # 主页路由
        self.app.router.add_get('/', self.index_handler)
        
        # 健康检查
        self.app.router.add_get('/health', self.health_handler)
        
        # API路由
        self.app.router.add_get('/api/status', self.api_status_handler)
    
    async def index_handler(self, request):
        """处理主页请求"""
        index_file = WEB_DIR / "index.html"
        if index_file.exists():
            return web.FileResponse(index_file)
        else:
            return web.Response(text="网页文件未找到", status=404)
    
    async def health_handler(self, request):
        """健康检查"""
        return web.json_response({
            "status": "ok", 
            "service": "smart-food-cabinet-web",
            "message": "网页服务器运行正常"
        })
    
    async def api_status_handler(self, request):
        """API状态处理"""
        return web.json_response({
            "websocket_connected": False,
            "message": "这是模拟模式，WebSocket功能不可用"
        })
    
    async def start(self):
        """启动HTTP服务器"""
        runner = web.AppRunner(self.app)
        await runner.setup()
        site = web.TCPSite(runner, HOST, HTTP_PORT)
        await site.start()
        logger.info(f"HTTP服务器已启动，监听端口 {HTTP_PORT}")
        logger.info(f"网页访问地址: http://localhost:{HTTP_PORT}")
        logger.info(f"网页访问地址: http://{HOST}:{HTTP_PORT}")
        logger.info("按 Ctrl+C 停止服务器")
        return runner

async def test_web_server():
    """测试网页服务器"""
    print("正在启动网页服务器...")
    print("注意：这是模拟模式，WebSocket功能不可用")
    print("但可以测试所有网页界面功能")
    
    web_server = SimpleWebServer()
    runner = await web_server.start()
    
    try:
        # 保持服务器运行
        await asyncio.Future()  # 创建一个永远不会完成的Future
    except KeyboardInterrupt:
        print("\n正在停止服务器...")
    finally:
        await runner.cleanup()
        print("服务器已停止")

if __name__ == "__main__":
    asyncio.run(test_web_server())
