# RFID模块测试

这是RFID管理器的单元测试，用于测试RFID管理器的基本功能。

## 功能测试

- ✅ RFID连接管理
- ✅ 自动读卡模式初始化
- ✅ 标签读取功能
- ✅ 完整工作流程测试

## 文件说明

- `test_rfid.py` - RFID管理器测试程序

## 安装依赖

```bash
# 激活虚拟环境
source sfc/bin/activate  # 树莓派
# 或
conda activate ocr_env   # Mac

# 安装依赖
pip install -r ../../requirements.txt
```

## 使用方法

### 运行测试

```bash
cd test_documents/RFID测试文件/
python test_rfid.py
```

### 测试输出示例

```
....
----------------------------------------------------------------------
Ran 4 tests in 0.045s

OK
```

## 测试用例说明

1. **test_rfid_connection** - 测试RFID连接和断开
2. **test_auto_read_mode** - 测试自动读卡模式初始化
3. **test_tag_reading** - 测试标签读取功能
4. **test_rfid_workflow** - 测试RFID完整工作流程

## 注意事项

- 测试使用模拟RFID管理器，不需要实际硬件
- 在非树莓派环境下可以正常运行
- 模拟了真实的RFID操作流程
