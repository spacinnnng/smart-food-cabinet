#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
RFID模块测试
测试RFID管理器的基本功能（模拟模式）
"""

import unittest
import os
import sys
import time

# 添加项目根目录到Python路径
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

# 模拟RFID模块（在非树莓派环境下）
class MockRFIDManager:
    """模拟RFID管理器"""
    
    def __init__(self):
        self.is_connected = False
        self.is_auto_mode = False
        self.is_reading = False
    
    def connect(self):
        """模拟连接"""
        self.is_connected = True
        return True
    
    def disconnect(self):
        """模拟断开连接"""
        self.is_connected = False
    
    def init_auto_read_mode(self):
        """模拟初始化自动读卡模式"""
        self.is_auto_mode = True
        return True
    
    def start_reading(self, callback):
        """模拟开始读取"""
        self.is_reading = True
        # 模拟读取到标签
        if callback:
            callback("12345678")
        return True
    
    def stop_reading(self):
        """模拟停止读取"""
        self.is_reading = False


class TestRFIDManager(unittest.TestCase):
    """RFID管理器测试类"""
    
    def setUp(self):
        """测试前准备"""
        self.rfid_manager = MockRFIDManager()
    
    def test_rfid_connection(self):
        """测试RFID连接"""
        # 测试连接
        result = self.rfid_manager.connect()
        self.assertTrue(result)
        self.assertTrue(self.rfid_manager.is_connected)
        
        # 测试断开连接
        self.rfid_manager.disconnect()
        self.assertFalse(self.rfid_manager.is_connected)
    
    def test_auto_read_mode(self):
        """测试自动读卡模式"""
        # 先连接
        self.rfid_manager.connect()
        
        # 初始化自动读卡模式
        result = self.rfid_manager.init_auto_read_mode()
        self.assertTrue(result)
        self.assertTrue(self.rfid_manager.is_auto_mode)
    
    def test_tag_reading(self):
        """测试标签读取"""
        # 先连接并初始化
        self.rfid_manager.connect()
        self.rfid_manager.init_auto_read_mode()
        
        # 测试读取
        received_tag = None
        def tag_callback(tag_id):
            nonlocal received_tag
            received_tag = tag_id
        
        result = self.rfid_manager.start_reading(tag_callback)
        self.assertTrue(result)
        self.assertTrue(self.rfid_manager.is_reading)
        self.assertEqual(received_tag, "12345678")
        
        # 测试停止读取
        self.rfid_manager.stop_reading()
        self.assertFalse(self.rfid_manager.is_reading)
    
    def test_rfid_workflow(self):
        """测试RFID完整工作流程"""
        # 1. 连接
        self.assertTrue(self.rfid_manager.connect())
        
        # 2. 初始化自动读卡模式
        self.assertTrue(self.rfid_manager.init_auto_read_mode())
        
        # 3. 开始读取
        tags_received = []
        def tag_callback(tag_id):
            tags_received.append(tag_id)
        
        self.assertTrue(self.rfid_manager.start_reading(tag_callback))
        
        # 4. 验证读取状态
        self.assertTrue(self.rfid_manager.is_reading)
        self.assertEqual(len(tags_received), 1)
        self.assertEqual(tags_received[0], "12345678")
        
        # 5. 停止读取
        self.rfid_manager.stop_reading()
        self.assertFalse(self.rfid_manager.is_reading)
        
        # 6. 断开连接
        self.rfid_manager.disconnect()
        self.assertFalse(self.rfid_manager.is_connected)


if __name__ == '__main__':
    unittest.main()
