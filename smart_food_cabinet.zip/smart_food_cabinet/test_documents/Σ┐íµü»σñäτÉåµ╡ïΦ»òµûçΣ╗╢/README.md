# 信息处理模块测试

这是信息处理模块的单元测试，用于测试OCR识别、字段映射等基本功能。

## 功能测试

- ✅ 时间单位模糊匹配
- ✅ OCR到数据库字段映射
- ✅ 过敏原信息处理
- ✅ 空数据映射处理
- ✅ 无效数据处理
- ✅ OCR结果验证
- ✅ 字段提取功能

## 文件说明

- `test_info_processor.py` - 信息处理模块测试程序

## 安装依赖

```bash
# 激活虚拟环境
source sfc/bin/activate  # 树莓派
# 或
conda activate ocr_env   # Mac

# 安装依赖
pip install -r ../../requirements.txt
```

## 使用方法

### 运行测试

```bash
cd test_documents/信息处理测试文件/
python test_info_processor.py
```

### 测试输出示例

```
.......
----------------------------------------------------------------------
Ran 7 tests in 0.089s

OK
```

## 测试用例说明

### 字段映射器测试 (TestFieldMapper)

1. **test_fuzzy_normalize_time_unit** - 测试时间单位模糊匹配
2. **test_map_ocr_to_db_basic** - 测试基本OCR到数据库字段映射
3. **test_map_ocr_to_db_with_allergens** - 测试包含过敏原的OCR映射
4. **test_map_ocr_to_db_empty** - 测试空OCR结果映射
5. **test_map_ocr_to_db_invalid_data** - 测试无效数据映射

### OCR处理器测试 (TestOCRProcessor)

6. **test_ocr_result_validation** - 测试OCR结果验证
7. **test_ocr_field_extraction** - 测试OCR字段提取

## 测试数据说明

测试使用模拟的OCR结果数据，包含：
- 食品名称
- 净含量
- 生产日期
- 保质期
- 配料表
- 过敏原信息

## 注意事项

- 测试不需要实际的OCR服务
- 使用模拟数据进行功能验证
- 测试覆盖了各种边界情况
