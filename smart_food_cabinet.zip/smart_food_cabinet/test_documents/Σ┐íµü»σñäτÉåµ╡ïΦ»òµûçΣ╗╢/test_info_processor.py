#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
信息处理模块测试
测试OCR识别、字段映射等基本功能
"""

import unittest
import os
import sys
import json

# 添加项目根目录到Python路径
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

from modules.info_processor.field_mapper import map_ocr_to_db, fuzzy_normalize_time_unit


class TestFieldMapper(unittest.TestCase):
    """字段映射器测试类"""
    
    def test_fuzzy_normalize_time_unit(self):
        """测试时间单位模糊匹配"""
        # 测试各种时间单位格式
        test_cases = [
            ("2年", 2, "年"),
            ("6个月", 6, "个月"),
            ("30天", 30, "天"),
            ("12个月", 12, "个月"),
            ("1年6个月", 18, "个月"),
            ("2年3个月", 27, "个月"),
        ]
        
        for input_str, expected_value, expected_unit in test_cases:
            result = fuzzy_normalize_time_unit(input_str)
            if result:
                value, unit = result
                self.assertEqual(value, expected_value)
                self.assertEqual(unit, expected_unit)
    
    def test_map_ocr_to_db_basic(self):
        """测试基本OCR到数据库字段映射"""
        # 模拟OCR结果
        ocr_result = {
            'StructuralList': [
                {
                    'Groups': [
                        {
                            'Lines': [
                                {
                                    'Key': {'ConfigName': '食品名称', 'AutoName': '产品名称'},
                                    'Value': {'AutoContent': '测试饼干'}
                                },
                                {
                                    'Key': {'ConfigName': '净含量', 'AutoName': '净重'},
                                    'Value': {'AutoContent': '500g'}
                                },
                                {
                                    'Key': {'ConfigName': '生产日期', 'AutoName': '生产日期'},
                                    'Value': {'AutoContent': '2024-01-01'}
                                },
                                {
                                    'Key': {'ConfigName': '保质期', 'AutoName': '保质期'},
                                    'Value': {'AutoContent': '12个月'}
                                }
                            ]
                        }
                    ]
                }
            ]
        }
        
        # 映射到数据库字段
        result = map_ocr_to_db(ocr_result)
        
        # 验证映射结果
        self.assertIsInstance(result, dict)
        self.assertEqual(result.get('name'), '测试饼干')
        self.assertEqual(result.get('net_content'), '500g')
        self.assertEqual(result.get('production_date'), '2024-01-01')
        self.assertEqual(result.get('shelf_life'), '12个月')
    
    def test_map_ocr_to_db_with_allergens(self):
        """测试包含过敏原的OCR映射"""
        # 模拟包含过敏原信息的OCR结果
        ocr_result = {
            'StructuralList': [
                {
                    'Groups': [
                        {
                            'Lines': [
                                {
                                    'Key': {'ConfigName': '食品名称', 'AutoName': '产品名称'},
                                    'Value': {'AutoContent': '牛奶饼干'}
                                },
                                {
                                    'Key': {'ConfigName': '配料表', 'AutoName': '配料'},
                                    'Value': {'AutoContent': '小麦粉、牛奶、鸡蛋、坚果'}
                                }
                            ]
                        }
                    ]
                }
            ]
        }
        
        # 映射到数据库字段
        result = map_ocr_to_db(ocr_result)
        
        # 验证映射结果
        self.assertIsInstance(result, dict)
        self.assertEqual(result.get('name'), '牛奶饼干')
        self.assertIn('allergens', result)
        self.assertIsInstance(result['allergens'], str)
    
    def test_map_ocr_to_db_empty(self):
        """测试空OCR结果映射"""
        # 空OCR结果
        ocr_result = {}
        
        # 映射到数据库字段
        result = map_ocr_to_db(ocr_result)
        
        # 验证映射结果
        self.assertIsInstance(result, dict)
        self.assertEqual(len(result), 0)
    
    def test_map_ocr_to_db_invalid_data(self):
        """测试无效数据映射"""
        # 无效的OCR结果
        ocr_result = {
            'StructuralList': [
                {
                    'Groups': [
                        {
                            'Lines': [
                                {
                                    'Key': {'ConfigName': '无效字段'},
                                    'Value': {'AutoContent': '无效内容'}
                                }
                            ]
                        }
                    ]
                }
            ]
        }
        
        # 映射到数据库字段
        result = map_ocr_to_db(ocr_result)
        
        # 验证映射结果
        self.assertIsInstance(result, dict)
        # 无效字段应该被忽略
        self.assertNotIn('无效字段', result)


class TestOCRProcessor(unittest.TestCase):
    """OCR处理器测试类"""
    
    def test_ocr_result_validation(self):
        """测试OCR结果验证"""
        # 模拟有效的OCR结果
        valid_ocr = {
            'StructuralList': [
                {
                    'Groups': [
                        {
                            'Lines': [
                                {
                                    'Key': {'ConfigName': '食品名称'},
                                    'Value': {'AutoContent': '测试食品'}
                                }
                            ]
                        }
                    ]
                }
            ]
        }
        
        # 验证OCR结果结构
        self.assertIn('StructuralList', valid_ocr)
        self.assertIsInstance(valid_ocr['StructuralList'], list)
        self.assertGreater(len(valid_ocr['StructuralList']), 0)
    
    def test_ocr_field_extraction(self):
        """测试OCR字段提取"""
        # 模拟OCR结果
        ocr_result = {
            'StructuralList': [
                {
                    'Groups': [
                        {
                            'Lines': [
                                {
                                    'Key': {'ConfigName': '食品名称', 'AutoName': '产品名称'},
                                    'Value': {'AutoContent': '测试饼干'}
                                },
                                {
                                    'Key': {'ConfigName': '净含量'},
                                    'Value': {'AutoContent': '500g'}
                                }
                            ]
                        }
                    ]
                }
            ]
        }
        
        # 提取字段
        extracted_fields = {}
        for struct in ocr_result.get('StructuralList', []):
            for group in struct.get('Groups', []):
                for line in group.get('Lines', []):
                    key_info = line.get('Key', {})
                    value_info = line.get('Value', {})
                    
                    # 优先使用ConfigName，其次使用AutoName
                    field_name = key_info.get('ConfigName') or key_info.get('AutoName')
                    field_value = value_info.get('AutoContent', '')
                    
                    if field_name and field_value:
                        extracted_fields[field_name] = field_value
        
        # 验证提取结果
        self.assertEqual(extracted_fields.get('食品名称'), '测试饼干')
        self.assertEqual(extracted_fields.get('净含量'), '500g')


if __name__ == '__main__':
    unittest.main()
