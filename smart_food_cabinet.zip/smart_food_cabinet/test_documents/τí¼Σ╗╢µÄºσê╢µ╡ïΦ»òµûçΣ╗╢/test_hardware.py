#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
硬件控制模块测试
测试硬件管理器的基本功能（模拟模式）
"""

import unittest
import os
import sys
import time

# 添加项目根目录到Python路径
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

# 模拟硬件管理器（在非树莓派环境下）
class MockHardwareManager:
    """模拟硬件管理器"""
    
    def __init__(self):
        self.led_states = {
            'red': False,
            'green': False,
            'blue': False
        }
        self.buzzer_state = False
        self.door_sensor_state = False
    
    def control_led(self, color, state=None):
        """模拟LED控制"""
        if color == 'red_on':
            self.led_states['red'] = True
        elif color == 'red_off':
            self.led_states['red'] = False
        elif color == 'green_on':
            self.led_states['green'] = True
        elif color == 'green_off':
            self.led_states['green'] = False
        elif color == 'blue_on':
            self.led_states['blue'] = True
        elif color == 'blue_off':
            self.led_states['blue'] = False
        elif color == 'all_off':
            self.led_states = {'red': False, 'green': False, 'blue': False}
        return True
    
    def control_buzzer(self, duration=0.1):
        """模拟蜂鸣器控制"""
        self.buzzer_state = True
        time.sleep(duration)
        self.buzzer_state = False
        return True
    
    def read_door_sensor(self):
        """模拟霍尔传感器读取"""
        return self.door_sensor_state
    
    def set_door_sensor_state(self, state):
        """设置门传感器状态（用于测试）"""
        self.door_sensor_state = state


class TestHardwareManager(unittest.TestCase):
    """硬件管理器测试类"""
    
    def setUp(self):
        """测试前准备"""
        self.hardware_manager = MockHardwareManager()
    
    def test_led_control(self):
        """测试LED控制"""
        # 测试红灯控制
        self.hardware_manager.control_led('red_on')
        self.assertTrue(self.hardware_manager.led_states['red'])
        
        self.hardware_manager.control_led('red_off')
        self.assertFalse(self.hardware_manager.led_states['red'])
        
        # 测试绿灯控制
        self.hardware_manager.control_led('green_on')
        self.assertTrue(self.hardware_manager.led_states['green'])
        
        self.hardware_manager.control_led('green_off')
        self.assertFalse(self.hardware_manager.led_states['green'])
        
        # 测试蓝灯控制
        self.hardware_manager.control_led('blue_on')
        self.assertTrue(self.hardware_manager.led_states['blue'])
        
        self.hardware_manager.control_led('blue_off')
        self.assertFalse(self.hardware_manager.led_states['blue'])
        
        # 测试全部关闭
        self.hardware_manager.control_led('red_on')
        self.hardware_manager.control_led('green_on')
        self.hardware_manager.control_led('blue_on')
        
        self.hardware_manager.control_led('all_off')
        self.assertFalse(self.hardware_manager.led_states['red'])
        self.assertFalse(self.hardware_manager.led_states['green'])
        self.assertFalse(self.hardware_manager.led_states['blue'])
    
    def test_buzzer_control(self):
        """测试蜂鸣器控制"""
        # 测试蜂鸣器开启
        result = self.hardware_manager.control_buzzer(0.01)  # 短时间测试
        self.assertTrue(result)
        # 注意：在模拟环境中，buzzer_state会立即变为False
    
    def test_door_sensor(self):
        """测试霍尔传感器"""
        # 测试门关闭状态
        self.hardware_manager.set_door_sensor_state(False)
        self.assertFalse(self.hardware_manager.read_door_sensor())
        
        # 测试门打开状态
        self.hardware_manager.set_door_sensor_state(True)
        self.assertTrue(self.hardware_manager.read_door_sensor())
    
    def test_hardware_workflow(self):
        """测试硬件完整工作流程"""
        # 1. 初始状态：所有LED关闭
        self.hardware_manager.control_led('all_off')
        self.assertFalse(any(self.hardware_manager.led_states.values()))
        
        # 2. 门打开：蓝灯亮起
        self.hardware_manager.set_door_sensor_state(True)
        self.assertTrue(self.hardware_manager.read_door_sensor())
        self.hardware_manager.control_led('blue_on')
        self.assertTrue(self.hardware_manager.led_states['blue'])
        
        # 3. 检测到标签：蜂鸣器响
        self.hardware_manager.control_buzzer(0.01)
        
        # 4. 成功处理：绿灯亮起
        self.hardware_manager.control_led('green_on')
        self.assertTrue(self.hardware_manager.led_states['green'])
        
        # 5. 门关闭：所有LED关闭
        self.hardware_manager.set_door_sensor_state(False)
        self.assertFalse(self.hardware_manager.read_door_sensor())
        self.hardware_manager.control_led('all_off')
        self.assertFalse(any(self.hardware_manager.led_states.values()))
    
    def test_error_handling(self):
        """测试错误处理"""
        # 测试无效的LED控制命令
        result = self.hardware_manager.control_led('invalid_command')
        self.assertTrue(result)  # 模拟环境总是返回True
        
        # 测试传感器状态切换
        initial_state = self.hardware_manager.read_door_sensor()
        self.hardware_manager.set_door_sensor_state(not initial_state)
        self.assertNotEqual(self.hardware_manager.read_door_sensor(), initial_state)


if __name__ == '__main__':
    unittest.main()
