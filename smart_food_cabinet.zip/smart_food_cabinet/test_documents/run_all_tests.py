#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
运行所有单元测试
"""

import unittest
import sys
import os

# 添加项目根目录到Python路径
sys.path.append(os.path.dirname(os.path.dirname(__file__)))

def run_all_tests():
    """运行所有单元测试"""
    # 创建测试套件
    test_suite = unittest.TestSuite()
    
    # 添加各个模块的测试
    test_modules = [
        '数据库测试文件.test_database',
        'RFID测试文件.test_rfid',
        '信息处理测试文件.test_info_processor',
        '硬件控制测试文件.test_hardware'
    ]
    
    # 加载测试模块
    for module_name in test_modules:
        try:
            module = __import__(module_name, fromlist=[''])
            test_suite.addTest(unittest.defaultTestLoader.loadTestsFromModule(module))
            print(f"✅ 加载测试模块: {module_name}")
        except ImportError as e:
            print(f"❌ 无法加载测试模块 {module_name}: {e}")
        except Exception as e:
            print(f"❌ 加载测试模块 {module_name} 时出错: {e}")
    
    # 运行测试
    if test_suite.countTestCases() > 0:
        print(f"\n开始运行 {test_suite.countTestCases()} 个测试用例...")
        print("=" * 60)
        
        runner = unittest.TextTestRunner(verbosity=2)
        result = runner.run(test_suite)
        
        print("=" * 60)
        print(f"测试完成!")
        print(f"运行测试: {result.testsRun}")
        print(f"失败: {len(result.failures)}")
        print(f"错误: {len(result.errors)}")
        
        if result.failures:
            print("\n失败的测试:")
            for test, traceback in result.failures:
                print(f"  - {test}: {traceback}")
        
        if result.errors:
            print("\n错误的测试:")
            for test, traceback in result.errors:
                print(f"  - {test}: {traceback}")
        
        return len(result.failures) == 0 and len(result.errors) == 0
    else:
        print("❌ 没有找到可运行的测试用例")
        return False

if __name__ == '__main__':
    print("智能食品柜系统 - 单元测试")
    print("=" * 60)
    
    success = run_all_tests()
    
    if success:
        print("\n🎉 所有测试通过!")
        sys.exit(0)
    else:
        print("\n💥 部分测试失败!")
        sys.exit(1)
