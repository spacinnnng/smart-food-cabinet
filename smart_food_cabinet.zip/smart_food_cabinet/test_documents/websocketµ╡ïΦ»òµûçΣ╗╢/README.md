# WebSocket通信测试

这是一个简单的WebSocket通信测试程序，用于测试树莓派（服务器）和客户端之间的通信功能。

## 功能测试

- ✅ 建立连接
- ✅ 客户端向树莓派发送请求-树莓派响应
- ✅ 树莓派给客户端广播
- ✅ 断开连接

## 文件说明

- `server.py` - 树莓派端WebSocket服务器
- `client.py` - 客户端测试程序
- `requirements.txt` - Python依赖包

## 安装依赖

### 树莓派端
```bash
# 激活虚拟环境（如果使用）
source sfc/bin/activate  # 或者你的虚拟环境路径

# 安装依赖
pip install -r requirements.txt
```

### 客户端（Mac）
```bash
# 激活虚拟环境（如果使用）
conda activate ocr_env  # 或者你的虚拟环境

# 安装依赖
pip install -r requirements.txt
```

## 使用方法

### 1. 启动树莓派服务器

在树莓派上运行：
```bash
python server.py
```

服务器将监听 `0.0.0.0:5001`，你会看到类似输出：
```
INFO:__main__:WebSocket服务器启动中...
INFO:__main__:监听地址: 0.0.0.0:5001
```

### 2. 运行客户端测试

在客户端（Mac）上运行：
```bash
python client.py
```

选择测试模式：
- `1` - 自动测试：运行所有测试用例
- `2` - 交互式测试：手动输入命令测试

### 3. 修改IP地址

在 `client.py` 文件中，找到这一行：
```python
server_ip = "183.172.187.250"  # 请修改为实际的树莓派IP
```

将 `183.172.187.250` 替换为你的树莓派实际IP地址。

## 测试用例

### 自动测试包含：
1. **连接测试** - 建立WebSocket连接
2. **心跳测试** - 发送ping，接收pong响应
3. **请求响应测试** - 发送请求，接收响应
4. **广播测试** - 发送广播请求，接收广播消息
5. **定期广播测试** - 等待服务器定期广播
6. **断开连接测试** - 正常断开连接

### 交互式测试命令：
- `ping` - 发送心跳
- `request <消息>` - 发送请求
- `broadcast <消息>` - 发送广播
- `quit` - 退出

## 消息格式

### 客户端发送的消息格式：
```json
{
    "type": "ping|request|broadcast_request",
    "data": "消息内容（可选）",
    "timestamp": "2024-01-01T12:00:00"
}
```

### 服务器响应的消息格式：
```json
{
    "type": "pong|response|broadcast|broadcast_sent|error",
    "message": "响应消息",
    "timestamp": "2024-01-01T12:00:00"
}
```

## 故障排除

1. **连接失败**：检查树莓派IP地址是否正确，防火墙是否开放5001端口
2. **导入错误**：确保已安装websockets库
3. **权限错误**：确保有权限监听5001端口

## 网络配置

确保树莓派和客户端在同一网络中，或者配置端口转发。
