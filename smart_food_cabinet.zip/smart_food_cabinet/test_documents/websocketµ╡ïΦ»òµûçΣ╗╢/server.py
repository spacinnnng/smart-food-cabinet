#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
树莓派端WebSocket服务器
测试功能：连接、请求响应、广播、断开连接
"""

import asyncio
import websockets
import json
import logging
from datetime import datetime

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# 存储所有连接的客户端
connected_clients = set()

async def handle_client(websocket, path):
    """处理客户端连接"""
    client_id = f"{websocket.remote_address[0]}:{websocket.remote_address[1]}"
    connected_clients.add(websocket)
    logger.info(f"客户端 {client_id} 已连接，当前连接数: {len(connected_clients)}")
    
    try:
        async for message in websocket:
            try:
                # 解析JSON消息
                data = json.loads(message)
                logger.info(f"收到来自 {client_id} 的消息: {data}")
                
                # 处理不同类型的消息
                response = await process_message(data, client_id)
                
                # 发送响应
                if response:
                    await websocket.send(json.dumps(response))
                    logger.info(f"发送响应给 {client_id}: {response}")
                    
            except json.JSONDecodeError:
                error_response = {
                    "type": "error",
                    "message": "无效的JSON格式",
                    "timestamp": datetime.now().isoformat()
                }
                await websocket.send(json.dumps(error_response))
                
    except websockets.exceptions.ConnectionClosed:
        logger.info(f"客户端 {client_id} 连接已关闭")
    except Exception as e:
        logger.error(f"处理客户端 {client_id} 时出错: {e}")
    finally:
        # 清理连接
        connected_clients.discard(websocket)
        logger.info(f"客户端 {client_id} 已断开，当前连接数: {len(connected_clients)}")

async def process_message(data, client_id):
    """处理客户端消息"""
    message_type = data.get("type", "")
    
    if message_type == "ping":
        # 心跳测试
        return {
            "type": "pong",
            "message": "服务器响应",
            "timestamp": datetime.now().isoformat()
        }
    
    elif message_type == "request":
        # 请求响应测试
        return {
            "type": "response",
            "message": f"收到你的请求: {data.get('data', '')}",
            "client_id": client_id,
            "timestamp": datetime.now().isoformat()
        }
    
    elif message_type == "broadcast_request":
        # 广播测试
        broadcast_message = {
            "type": "broadcast",
            "message": f"广播消息: {data.get('data', '')}",
            "from_client": client_id,
            "timestamp": datetime.now().isoformat()
        }
        
        # 向所有客户端广播
        await broadcast_to_all(broadcast_message)
        return {
            "type": "broadcast_sent",
            "message": "广播已发送",
            "timestamp": datetime.now().isoformat()
        }
    
    else:
        return {
            "type": "unknown",
            "message": f"未知消息类型: {message_type}",
            "timestamp": datetime.now().isoformat()
        }

async def broadcast_to_all(message):
    """向所有连接的客户端广播消息"""
    if connected_clients:
        # 创建广播任务
        broadcast_tasks = []
        for client in connected_clients.copy():
            try:
                broadcast_tasks.append(client.send(json.dumps(message)))
            except websockets.exceptions.ConnectionClosed:
                connected_clients.discard(client)
        
        # 并发发送广播
        if broadcast_tasks:
            await asyncio.gather(*broadcast_tasks, return_exceptions=True)
            logger.info(f"广播消息已发送给 {len(broadcast_tasks)} 个客户端")

async def periodic_broadcast():
    """定期广播测试消息"""
    while True:
        await asyncio.sleep(30)  # 每30秒广播一次
        if connected_clients:
            broadcast_message = {
                "type": "periodic_broadcast",
                "message": "这是服务器的定期广播消息",
                "timestamp": datetime.now().isoformat()
            }
            await broadcast_to_all(broadcast_message)

if __name__ == "__main__":
    # 启动WebSocket服务器
    start_server = websockets.serve(
        handle_client, 
        "0.0.0.0",  # 监听所有网络接口
        5001,       # 端口
        ping_interval=20,  # 心跳间隔
        ping_timeout=10    # 心跳超时
    )
    
    logger.info("WebSocket服务器启动中...")
    logger.info("监听地址: 0.0.0.0:5001")
    
    # 创建事件循环
    loop = asyncio.get_event_loop()
    
    # 启动服务器和定期广播任务
    loop.run_until_complete(start_server)
    loop.create_task(periodic_broadcast())
    
    try:
        loop.run_forever()
    except KeyboardInterrupt:
        logger.info("服务器正在关闭...")
    finally:
        loop.close()
