1
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
WebSocket客户端测试程序
测试功能：连接、发送请求、接收响应、接收广播、断开连接
"""

import asyncio
import websockets
import json
import logging
from datetime import datetime

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class WebSocketClient:
    def __init__(self, uri):
        self.uri = uri
        self.websocket = None
        
    async def connect(self):
        """连接到WebSocket服务器"""
        try:
            self.websocket = await websockets.connect(self.uri)
            logger.info(f"已连接到服务器: {self.uri}")
            return True
        except Exception as e:
            logger.error(f"连接失败: {e}")
            return False
    
    async def disconnect(self):
        """断开连接"""
        if self.websocket:
            await self.websocket.close()
            logger.info("已断开连接")
    
    async def send_message(self, message):
        """发送消息"""
        if self.websocket:
            try:
                await self.websocket.send(json.dumps(message))
                logger.info(f"发送消息: {message}")
                return True
            except Exception as e:
                logger.error(f"发送消息失败: {e}")
                return False
        return False
    
    async def receive_message(self):
        """接收消息"""
        if self.websocket:
            try:
                message = await self.websocket.recv()
                data = json.loads(message)
                logger.info(f"收到消息: {data}")
                return data
            except Exception as e:
                logger.error(f"接收消息失败: {e}")
                return None
        return None
    
    async def listen_for_messages(self):
        """持续监听消息"""
        if self.websocket:
            try:
                async for message in self.websocket:
                    data = json.loads(message)
                    logger.info(f"收到消息: {data}")
            except websockets.exceptions.ConnectionClosed:
                logger.info("连接已关闭")
            except Exception as e:
                logger.error(f"监听消息时出错: {e}")

async def test_connection():
    """测试连接功能"""
    logger.info("=== 测试连接功能 ===")
    
    # 替换为你的树莓派IP地址
    server_ip = "183.172.188.44"  # 树莓派IP地址
    uri = f"ws://{server_ip}:5001"
    
    client = WebSocketClient(uri)
    
    # 连接测试
    if not await client.connect():
        logger.error("连接测试失败")
        return
    
    logger.info("连接测试成功！")
    
    # 等待一下确保连接稳定
    await asyncio.sleep(1)
    
    # 测试1: 心跳测试
    logger.info("\n=== 测试1: 心跳测试 ===")
    ping_message = {
        "type": "ping",
        "timestamp": datetime.now().isoformat()
    }
    await client.send_message(ping_message)
    response = await client.receive_message()
    if response and response.get("type") == "pong":
        logger.info("心跳测试成功！")
    else:
        logger.error("心跳测试失败")
    
    # 测试2: 请求响应测试
    logger.info("\n=== 测试2: 请求响应测试 ===")
    request_message = {
        "type": "request",
        "data": "这是测试请求数据",
        "timestamp": datetime.now().isoformat()
    }
    await client.send_message(request_message)
    response = await client.receive_message()
    if response and response.get("type") == "response":
        logger.info("请求响应测试成功！")
    else:
        logger.error("请求响应测试失败")
    
    # 测试3: 广播测试
    logger.info("\n=== 测试3: 广播测试 ===")
    broadcast_message = {
        "type": "broadcast_request",
        "data": "这是广播测试消息",
        "timestamp": datetime.now().isoformat()
    }
    await client.send_message(broadcast_message)
    response = await client.receive_message()
    if response and response.get("type") == "broadcast_sent":
        logger.info("广播请求发送成功！")
    else:
        logger.error("广播请求发送失败")
    
    # 等待接收广播消息
    logger.info("等待接收广播消息...")
    try:
        broadcast_response = await asyncio.wait_for(client.receive_message(), timeout=5.0)
        if broadcast_response and broadcast_response.get("type") == "broadcast":
            logger.info("广播接收测试成功！")
        else:
            logger.error("广播接收测试失败")
    except asyncio.TimeoutError:
        logger.error("广播接收超时")
    
    # 测试4: 持续监听测试（等待定期广播）
    logger.info("\n=== 测试4: 持续监听测试 ===")
    logger.info("等待30秒接收定期广播消息...")
    try:
        periodic_response = await asyncio.wait_for(client.receive_message(), timeout=35.0)
        if periodic_response and periodic_response.get("type") == "periodic_broadcast":
            logger.info("定期广播接收测试成功！")
        else:
            logger.error("定期广播接收测试失败")
    except asyncio.TimeoutError:
        logger.error("定期广播接收超时")
    
    # 测试5: 断开连接测试
    logger.info("\n=== 测试5: 断开连接测试 ===")
    await client.disconnect()
    logger.info("断开连接测试完成！")
    
    logger.info("\n=== 所有测试完成 ===")

async def interactive_test():
    """交互式测试"""
    logger.info("=== 交互式WebSocket测试 ===")
    
    # 替换为你的树莓派IP地址
    server_ip = "183.172.188.44"  # 树莓派IP地址
    uri = f"ws://{server_ip}:5001"
    
    client = WebSocketClient(uri)
    
    if not await client.connect():
        logger.error("连接失败")
        return
    
    logger.info("连接成功！输入 'quit' 退出")
    logger.info("可用命令:")
    logger.info("  ping - 发送心跳")
    logger.info("  request <消息> - 发送请求")
    logger.info("  broadcast <消息> - 发送广播")
    logger.info("  quit - 退出")
    
    # 启动消息监听任务
    listen_task = asyncio.create_task(client.listen_for_messages())
    
    try:
        while True:
            user_input = input("\n请输入命令: ").strip()
            
            if user_input.lower() == 'quit':
                break
            elif user_input.lower() == 'ping':
                message = {
                    "type": "ping",
                    "timestamp": datetime.now().isoformat()
                }
                await client.send_message(message)
            elif user_input.startswith('request '):
                data = user_input[8:]  # 去掉 'request ' 前缀
                message = {
                    "type": "request",
                    "data": data,
                    "timestamp": datetime.now().isoformat()
                }
                await client.send_message(message)
            elif user_input.startswith('broadcast '):
                data = user_input[10:]  # 去掉 'broadcast ' 前缀
                message = {
                    "type": "broadcast_request",
                    "data": data,
                    "timestamp": datetime.now().isoformat()
                }
                await client.send_message(message)
            else:
                logger.info("未知命令")
                
    except KeyboardInterrupt:
        logger.info("\n用户中断")
    finally:
        listen_task.cancel()
        await client.disconnect()

if __name__ == "__main__":
    print("WebSocket客户端测试程序")
    print("1. 自动测试")
    print("2. 交互式测试")
    
    choice = input("请选择测试模式 (1/2): ").strip()
    
    if choice == "1":
        asyncio.run(test_connection())
    elif choice == "2":
        asyncio.run(interactive_test())
    else:
        print("无效选择")
