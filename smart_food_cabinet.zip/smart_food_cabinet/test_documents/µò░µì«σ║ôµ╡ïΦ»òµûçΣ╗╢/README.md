# 数据库模块测试

这是数据库管理器的单元测试，用于测试数据管理器的基本功能。

## 功能测试

- ✅ 数据库创建
- ✅ 表结构创建
- ✅ 食品信息插入
- ✅ 食品信息查询
- ✅ 食品信息更新
- ✅ 食品信息删除
- ✅ 获取所有食品

## 文件说明

- `test_database.py` - 数据库管理器测试程序

## 安装依赖

```bash
# 激活虚拟环境
source sfc/bin/activate  # 树莓派
# 或
conda activate ocr_env   # Mac

# 安装依赖
pip install -r ../../requirements.txt
```

## 使用方法

### 运行测试

```bash
cd test_documents/数据库测试文件/
python test_database.py
```

### 测试输出示例

```
.....
----------------------------------------------------------------------
Ran 7 tests in 0.123s

OK
```

## 测试用例说明

1. **test_database_creation** - 测试数据库文件创建
2. **test_table_creation** - 测试表结构创建
3. **test_food_insertion** - 测试食品信息插入
4. **test_food_retrieval** - 测试食品信息查询
5. **test_food_update** - 测试食品信息更新
6. **test_food_deletion** - 测试食品信息删除
7. **test_get_all_foods** - 测试获取所有食品

## 注意事项

- 测试使用临时数据库文件，不会影响实际数据
- 测试完成后会自动清理临时文件
- 需要确保数据库模块可以正常导入
