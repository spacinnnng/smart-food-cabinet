#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
数据库模块测试
测试数据管理器的基本功能
"""

import unittest
import os
import sys
import tempfile
import shutil

# 添加项目根目录到Python路径
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

from modules.database.data_manager import DatabaseManager


class TestDatabaseManager(unittest.TestCase):
    """数据库管理器测试类"""
    
    def setUp(self):
        """测试前准备"""
        # 创建临时数据库文件
        self.temp_dir = tempfile.mkdtemp()
        self.temp_db_path = os.path.join(self.temp_dir, 'test.db')
        
        # 设置临时数据库路径
        os.environ['DATABASE_PATH'] = self.temp_db_path
    
    def tearDown(self):
        """测试后清理"""
        # 清理临时文件
        if os.path.exists(self.temp_dir):
            shutil.rmtree(self.temp_dir)
    
    def test_database_creation(self):
        """测试数据库创建"""
        with DatabaseManager() as db:
            self.assertTrue(os.path.exists(self.temp_db_path))
            self.assertIsNotNone(db.conn)
    
    def test_table_creation(self):
        """测试表结构创建"""
        with DatabaseManager() as db:
            # 检查foods表是否存在
            cursor = db.conn.cursor()
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='foods'")
            result = cursor.fetchone()
            self.assertIsNotNone(result)
    
    def test_food_insertion(self):
        """测试食品信息插入"""
        with DatabaseManager() as db:
            # 测试数据
            food_data = {
                'name': '测试食品',
                'net_content': '500g',
                'production_date': '2024-01-01',
                'expire_date': '2024-12-31',
                'category': '零食',
                'quantity': 5
            }
            
            # 插入数据
            food_id = db.insert_food(food_data)
            self.assertIsNotNone(food_id)
            self.assertGreater(food_id, 0)
    
    def test_food_retrieval(self):
        """测试食品信息查询"""
        with DatabaseManager() as db:
            # 插入测试数据
            food_data = {
                'name': '测试食品',
                'net_content': '500g',
                'production_date': '2024-01-01',
                'expire_date': '2024-12-31',
                'category': '零食',
                'quantity': 5
            }
            food_id = db.insert_food(food_data)
            
            # 查询数据
            retrieved_food = db.get_food_by_id(food_id)
            self.assertIsNotNone(retrieved_food)
            self.assertEqual(retrieved_food['name'], '测试食品')
    
    def test_food_update(self):
        """测试食品信息更新"""
        with DatabaseManager() as db:
            # 插入测试数据
            food_data = {
                'name': '测试食品',
                'net_content': '500g',
                'production_date': '2024-01-01',
                'expire_date': '2024-12-31',
                'category': '零食',
                'quantity': 5
            }
            food_id = db.insert_food(food_data)
            
            # 更新数据
            update_data = {'quantity': 10}
            success = db.update_food(food_id, update_data)
            self.assertTrue(success)
            
            # 验证更新
            updated_food = db.get_food_by_id(food_id)
            self.assertEqual(updated_food['quantity'], 10)
    
    def test_food_deletion(self):
        """测试食品信息删除"""
        with DatabaseManager() as db:
            # 插入测试数据
            food_data = {
                'name': '测试食品',
                'net_content': '500g',
                'production_date': '2024-01-01',
                'expire_date': '2024-12-31',
                'category': '零食',
                'quantity': 5
            }
            food_id = db.insert_food(food_data)
            
            # 删除数据
            success = db.delete_food(food_id)
            self.assertTrue(success)
            
            # 验证删除
            deleted_food = db.get_food_by_id(food_id)
            self.assertIsNone(deleted_food)
    
    def test_get_all_foods(self):
        """测试获取所有食品"""
        with DatabaseManager() as db:
            # 插入多条测试数据
            for i in range(3):
                food_data = {
                    'name': f'测试食品{i}',
                    'net_content': '500g',
                    'production_date': '2024-01-01',
                    'expire_date': '2024-12-31',
                    'category': '零食',
                    'quantity': 5
                }
                db.insert_food(food_data)
            
            # 获取所有食品
            all_foods = db.get_all_foods()
            self.assertGreaterEqual(len(all_foods), 3)


if __name__ == '__main__':
    unittest.main()
