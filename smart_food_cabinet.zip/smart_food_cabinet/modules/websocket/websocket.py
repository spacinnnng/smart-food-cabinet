import asyncio
import websockets
import json
import os
import logging
import sys
from pathlib import Path
from datetime import datetime
from typing import Dict, Any
import aiohttp
from aiohttp import web
from PIL import Image
import io

# 添加项目根目录到Python路径
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

# 导入配置
from config import (
    WEB_API_HOST, WEB_API_PORT, WEBSOCKET_PORT, IMAGES_TEMP_DIR,
    db_data_list, food_number, MessageTypes, StatusTypes, ActionTypes
)

# ==================== 配置部分 ====================
# 服务器监听地址
HOST = WEB_API_HOST
# WebSocket端口
PORT = WEBSOCKET_PORT
# HTTP服务器端口
HTTP_PORT = WEB_API_PORT
# 网页文件目录
WEB_DIR = Path(__file__).parent.parent.parent / "http"

# 配置日志
logger = logging.getLogger(__name__)

# 确保上传目录存在
IMAGES_TEMP_DIR.mkdir(exist_ok=True, parents=True)

# 打印服务器启动信息和图片保存路径
logger.info(f"WebSocket服务器启动 - 地址: {HOST}:{PORT}")
logger.info(f"图片存储目录: {IMAGES_TEMP_DIR}")

# ==================== 服务器启动部分 ====================
async def start_websocket_server():
    """启动WebSocket服务器"""
    # 创建服务器实例
    server = SmartFoodCabinetWebSocketServer()
    
    # 设置全局服务器实例
    set_websocket_server(server)
    
    # 启动消息队列处理任务
    message_task = asyncio.create_task(server.process_message_queue())
    
    # 启动WebSocket服务器
    async with websockets.serve(
        server.handler, 
        HOST, 
        PORT,
        # 连接稳定性配置
        ping_interval=60,        # 每60秒发送一次ping
        ping_timeout=30,         # ping超时时间30秒
        close_timeout=10,        # 关闭超时时间10秒
        max_size=10*1024*1024,   # 最大消息大小10MB
        compression=None         # 禁用压缩
    ):
        # websockets库在底层自动完成：
        # 1. 监听端口5001
        # 2. 接收HTTP升级请求
        # 3. 解析Sec-WebSocket-Key
        # 4. 生成Sec-WebSocket-Accept
        # 5. 发送101响应
        # 6. 升级为WebSocket连接
        # 7. 调用我们的handler函数
        logger.info(f"WebSocket服务器已启动，监听端口 {PORT}")
        logger.info("等待客户端连接...")
        # 保持服务器运行
        await asyncio.Future()  # 创建一个永远不会完成的Future

# ==================== 服务器类定义 ====================
class SmartFoodCabinetWebSocketServer:
    """
    智能食品柜WebSocket服务器类
    负责处理客户端连接、消息路由、入库出库流程管理
    """
    
    # ==================== 初始化和配置 ====================
    def __init__(self):
        # 存储所有活跃连接
        self.connections = set()
        self.sessions = {}
        
        # IP地址到连接的映射
        self.ip_connections = {}  # {ip: websocket}
        
        # 取消标志
        self.ocr_cancel_requested = False
        
        # 线程安全的消息队列
        import queue
        self.message_queue = queue.Queue()
        
        # 导入必要的模块
        try:
            from ..rfid.rfid_in import RFIDReader
            from ..rfid.rfid_out import RFIDOutboundManager
            from ..database.data_manager import DatabaseManager
            
            # 延迟初始化
            self.rfid_in_manager = None
            self.rfid_out_manager = None
            self.db_manager = None
            
            logger.info("WebSocket服务器初始化完成")
            
        except ImportError as e:
            logger.error(f"导入模块失败: {e}")
            self.rfid_in_manager = None
            self.rfid_out_manager = None
            self.db_manager = None
    
    # ==================== 核心连接生命周期管理 ====================
    async def register(self, websocket):
        """注册新的客户端连接"""
        client_ip = "未知"
        try:
            # 获取客户端IP地址
            client_ip = websocket.remote_address[0] if websocket.remote_address else "未知"
            logger.info(f"开始注册客户端连接: {client_ip}")
            
            # 检查是否已存在来自同一IP的连接
            if client_ip in self.ip_connections:
                old_websocket = self.ip_connections[client_ip]
                logger.info(f"检测到来自 {client_ip} 的重复连接，关闭旧连接")
                
                # 关闭旧连接
                try:
                    await old_websocket.close(code=1000, reason="新连接替换")
                except Exception as close_error:
                    logger.warning(f"关闭旧连接失败: {close_error}")
                
                # 从连接集合中删除旧连接
                if old_websocket in self.connections:
                    self.connections.remove(old_websocket)
                    logger.info(f"已从连接集合中移除旧连接")
                
                # 从IP映射中删除旧连接
                del self.ip_connections[client_ip]
                logger.info(f"已从IP映射中移除旧连接: {client_ip}")
            
            # 将新连接添加到连接集合中
            self.connections.add(websocket)
            logger.info(f"新连接已添加到连接集合，当前连接数: {len(self.connections)}")
            
            # 将新连接添加到IP映射中
            self.ip_connections[client_ip] = websocket
            logger.info(f"新连接已添加到IP映射: {client_ip}")
            
            # 打印连接信息
            logger.info(f"新客户端连接注册成功 from {client_ip}, 当前连接数: {len(self.connections)}")
            
            # 向客户端发送连接成功确认消息
            try:
                await self.send_response(websocket, MessageTypes.CONNECTION, ActionTypes.SUCCESS, {
                    'status': StatusTypes.CONNECTED
                })
                logger.info(f"连接成功消息已发送给客户端: {client_ip}")
            except Exception as send_error:
                logger.error(f"发送连接成功消息失败: {send_error}")
                raise send_error
            
        except Exception as e:
            # 详细错误处理：记录错误并清理连接
            logger.error(f"注册连接失败 - IP: {client_ip}, 错误: {e}")
            import traceback
            logger.error(f"注册连接失败详细错误: {traceback.format_exc()}")
            
            # 如果连接已添加到集合中，需要删除
            if websocket in self.connections:
                self.connections.remove(websocket)
                logger.info(f"已从连接集合中移除失败的连接，当前连接数: {len(self.connections)}")
            
            # 从IP映射中删除（如果存在）
            if client_ip in self.ip_connections and self.ip_connections[client_ip] == websocket:
                del self.ip_connections[client_ip]
                logger.info(f"已从IP映射中移除失败的连接: {client_ip}")
            
            # 尝试发送错误消息给客户端
            try:
                await self.send_error(websocket, "连接注册失败")
                logger.info(f"连接注册失败错误消息已发送给客户端: {client_ip}")
            except Exception as error_send_error:
                # 如果连错误消息都发送不了，说明连接已断开
                logger.warning(f"无法发送错误消息给客户端 {client_ip}，连接可能已断开: {error_send_error}")
                # 重新抛出原始异常，让上层处理
                raise e
    
    async def unregister(self, websocket):
        """移除断开连接的客户端"""
        try:
            # 获取客户端IP地址
            client_ip = websocket.remote_address[0] if websocket.remote_address else "未知"
            
            if websocket in self.connections:
                self.connections.remove(websocket)
                logger.info(f"客户端断开，当前连接数: {len(self.connections)}")
            else:
                logger.warning("尝试移除不存在的连接")
            
            # 从IP映射中删除（如果存在）
            if client_ip in self.ip_connections and self.ip_connections[client_ip] == websocket:
                del self.ip_connections[client_ip]
                logger.info(f"已从IP映射中移除 {client_ip} 的连接")
                
        except Exception as e:
            logger.error(f"移除连接失败: {e}")
    
    # ==================== 消息队列处理 ====================
    async def process_message_queue(self):
        """处理来自其他线程的消息队列"""
        logger.info("消息队列处理任务已启动")
        while True:
            try:
                # 非阻塞方式获取队列中的消息
                try:
                    message = self.message_queue.get_nowait()
                    logger.info(f"从队列中获取到消息: {message}")
                except:
                    # 队列为空，等待一小段时间
                    await asyncio.sleep(0.1)
                    continue
                
                # 处理出库通知消息
                if message.get('type') == 'outbound_notification':
                    action = message.get('action')
                    data = message.get('data')
                    logger.info(f"开始处理出库通知: action={action}, data={data}")
                    await self.broadcast_outbound_notification(action, data)
                    logger.info(f"已处理队列中的出库通知: action={action}")
                else:
                    logger.warning(f"收到未知类型的消息: {message}")
                
                # 标记任务完成
                self.message_queue.task_done()
                
            except Exception as e:
                logger.error(f"处理消息队列失败: {e}")
                await asyncio.sleep(1)  # 出错时等待1秒再继续
    
    # ==================== 核心消息处理 ====================
    async def handler(self, websocket):
        """处理WebSocket连接的主函数"""
        # 注册新连接
        await self.register(websocket)
        try:
            # 循环接收客户端发送的消息
            async for message in websocket:
                # 处理每条消息
                await self.handle_message(websocket, message)
                
        except websockets.exceptions.ConnectionClosed as e:
            # 处理连接关闭的情况
            logger.info(f"客户端连接已关闭: {e}")
        except Exception as e:
            # 处理其他异常
            logger.error(f"处理连接时发生错误: {e}")
        finally:
            # 无论是否发生异常，最终都要取消注册连接
            await self.unregister(websocket)
            
    async def handle_message(self, websocket, message):
        """处理接收到的消息（文本或二进制）"""
        try:
            # 判断消息类型：文本消息（JSON格式的元数据）或二进制消息（图片数据）
            if isinstance(message, str):
                # 文本消息：应该是JSON格式的元数据
                data = json.loads(message)  # 解析JSON
                
                # 处理心跳消息
                if data.get('type') == 'ping':
                    await self.send_response(websocket, 'pong', 'success', {
                        'timestamp': data.get('timestamp', 0),
                        'server_time': datetime.now().isoformat()
                    })
                    return
                
                # ========== 消息类型处理 - 根据业务流程重新整理 ==========
                # 从JSON消息中提取消息类型，根据不同类型调用对应的业务处理函数
                msg_type = data.get('type')

                #------ 入库流程 ------
                # 处理食品数量设置：用户通过手机端设置要入库的食品数量
                if msg_type == MessageTypes.INBOUND_FOOD_NUMBER:
                    await self.handle_inbound_food_number(websocket, data)
                # 处理RFID读取：启动RFID模块读取食品标签，获取标签列表
                elif msg_type == MessageTypes.INBOUND_RFID_READING:
                    await self.handle_inbound_rfid_reading(websocket, data)
                # 处理信息处理请求：启动OCR识别、分类检测和表格日期检测流程
                elif msg_type == MessageTypes.INBOUND_OCR_PROCESS:
                    await self.handle_inbound_info_process(websocket, data)
                # 处理上传成功确认：标记数据已同步到手机端
                elif msg_type == MessageTypes.INBOUND_UPLOAD_SUCCESS:
                    await self.handle_inbound_upload_success(websocket, data)
                # 处理入库结束：清空临时数据，完成入库流程
                elif msg_type == MessageTypes.INBOUND_END:
                    await self.handle_inbound_end(websocket, data)
                # 处理中止入库：中断当前入库流程，清理所有临时数据
                elif msg_type == MessageTypes.INBOUND_CANCEL:
                    await self.handle_inbound_cancel(websocket, data)
                    
                #------ 出库流程 ------
                # 出库流程只需要广播通知，无需确认回调
                
                #------ 系统功能 ------
                # 注意：食品列表相关功能已改为纯本地存储，不再需要服务器处理
                
                # 处理未知消息类型：记录错误并返回错误信息给客户端
                else:
                    logger.error(f"未知消息类型: {msg_type}")
                    await self.send_error(websocket, "未知消息类型")
            
            elif isinstance(message, bytes):
                # 处理二进制消息：接收手机端上传的食品图片数据，用于后续的OCR识别和分类检测
                await self.handle_image_upload(websocket, message)
                
        except json.JSONDecodeError:
            # 处理JSON解析错误
            logger.error("收到无法解析的JSON消息")
            await self.send_error(websocket, "无效的JSON格式")
        except Exception as e:
            # 处理其他未知错误
            logger.error(f"处理消息时出错: {str(e)}")
            await self.send_error(websocket, str(e))
    
    # ==================== 消息发送工具函数 ====================
    async def send_response(self, websocket, msg_type, action, data):
        """发送标准响应消息"""
        response = {
            'type': msg_type,   # 消息的业务类型，告诉客户端这是什么业务消息
            'action': action,   # 消息的执行结果，告诉客户端这个操作的结果如何
            'data': data,       # 信息
            'timestamp': datetime.now().isoformat()   # 时间戳，ISO格式：YYYY-MM-DDTHH:MM:SS.ffffff
        }
        
        if hasattr(websocket, 'session_id'):
            response['session_id'] = websocket.session_id
        
        await websocket.send(json.dumps(response))

    async def send_error(self, websocket, error_message):
        """发送错误消息"""
        await self.send_response(websocket, MessageTypes.ERROR, ActionTypes.ERROR, {
            'status': StatusTypes.ERROR,
            'error_message': error_message
        })
    
    def compress_image(self, image_data: bytes, max_size_kb: int = 500) -> bytes:
        """
        压缩图片数据到指定大小以下
        
        Args:
            image_data: 原始图片数据
            max_size_kb: 最大文件大小（KB）
            
        Returns:
            bytes: 压缩后的图片数据
        """
        try:
            max_size_bytes = max_size_kb * 1024
            
            # 如果图片已经小于目标大小，直接返回
            if len(image_data) <= max_size_bytes:
                logger.info(f"图片大小 {len(image_data)} bytes 已符合要求，无需压缩")
                return image_data
            
            # 打开图片
            image = Image.open(io.BytesIO(image_data))
            
            # 转换为RGB模式（如果是RGBA或其他模式）
            if image.mode in ('RGBA', 'LA', 'P'):
                # 创建白色背景
                background = Image.new('RGB', image.size, (255, 255, 255))
                if image.mode == 'P':
                    image = image.convert('RGBA')
                background.paste(image, mask=image.split()[-1] if image.mode == 'RGBA' else None)
                image = background
            elif image.mode != 'RGB':
                image = image.convert('RGB')
            
            # 多级压缩策略
            compression_levels = [
                {'size': (1280, 720), 'quality': 60, 'name': '中等压缩'},
                {'size': (1024, 576), 'quality': 50, 'name': '较强压缩'},
                {'size': (800, 450), 'quality': 40, 'name': '强压缩'},
                {'size': (640, 360), 'quality': 30, 'name': '极强压缩'},
                {'size': (480, 270), 'quality': 20, 'name': '极限压缩'}
            ]
            
            for level in compression_levels:
                # 调整图片大小
                resized_image = image.resize(level['size'], Image.Resampling.LANCZOS)
                
                # 压缩并保存到内存
                output = io.BytesIO()
                resized_image.save(output, format='JPEG', quality=level['quality'], optimize=True)
                compressed_data = output.getvalue()
                
                logger.info(f"尝试{level['name']}: 原始 {len(image_data)} bytes -> 压缩后 {len(compressed_data)} bytes")
                
                # 如果压缩后大小符合要求，返回结果
                if len(compressed_data) <= max_size_bytes:
                    logger.info(f"图片压缩成功: {level['name']}, 最终大小: {len(compressed_data)} bytes")
                    return compressed_data
            
            # 如果所有级别都无法达到目标大小，返回最小的大小
            logger.warning(f"无法将图片压缩到 {max_size_kb}KB 以下，使用极限压缩结果: {len(compressed_data)} bytes")
            return compressed_data
            
        except Exception as e:
            logger.error(f"图片压缩失败: {e}")
            # 压缩失败时返回原始数据
            return image_data
    
    async def broadcast_message(self, msg_type, action, data):
        """向所有连接的客户端广播消息（主动推送）"""
        logger.info(f"开始广播消息: type={msg_type}, action={action}, connections={len(self.connections)}")
        
        if not self.connections:
            logger.warning("没有活跃的连接，无法广播消息")
            return
        
        response = {
            'type': msg_type,
            'action': action,
            'data': data,
            'timestamp': datetime.now().isoformat()
        }
        
        message_json = json.dumps(response)
        logger.info(f"准备发送的消息: {message_json}")
        
        disconnected_connections = set()
        successful_sends = 0
        
        # 向所有连接发送消息
        for websocket in self.connections.copy():
            try:
                await websocket.send(message_json)
                successful_sends += 1
                logger.info(f"消息已发送到客户端: {websocket.remote_address}")
            except websockets.exceptions.ConnectionClosed:
                # 连接已关闭，标记为需要删除
                disconnected_connections.add(websocket)
                logger.warning(f"客户端连接已关闭: {websocket.remote_address}")
            except Exception as e:
                logger.error(f"发送消息到客户端失败: {websocket.remote_address}, 错误: {e}")
                disconnected_connections.add(websocket)
        
        # 清理已断开的连接
        for websocket in disconnected_connections:
            self.connections.discard(websocket)
        
        logger.info(f"广播消息完成，成功发送到 {successful_sends} 个客户端，当前连接数: {len(self.connections)}")
    
    # ==================== 入库流程 ====================
    # ------- 数据准备阶段：图片、食品数量设置 -------
    async def handle_image_upload(self, websocket, image_data):
        """处理图片上传，成功时返回成功消息，失败时返回失败消息"""
        try:
            # 生成唯一文件名
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")[:-3]
            filename = f"food_{timestamp}.jpg"
            filepath = IMAGES_TEMP_DIR / filename
            
            # 记录接收到的数据大小
            data_size = len(image_data)
            logger.info(f"接收到图片数据: {data_size} bytes")
            
            # 检查数据大小是否合理
            if data_size == 0:
                logger.error("接收到空数据")
                await self.send_error(websocket, "接收到空数据")
                return False
            
            if data_size > 500 * 1024:  # 500KB限制 - 基于WebSocket实际传输能力
                logger.error(f"图片文件过大: {data_size} bytes")
                await self.send_error(websocket, "图片文件过大，最大支持500KB")
                return False
            
            # 保存图片
            with open(filepath, 'wb') as f:
                f.write(image_data)
            
            # 验证文件是否保存成功
            saved_size = filepath.stat().st_size
            logger.info(f"图片已保存: {filename}, 大小: {saved_size} bytes")
            
            # 验证文件完整性
            if saved_size != data_size:
                logger.error(f"文件大小不匹配: 接收{saved_size} bytes, 保存{data_size} bytes")
                await self.send_error(websocket, "文件保存不完整")
                return False
            
            # 发送成功消息
            # 发送：图片上传成功消息，包含文件名
            await self.send_response(websocket, MessageTypes.INBOUND_READY, ActionTypes.SUCCESS, {
                'status': StatusTypes.READY,
                'message': '图片上传成功',
                'filename': filename,
                'size': saved_size
            })
            
            return True  # 返回成功标志
            
        except Exception as e:
            logger.error(f"保存图片失败: {e}")
            await self.send_error(websocket, f"保存图片失败: {str(e)}")
            return False  # 返回失败标志

    async def handle_inbound_food_number(self, websocket, data):
        """处理食品数量设置，成功时返回成功消息，失败时返回失败消息"""
        try:
            food_number = data.get('data', {}).get('food_number', 1)
            
            # 更新全局变量
            import config
            config.food_number = food_number
            config.db_data_list['food_number'] = food_number
            
            logger.info(f"食品数量设置: {food_number}")
            
            # 发送成功消息
            # 发送：食品数量设置成功消息，包含设置的数量
            await self.send_response(websocket, MessageTypes.INBOUND_READY, ActionTypes.SUCCESS, {
                'status': StatusTypes.READY,
                'message': '食品数量设置成功',
                'food_number': food_number
            })
            
            return True  # 返回成功标志
            
        except Exception as e:
            logger.error(f"设置食品数量失败: {e}")
            await self.send_error(websocket, "设置食品数量失败")
            return False  # 返回失败标志


    # ------- RFID读取阶段 -------
    async def handle_inbound_rfid_reading(self, websocket, data):
        """
        启动RFID读取：调用rfid_in模块
        流程：
        1. 将food_number写入字典db_data_list
        2. 调用read_multiple_unique_tags_with_feedback读取不同标签ID
        3. 读取过程中LED绿灯常亮，每读取到新ID蜂鸣器响一次
        4. 读取到目标数量或超时后停止，提供相应LED反馈
        5. 将读取到的不同ID写入db_data_list
        """
        try:
            # 调用RFID入库模块
            if not self.rfid_in_manager:
                from ..rfid.rfid_in import RFIDReader
                self.rfid_in_manager = RFIDReader()
            
            if not self.rfid_in_manager.connect():
                await self.send_error(websocket, "RFID连接失败")
                return
            
            # 重置取消标志
            self.rfid_in_manager.cancel_requested = False
            
            # 启动RFID读取
            result = self.rfid_in_manager.read_multiple_unique_tags_with_feedback()
            
            # 根据结果返回消息
            if result['success']:
                # 更新全局变量（只有当result中有有效数据时才更新）
                import config
                if result['rfid_list']:
                    config.db_data_list['rfid_list'] = result['rfid_list']
                
                # 发送：RFID读取成功消息，包含标签数量和列表
                await self.send_response(websocket, MessageTypes.INBOUND_RFID_RESULT, ActionTypes.SUCCESS, {
                    'status': StatusTypes.RFID_READING_SUCCESS,
                    'tag_count': result['tag_count'],
                    'rfid_list': result['rfid_list']
                })
                
                logger.info(f"RFID读取成功: 标签数量={result['tag_count']}, 标签列表={result['rfid_list']}")
            else:
                # 检查是否被取消
                if self.rfid_in_manager.cancel_requested:
                    # RFID读取被取消，只记录日志，不发送消息给手机端
                    logger.info(f"RFID读取被取消: 已识别标签数量={result['tag_count']}")
                else:
                    # RFID读取失败（非取消情况）
                    logger.warning(f"RFID读取失败: 已识别标签数量={result['tag_count']}")
                    await self.send_error(websocket, "RFID读取失败")
            
        except Exception as e:
            logger.error(f"RFID读取失败: {e}")
            await self.send_error(websocket, "RFID读取失败")


    # ------- 信息处理阶段 -------
    async def handle_inbound_info_process(self, websocket, data):
        """启动信息处理：对images_tempt中的图片进行OCR识别、分类检测和表格日期检测"""
        try:
            # 重置取消标志
            self.ocr_cancel_requested = False
            
            # 调用信息处理模块
            from ..info_processor.tencent_ocr import process_images_to_db_data
            from ..info_processor.category_detector import FoodDrinkDetector
            from ..info_processor.table_date_detector import TableDateDetector
            
            # 初始化处理器
            from config import YOLO_CATEGORY_MODEL_PATH, YOLO_TABLE_DATE_MODEL_PATH
            category_processor = FoodDrinkDetector(YOLO_CATEGORY_MODEL_PATH)
            table_date_processor = TableDateDetector(YOLO_TABLE_DATE_MODEL_PATH)
            
            # 处理images_tempt中的图片
            import os
            import config
            images_dir = "images_tempt"
            image_files = [f for f in os.listdir(images_dir) if f.lower().endswith(('.jpg', '.jpeg', '.png'))]
            
            # 依次处理每张图片
            for image_file in image_files:
                # 检查是否被取消（图片处理循环中，每张图片处理前检查）
                if self.ocr_cancel_requested:
                    # 图片处理被取消，只记录日志，不发送消息给手机端
                    logger.info("图片处理因中止入库而停止")
                    return
                
                image_path = os.path.join(images_dir, image_file)
                
                # OCR识别：提取文字信息
                # 注意：process_images_to_db_data函数处理整个images_tempt目录
                # 这里我们只处理单张图片，所以需要调用相应的函数
                # 暂时跳过单张图片的OCR处理，在最后统一处理
                
                # 分类检测：使用OD大模型检测食品类别
                try:
                    # 调用正确的分析方法，返回简单的类别字符串
                    category_result = category_processor.analyze_category(image_path)
                    if category_result:
                        config.db_data_list['category'] = category_result
                        logger.info(f"分类检测完成: {image_file}, 类别: {category_result}")
                except Exception as e:
                    logger.error(f"分类检测失败 {image_file}: {e}")
                
                # 表格日期检测：检测生产日期和保质期
                try:
                    table_date_image, table_date_results = table_date_processor.detect_objects(image_path)
                    if table_date_results:
                        # 保存标记后的图片到images_return
                        from config import IMAGES_RETURN_DIR
                        output_path = os.path.join(str(IMAGES_RETURN_DIR), f"table_date_result_{image_file}")
                        
                        # 调用可视化方法保存标记后的图片
                        table_date_processor.visualize_results(table_date_image, table_date_results, output_path)
                        logger.info(f"表格日期检测完成: {image_file}, 结果已保存到: {output_path}")
                    else:
                        logger.info(f"表格日期检测完成: {image_file}, 未检测到对象")
                except Exception as e:
                    logger.error(f"表格日期检测失败 {image_file}: {e}")
                    
            # 检查是否被取消（数据保存阶段，所有图片处理完成后检查）
            if self.ocr_cancel_requested:
                # 数据保存被取消，只记录日志，不发送消息给手机端
                logger.info("数据保存因中止入库而停止")
                return
            
            # 统一进行OCR处理
            try:
                logger.info("=" * 80)
                logger.info("开始OCR处理...")
                logger.info("=" * 80)
                
                ocr_result = process_images_to_db_data()
                if ocr_result:
                    logger.info("=" * 80)
                    logger.info("OCR处理完成，详细结果如下:")
                    logger.info("=" * 80)
                    logger.info(f"OCR返回的字段数量: {len(ocr_result)}")
                    logger.info(f"OCR返回的字段列表: {list(ocr_result.keys())}")
                    logger.info(f"OCR返回的完整数据:")
                    for key, value in ocr_result.items():
                        logger.info(f"  {key}: {value}")
                    logger.info("=" * 80)
                    
                    # 保存category字段，避免被OCR结果覆盖
                    saved_category = config.db_data_list.get('category')
                    logger.info(f"保存category字段: {saved_category}")
                    
                    # 保存OCR结果到临时文件，防止连接断开导致数据丢失
                    self.save_ocr_result_to_temp_file(ocr_result)
                    
                    config.db_data_list.update(ocr_result)
                    
                    # 恢复category字段
                    if saved_category:
                        config.db_data_list['category'] = saved_category
                        logger.info(f"已恢复category字段: {saved_category}")
                    
                    logger.info("OCR处理完成，数据已更新到db_data_list")
                else:
                    logger.warning("OCR处理返回空结果")
            except Exception as e:
                logger.error(f"OCR处理失败: {e}")
                import traceback
                logger.error(f"OCR处理详细错误: {traceback.format_exc()}")
            
            # 将数据写入数据库
            logger.info("=" * 50)
            logger.info("准备保存到数据库的db_data_list内容:")
            logger.info(f"db_data_list: {config.db_data_list}")
            logger.info(f"db_data_list字段: {list(config.db_data_list.keys())}")
            logger.info("=" * 50)
            
            from ..database.data_manager import DatabaseManager
            data_manager = DatabaseManager()
            food_id = data_manager.save_food_info(config.db_data_list)
            
            # 将food_id添加到db_data_list中
            config.db_data_list['food_id'] = food_id
            logger.info(f"数据库保存成功，food_id: {food_id}")
            
            # 先发送db_data_list数据
            # 发送：信息处理完成消息，包含所有识别数据
            
            # 检查name字段，如果为空则添加"name": "NULL"
            db_data_to_send = config.db_data_list.copy()
            if not db_data_to_send.get('name') or db_data_to_send.get('name') == '':
                db_data_to_send['name'] = 'NULL'
                logger.info("name字段为空，已设置为'NULL'")
            
            await self.send_response(websocket, MessageTypes.INBOUND_OCR_PROCESS, ActionTypes.SUCCESS, {
                'status': StatusTypes.DATA_READY,
                'db_data_list': db_data_to_send
            })
            
            # 然后发送images_return中的处理结果图片
            from config import IMAGES_RETURN_DIR
            if IMAGES_RETURN_DIR.exists():
                # 获取images_return目录中的所有图片文件
                result_image_files = []
                for ext in ['.jpg', '.jpeg', '.png', '.bmp']:
                    for file_path in IMAGES_RETURN_DIR.glob(f"*{ext}"):
                        if file_path.is_file():
                            result_image_files.append(file_path)
                
                # 按文件名排序
                result_image_files.sort(key=lambda x: x.name)
                
                if result_image_files:
                    # 发送图片数量信息
                    # 发送：图片处理完成消息，包含图片数量
                    await self.send_response(websocket, MessageTypes.INBOUND_OCR_PROCESS, ActionTypes.IMAGES, {
                        'status': StatusTypes.IMAGES_READY,
                        'image_count': len(result_image_files),
                        'message': f'开始发送{len(result_image_files)}张处理结果图片'
                    })
                    
                    # 依次发送每张处理结果图片
                    for i, image_path in enumerate(result_image_files):
                        try:
                            # 读取图片文件
                            with open(image_path, 'rb') as f:
                                original_image_data = f.read()
                            
                            # 压缩图片到500KB以下
                            compressed_image_data = self.compress_image(original_image_data, max_size_kb=500)
                            
                            # 发送压缩后的图片数据（二进制）
                            await websocket.send(compressed_image_data)
                            
                            logger.info(f"处理结果图片已发送 ({i+1}/{len(result_image_files)}): {image_path.name}, 原始大小: {len(original_image_data)} bytes, 压缩后: {len(compressed_image_data)} bytes")
                            
                        except Exception as e:
                            logger.error(f"发送处理结果图片失败: {image_path.name}, 错误: {e}")
                            continue
                    
                    logger.info(f"处理结果图片发送完成: 共{len(result_image_files)}张图片")
            
            logger.info(f"信息处理完成，处理了{len(image_files)}张图片")
            
        except Exception as e:
            logger.error(f"信息处理失败: {e}")
            await self.send_error(websocket, "信息处理失败")
    
    # ------- 上传成功确认阶段 -------
    async def handle_inbound_upload_success(self, websocket, data):
        """处理上传成功确认：标记数据已同步到手机端"""
        try:
            # 调用mark_as_synced标记刚才上传的食品
            from ..database.data_manager import DatabaseManager
            data_manager = DatabaseManager()
            
            # 标记为已同步
            import config
            # 根据rfid_list查询food_id，然后标记为已同步
            rfid_list = config.db_data_list.get('rfid_list', '')
            if rfid_list:
                # 从rfid_list中取第一个rfid来查询food_id
                first_rfid = rfid_list.split(',')[0].strip()
                food_id = data_manager.get_food_id_by_rfid_id(first_rfid)
                if food_id:
                    data_manager.mark_as_synced(food_id)
            
            # 发送：上传成功确认消息
            await self.send_response(websocket, MessageTypes.INBOUND_UPLOAD_SUCCESS, ActionTypes.SUCCESS, {
                'status': StatusTypes.UPLOAD_SUCCESS
            })
            
            logger.info("上传成功确认处理完成")
            
        except Exception as e:
            logger.error(f"上传成功确认处理失败: {e}")
            await self.send_error(websocket, "上传成功确认处理失败")
    
    # ------- 入库结束阶段 -------
    async def handle_inbound_end(self, websocket, data):
        """处理入库结束：清空临时数据，完成入库流程"""
        try:
            # 1. 清空字典db_data_list和food_number
            import config
            config.db_data_list.clear()
            config.food_number = 1
            
            # 2. 清理两个图片文件夹
            from config import IMAGES_TEMP_DIR, IMAGES_RETURN_DIR
            import os
            
            # 清理images_tempt目录中的所有图片
            cleaned_temp_count = 0
            if IMAGES_TEMP_DIR.exists():
                for file_path in IMAGES_TEMP_DIR.iterdir():
                    if file_path.is_file() and file_path.suffix.lower() in ['.jpg', '.jpeg', '.png', '.bmp', '.tiff']:
                        try:
                            file_path.unlink()
                            cleaned_temp_count += 1
                        except Exception as e:
                            logger.error(f"删除images_tempt图片失败: {file_path.name}, 错误: {e}")
            
            # 清理images_return目录中的所有图片
            cleaned_return_count = 0
            if IMAGES_RETURN_DIR.exists():
                for file_path in IMAGES_RETURN_DIR.iterdir():
                    if file_path.is_file() and file_path.suffix.lower() in ['.jpg', '.jpeg', '.png', '.bmp', '.tiff']:
                        try:
                            file_path.unlink()
                            cleaned_return_count += 1
                        except Exception as e:
                            logger.error(f"删除images_return图片失败: {file_path.name}, 错误: {e}")
            
            # 检查是否有保质期信息不完整的食品，并添加通知
            await self._check_and_add_incomplete_shelf_life_notifications()
            
            # 清理RFID资源，释放串口
            if hasattr(self, 'rfid_in_manager') and self.rfid_in_manager:
                try:
                    self.rfid_in_manager.cleanup()
                    logger.info("RFID入库资源已清理，串口已释放")
                except Exception as e:
                    logger.error(f"RFID入库资源清理失败: {e}")
                finally:
                    self.rfid_in_manager = None
            
            # 发送：入库结束成功消息
            await self.send_response(websocket, MessageTypes.INBOUND_END, ActionTypes.SUCCESS, {
                'status': StatusTypes.END_SUCCESS
            })
            
            logger.info(f"入库流程结束，临时数据已清空，清理了{cleaned_temp_count}个临时图片和{cleaned_return_count}个结果图片")
            
        except Exception as e:
            logger.error(f"入库结束处理失败: {e}")
            await self.send_error(websocket, "入库结束处理失败")

    # ------- 中止入库阶段 -------
    async def handle_inbound_cancel(self, websocket, data):
        """处理中止入库：中断当前入库流程，清理所有临时数据"""
        try:
            # 1. 停止当前正在进行的操作
            # 停止RFID读取（如果正在读取）
            if self.rfid_in_manager:
                self.rfid_in_manager.cancel_reading()
                logger.info("已停止RFID读取")
            
            # 停止OCR处理（如果正在处理）
            self.ocr_cancel_requested = True
            logger.info("已停止OCR处理")
            
            # 2. 硬件状态重置
            # 关闭所有LED和蜂鸣器
            if hasattr(self, 'rfid_in_manager') and self.rfid_in_manager:
                if hasattr(self.rfid_in_manager, 'hardware_manager'):
                    self.rfid_in_manager.hardware_manager.control_led('green_off')
                    self.rfid_in_manager.hardware_manager.control_led('red_off')
                    self.rfid_in_manager.hardware_manager.control_led('blue_off')
                    logger.info("已关闭所有LED")
            
            # 3. 清理临时数据
            import config
            config.db_data_list.clear()
            config.food_number = 1
            logger.info("已清理临时数据")
            
            # 4. 清理两个图片文件夹
            from config import IMAGES_TEMP_DIR, IMAGES_RETURN_DIR
            
            # 清理images_tempt目录中的所有图片
            cleaned_temp_count = 0
            if IMAGES_TEMP_DIR.exists():
                for file_path in IMAGES_TEMP_DIR.iterdir():
                    if file_path.is_file() and file_path.suffix.lower() in ['.jpg', '.jpeg', '.png', '.bmp', '.tiff']:
                        try:
                            file_path.unlink()
                            cleaned_temp_count += 1
                        except Exception as e:
                            logger.error(f"删除images_tempt图片失败: {file_path.name}, 错误: {e}")
            
            # 清理images_return目录中的所有图片
            cleaned_return_count = 0
            if IMAGES_RETURN_DIR.exists():
                for file_path in IMAGES_RETURN_DIR.iterdir():
                    if file_path.is_file() and file_path.suffix.lower() in ['.jpg', '.jpeg', '.png', '.bmp', '.tiff']:
                        try:
                            file_path.unlink()
                            cleaned_return_count += 1
                        except Exception as e:
                            logger.error(f"删除images_return图片失败: {file_path.name}, 错误: {e}")
            
            logger.info(f"已清理{cleaned_temp_count}个临时图片和{cleaned_return_count}个结果图片")
            
            # 5. 清理RFID资源，释放串口
            if hasattr(self, 'rfid_in_manager') and self.rfid_in_manager:
                try:
                    self.rfid_in_manager.cleanup()
                    logger.info("RFID入库资源已清理，串口已释放")
                except Exception as e:
                    logger.error(f"RFID入库资源清理失败: {e}")
                finally:
                    self.rfid_in_manager = None
            
            # 6. 发送中止成功消息
            # 发送：中止入库成功消息，包含中止状态
            await self.send_response(websocket, MessageTypes.INBOUND_CANCEL, ActionTypes.SUCCESS, {
                'status': StatusTypes.CANCELLED,
                'message': '入库流程已中止'
            })
            
            logger.info("入库流程已中止，所有资源已清理")
            
        except Exception as e:
            logger.error(f"中止入库处理失败: {str(e)}")
            await self.send_error(websocket, "中止入库失败")

    # ==================== 系统功能 ====================
    # 食品列表相关功能基于本地存储管理
    
    
    async def _check_and_add_incomplete_shelf_life_notifications(self):
        """检查并添加保质期信息不完整的通知"""
        try:
            from ..database.data_manager import DatabaseManager
            data_manager = DatabaseManager()
            
            # 获取最近入库的食品（通过rfid_list查找）
            import config
            current_rfid_list = config.db_data_list.get('rfid_list', '')
            if not current_rfid_list:
                logger.debug("没有RFID列表，跳过保质期检查")
                return
            
            # 获取所有食品，然后筛选出匹配RFID的食品
            all_foods = data_manager.get_all_foods()
            matching_foods = []
            for food in all_foods:
                food_rfid_list = food.get('rfid_list', '')
                if food_rfid_list and any(rfid in food_rfid_list for rfid in current_rfid_list.split(',')):
                    matching_foods.append(food)
            
            incomplete_foods = []
            for food in matching_foods:
                # 检查保质期信息是否完整
                expiry_info = self._calculate_expiry_info(food)
                if expiry_info.get('is_incomplete', False):
                    incomplete_foods.append(food.get('name', '未知食品'))
            
            # 如果有保质期信息不完整的食品，记录日志
            if incomplete_foods:
                notification_message = f"{', '.join(incomplete_foods)} 保质期相关信息不完整，请及时注意是否过期"
                logger.warning(f"保质期信息不完整: {notification_message}")
            
        except Exception as e:
            logger.error(f"检查保质期信息失败: {e}")
    

    # ==================== 出库流程 ====================
    
    async def broadcast_outbound_notification(self, action, notification_data):
        """广播出库通知消息（树莓派主动推送）"""
        try:
            await self.broadcast_message(
                MessageTypes.OUTBOUND_NOTIFICATION,
                action,
                notification_data
            )
            logger.info(f"出库通知广播成功: action={action}, data={notification_data}")
        except Exception as e:
            logger.error(f"广播出库通知失败: {e}")

    def save_ocr_result_to_temp_file(self, ocr_result):
        """保存OCR结果到临时文件，防止连接断开导致数据丢失"""
        try:
            import os
            from pathlib import Path
            
            # 创建临时文件目录
            temp_dir = Path(__file__).parent.parent.parent / "temp_data"
            temp_dir.mkdir(exist_ok=True)
            
            # 生成临时文件名
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            temp_file = temp_dir / f"ocr_result_{timestamp}.json"
            
            # 保存OCR结果
            with open(temp_file, 'w', encoding='utf-8') as f:
                json.dump(ocr_result, f, ensure_ascii=False, indent=2)
            
            logger.info(f"OCR结果已保存到临时文件: {temp_file}")
            
            # 清理旧的临时文件（保留最近5个）
            self.cleanup_old_temp_files(temp_dir)
            
        except Exception as e:
            logger.error(f"保存OCR结果到临时文件失败: {e}")
    
    def cleanup_old_temp_files(self, temp_dir, keep_count=5):
        """清理旧的临时文件"""
        try:
            import glob
            import os
            
            # 获取所有OCR结果临时文件
            temp_files = glob.glob(str(temp_dir / "ocr_result_*.json"))
            temp_files.sort(key=os.path.getmtime, reverse=True)
            
            # 删除超出保留数量的文件
            for temp_file in temp_files[keep_count:]:
                os.remove(temp_file)
                logger.debug(f"已清理旧临时文件: {temp_file}")
                
        except Exception as e:
            logger.error(f"清理旧临时文件失败: {e}")
    


# ==================== 全局服务器实例 ====================
# 全局WebSocket服务器实例，供其他模块调用
_global_websocket_server = None

def get_websocket_server():
    """获取全局WebSocket服务器实例"""
    return _global_websocket_server

def set_websocket_server(server):
    """设置全局WebSocket服务器实例"""
    global _global_websocket_server
    _global_websocket_server = server

def broadcast_outbound_notification_sync(action, notification_data):
    """同步广播出库通知消息（供RFID模块调用）"""
    global _global_websocket_server
    if _global_websocket_server is None:
        logger.warning("WebSocket服务器未初始化，无法发送出库通知")
        return False
    
    try:
        # 使用线程安全的方式发送WebSocket消息
        # 将消息放入队列，由主线程的WebSocket服务器处理
        if hasattr(_global_websocket_server, 'message_queue'):
            _global_websocket_server.message_queue.put({
                'type': 'outbound_notification',
                'action': action,
                'data': notification_data
            })
            logger.info(f"出库通知已加入队列: action={action}, data={notification_data}")
            return True
        else:
            # 如果没有消息队列，尝试直接调用（可能失败）
            try:
                loop = asyncio.get_running_loop()
                # 如果事件循环正在运行，创建任务
                asyncio.create_task(_global_websocket_server.broadcast_outbound_notification(action, notification_data))
                logger.info(f"出库通知已安排发送: action={action}, data={notification_data}")
                return True
            except RuntimeError:
                # 当前线程没有运行的事件循环，尝试获取主线程的事件循环
                try:
                    loop = asyncio.get_event_loop()
                    if loop.is_running():
                        # 如果主线程事件循环正在运行，创建任务
                        asyncio.create_task(_global_websocket_server.broadcast_outbound_notification(action, notification_data))
                    else:
                        # 如果主线程事件循环未运行，直接运行
                        loop.run_until_complete(_global_websocket_server.broadcast_outbound_notification(action, notification_data))
                    logger.info(f"出库通知已安排发送: action={action}, data={notification_data}")
                    return True
                except Exception as e:
                    logger.error(f"获取事件循环失败: {e}")
                    return False
            except Exception as e:
                # 无法获取事件循环，记录警告但不报错
                logger.error(f"发送出库通知失败: {e}")
                return False
        

    except Exception as e:
        logger.error(f"发送出库通知失败: {e}")
        return False

# ==================== HTTP服务器部分 ====================
class SimpleWebServer:
    """简单的HTTP服务器，用于提供网页文件"""
    
    def __init__(self):
        self.app = web.Application()
        # 添加中间件处理静态文件缓存
        self.app.middlewares.append(self.cache_control_middleware)
        self.setup_routes()
    
    @web.middleware
    async def cache_control_middleware(self, request, handler):
        """缓存控制中间件"""
        response = await handler(request)
        
        # 为静态文件设置缓存控制
        if request.path.startswith('/static/') or request.path.startswith('/js/') or request.path.startswith('/css/'):
            # 静态文件设置短期缓存（5分钟），避免频繁请求
            response.headers['Cache-Control'] = 'public, max-age=300'
        elif request.path.startswith('/images/'):
            # 图片文件设置较长期缓存（1小时）
            response.headers['Cache-Control'] = 'public, max-age=3600'
        else:
            # 其他文件不缓存
            response.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
            response.headers['Pragma'] = 'no-cache'
            response.headers['Expires'] = '0'
        
        return response
    
    def setup_routes(self):
        """设置路由"""
        # 静态文件服务 - 支持多种路径
        self.app.router.add_static('/static/', path=WEB_DIR, name='static')
        self.app.router.add_static('/images/', path=WEB_DIR / 'images', name='images')
        self.app.router.add_static('/css/', path=WEB_DIR / 'css', name='css')
        self.app.router.add_static('/js/', path=WEB_DIR / 'js', name='js')
        
        # 主页路由
        self.app.router.add_get('/', self.index_handler)
        
        # 健康检查
        self.app.router.add_get('/health', self.health_handler)
    
    async def index_handler(self, request):
        """处理主页请求"""
        index_file = WEB_DIR / "index.html"
        if index_file.exists():
            response = web.FileResponse(index_file)
            # 设置HTML文件不缓存，确保总是获取最新版本
            response.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
            response.headers['Pragma'] = 'no-cache'
            response.headers['Expires'] = '0'
            return response
        else:
            return web.Response(text="网页文件未找到", status=404)
    
    async def health_handler(self, request):
        """健康检查"""
        return web.json_response({"status": "ok", "service": "smart-food-cabinet-web"})
    
    async def start(self):
        """启动HTTP服务器"""
        runner = web.AppRunner(self.app)
        await runner.setup()
        site = web.TCPSite(runner, HOST, HTTP_PORT)
        await site.start()
        logger.info(f"HTTP服务器已启动，监听端口 {HTTP_PORT}")
        logger.info(f"网页访问地址: http://{HOST}:{HTTP_PORT}")
        return runner

# ==================== 集成服务器启动 ====================
async def start_web_server():
    """启动HTTP服务器"""
    web_server = SimpleWebServer()
    runner = await web_server.start()
    return runner

async def start_websocket_and_web_server():
    """同时启动WebSocket和HTTP服务器"""
    # 启动HTTP服务器
    web_runner = await start_web_server()
    
    # 启动WebSocket服务器
    websocket_server = SmartFoodCabinetWebSocketServer()
    set_websocket_server(websocket_server)
    
    # 启动消息队列处理任务
    message_task = asyncio.create_task(websocket_server.process_message_queue())
    
    # 启动WebSocket服务器，配置心跳以处理长时间操作
    async with websockets.serve(
        websocket_server.handler, 
        HOST, 
        PORT,
        ping_interval=60,  # 心跳间隔60秒（避免与客户端15秒心跳冲突）
        ping_timeout=30    # 心跳超时30秒
    ):
        logger.info(f"WebSocket服务器已启动，监听端口 {PORT}")
        logger.info("等待客户端连接...")
        
        # 保持服务器运行
        try:
            await asyncio.Future()  # 创建一个永远不会完成的Future
        except KeyboardInterrupt:
            logger.info("正在关闭服务器...")
        finally:
            await web_runner.cleanup()

# 程序入口点
if __name__ == "__main__":
    """主函数：启动WebSocket和HTTP服务器"""
    try:
        # 运行集成服务器
        asyncio.run(start_websocket_and_web_server())
    except KeyboardInterrupt:
        # 处理用户按Ctrl+C中断程序的情况
        logger.info("服务器已关闭")