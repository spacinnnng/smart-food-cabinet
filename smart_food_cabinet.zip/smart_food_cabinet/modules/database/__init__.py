#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
数据库管理模块
包含数据库操作和管理的核心功能
"""

from .data_manager import DatabaseManager

__all__ = ['DatabaseManager']
