# -*- coding: utf-8 -*-
"""
数据库管理模块
功能：创建数据库、表结构，提供基础操作方法
"""

import sqlite3
import os
import logging
from datetime import datetime
from typing import Dict, List, Optional, Any
import sys

# 添加项目根目录到Python路径，以便导入config模块
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

# 配置日志
# 注意：日志配置由主程序统一管理，这里只需要创建logger实例
logger = logging.getLogger(__name__)

class DatabaseManager:
    """数据库管理类"""
    
    def __init__(self, db_path: str = None):
        """
        初始化数据库管理器
        
        Args:
            db_path: 数据库文件路径
        """
        # 如果没有指定路径，使用配置中的默认路径
        if db_path is None:
            from config import DATABASE_PATH
            self.db_path = DATABASE_PATH
        else:
            self.db_path = db_path
            
        self.conn = None
        self.cursor = None
        
        # 初始化数据库
        self.init_database()
    
    def init_database(self):
        """初始化数据库和表结构"""
        try:
            # 连接数据库，启用线程安全模式
            self.conn = sqlite3.connect(
                self.db_path, 
                check_same_thread=False,  # 允许跨线程使用
                timeout=30.0  # 设置超时时间
            )
            # 启用WAL模式，提高并发性能
            self.conn.execute('PRAGMA journal_mode=WAL')
            self.cursor = self.conn.cursor()
            
            # 创建食品信息表
            self.create_food_table()
            
            logger.info("数据库初始化成功")
            
        except Exception as e:
            logger.error(f"数据库初始化失败: {e}")
            raise
    
    def create_food_table(self):
        """创建食品信息表"""
        create_table_sql = """
        CREATE TABLE IF NOT EXISTS food_info (
            food_id INTEGER PRIMARY KEY AUTOINCREMENT, 
            rfid_list TEXT NOT NULL,
            name TEXT,
            food_number INTEGER,
            production_date TEXT,
            shelf_life_year INTEGER,
            shelf_life_month INTEGER,
            shelf_life_day INTEGER,
            expire_date TEXT,
            net_value REAL,
            net_unit TEXT,
            calorie_per_unit REAL,
            protein_per_unit REAL,
            fat_per_unit REAL,
            carbo_per_unit REAL,
            sugar_per_unit REAL,
            sodium_per_unit REAL,
            gluten_valid INTEGER DEFAULT 0,
            cara_valid INTEGER DEFAULT 0,
            fish_valid INTEGER DEFAULT 0,
            egg_valid INTEGER DEFAULT 0,
            peanut_valid INTEGER DEFAULT 0,
            soy_valid INTEGER DEFAULT 0,
            dairy_valid INTEGER DEFAULT 0,
            nut_valid INTEGER DEFAULT 0,
            category TEXT,
            storage_date TEXT NOT NULL,
            is_synced INTEGER DEFAULT 0
        )
        """
        
        try:
            self.cursor.execute(create_table_sql)
            self.conn.commit()
            logger.info("食品信息表创建成功")
            
        except Exception as e:
            logger.error(f"创建表失败: {e}")
            raise
    

    
    def save_food_info(self, food_data: Dict[str, Any]) -> int:
        """
        保存食品信息到数据库
        
        Args:
            food_data: 食品信息字典
            
        Returns:
            food_id: 新插入记录的ID
        """
        try:
            # 设置默认值
            food_data.setdefault('storage_date', datetime.now().strftime('%Y-%m-%d'))
            food_data.setdefault('is_synced', 0)
            
            # 验证rfid_list是否存在
            if 'rfid_list' not in food_data or not food_data['rfid_list']:
                raise ValueError("RFID列表缺失，无法创建数据库记录")
            
            # 构建SQL语句
            fields = list(food_data.keys())
            placeholders = ', '.join(['?' for _ in fields])
            values = list(food_data.values())
            
            # 调试信息：打印字段名
            logger.info(f"准备保存的字段: {fields}")
            logger.info(f"准备保存的数据: {food_data}")
            
            # 检查数据库表结构
            self.cursor.execute("PRAGMA table_info(food_info)")
            table_info = self.cursor.fetchall()
            table_columns = [row[1] for row in table_info]
            logger.info(f"数据库表实际字段: {table_columns}")
            
            sql = f"""
            INSERT INTO food_info ({', '.join(fields)})
            VALUES ({placeholders})
            """
            
            self.cursor.execute(sql, values)
            self.conn.commit()
            
            food_id = self.cursor.lastrowid
            logger.info(f"食品信息保存成功，ID: {food_id}, rfid_list: {food_data['rfid_list']}")
            
            return food_id
            
        except Exception as e:
            logger.error(f"保存食品信息失败: {e}")
            raise
    
    def get_food_id_by_rfid_id(self, rfid_id: str) -> Optional[int]:
        """
        根据rfid_id查询食品ID - 修复版本
        使用精确匹配，避免子字符串问题，并处理多个匹配记录的情况
        
        Args:
            rfid_id: 食品的rfid_id
            
        Returns:
            food_id: 食品ID，如果不存在返回None
        """
        try:
            # 使用精确匹配，避免LIKE查询的子字符串问题
            sql = """
            SELECT food_id, rfid_list FROM food_info 
            WHERE rfid_list = ? OR 
                  rfid_list LIKE ? OR 
                  rfid_list LIKE ? OR 
                  rfid_list LIKE ?
            ORDER BY food_id DESC
            """
            
            # 构建精确的匹配模式
            patterns = [
                rfid_id,  # 完全匹配
                f"{rfid_id},%",  # 开头匹配
                f"%,{rfid_id},%",  # 中间匹配
                f"%,{rfid_id}"  # 结尾匹配
            ]
            
            self.cursor.execute(sql, patterns)
            rows = self.cursor.fetchall()
            
            if not rows:
                logger.info(f"未找到食品: rfid_id={rfid_id}")
                return None
            
            # 如果有多个匹配，选择最新的记录（food_id最大的）
            if len(rows) > 1:
                logger.warning(f"发现多个匹配记录: {rows}，选择最新的记录")
            
            food_id = rows[0][0]  # 选择第一个（最新的）记录
            logger.info(f"查询到食品ID: {food_id}, rfid_id={rfid_id}")
            return food_id
            
        except Exception as e:
            logger.error(f"根据rfid_id查询食品ID失败: {e}")
            raise
    
    def delete_food(self, food_id: int, rfid_id: str) -> bool:
        """
        从食品的RFID ID列表中删除指定的RFID ID - 修复版本
        使用更精确的删除逻辑，避免字符串替换问题
        
        Args:
            food_id: 食品ID
            rfid_id: 要删除的RFID ID
            
        Returns:
            是否删除成功
        """
        try:
            # 查询食品信息是否存在
            sql = "SELECT rfid_list FROM food_info WHERE food_id = ?"
            self.cursor.execute(sql, (food_id,))
            result = self.cursor.fetchone()
            
            if not result:
                logger.warning(f"未找到food_id {food_id} 对应的食品信息")
                return False
            
            current_rfid_list = result[0]
            
            # 将RFID列表转换为列表，进行精确删除
            rfid_items = [item.strip() for item in current_rfid_list.split(',') if item.strip()]
            
            if rfid_id not in rfid_items:
                logger.warning(f"RFID ID {rfid_id} 不在食品ID {food_id} 的RFID列表中")
                return False
            
            # 从列表中删除指定的RFID ID
            rfid_items.remove(rfid_id)
            new_rfid_list = ','.join(rfid_items)
            
            # 更新数据库
            sql = "UPDATE food_info SET rfid_list = ? WHERE food_id = ?"
            self.cursor.execute(sql, (new_rfid_list, food_id))
            self.conn.commit()
            
            logger.info(f"从食品ID {food_id} 中删除RFID ID {rfid_id}，剩余RFID: {new_rfid_list}")
            return True
                
        except Exception as e:
            logger.error(f"删除RFID ID失败: {e}")
            self.conn.rollback()
            raise
    
    def mark_as_synced(self, food_id: int) -> bool:
        """
        标记食品信息为已同步状态
        
        Args:
            food_id: 食品ID
            
        Returns:
            是否标记成功
        """
        try:
            sql = "UPDATE food_info SET is_synced = 1 WHERE food_id = ?"
            self.cursor.execute(sql, (food_id,))
            self.conn.commit()
            
            if self.cursor.rowcount > 0:
                logger.info(f"食品同步状态标记成功，ID: {food_id}")
                return True
            else:
                logger.warning(f"未找到要标记的食品，ID: {food_id}")
                return False
                
        except Exception as e:
            logger.error(f"标记同步状态失败: {e}")
            raise
    
    def close(self):
        """关闭数据库连接"""
        if self.conn:
            self.conn.close()
            logger.info("数据库连接已关闭")
    
    def __enter__(self):
        """上下文管理器入口"""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """上下文管理器出口"""
        self.close()


# ==================== 项目未使用的函数（保留以备将来扩展）====================

    def update_food_info(self, food_id: int, update_data: Dict[str, Any]) -> bool:
        """
        更新食品信息
        
        注意：当前版本未使用此函数，保留以备将来扩展使用
        未来可能需要用于：修改食品价格、更新保质期、标记同步状态、管理员手动修改信息等
        
        Args:
            food_id: 食品ID
            update_data: 更新的数据
            
        Returns:
            是否更新成功
        """
        try:
            # 构建更新SQL
            set_clause = ', '.join([f"{field} = ?" for field in update_data.keys()])
            values = list(update_data.values()) + [food_id]
            
            sql = f"""
            UPDATE food_info 
            SET {set_clause}
            WHERE food_id = ?
            """
            
            self.cursor.execute(sql, values)
            self.conn.commit()
            
            if self.cursor.rowcount > 0:
                logger.info(f"食品信息更新成功，ID: {food_id}")
                return True
            else:
                logger.warning(f"未找到要更新的食品，ID: {food_id}")
                return False
                
        except Exception as e:
            logger.error(f"更新食品信息失败: {e}")
            raise

    def get_unsynced_foods(self) -> List[Dict[str, Any]]:
        """
        获取所有未同步的食品信息
        用于查缺补漏
        注意：当前版本未使用此函数，保留以备将来扩展使用
        
        Returns:
            未同步食品信息列表
        """
        try:
            sql = """
            SELECT * FROM food_info 
            WHERE is_synced = 0
            ORDER BY food_id ASC
            """
            
            self.cursor.execute(sql)
            rows = self.cursor.fetchall()
            
            # 转换为字典列表
            columns = [description[0] for description in self.cursor.description]
            foods = [dict(zip(columns, row)) for row in rows]
            
            logger.info(f"查询到 {len(foods)} 条未同步的食品记录")
            return foods
            
        except Exception as e:
            logger.error(f"查询未同步食品信息失败: {e}")
            raise

    def get_all_foods(self) -> List[Dict[str, Any]]:
        """
        获取所有食品信息
        
        Returns:
            所有食品信息列表
        """
        try:
            sql = """
            SELECT * FROM food_info 
            ORDER BY food_id DESC
            """
            
            self.cursor.execute(sql)
            rows = self.cursor.fetchall()
            
            # 转换为字典列表
            foods = []
            for row in rows:
                food_dict = dict(zip([col[0] for col in self.cursor.description], row))
                foods.append(food_dict)
            
            logger.info(f"成功获取 {len(foods)} 条食品信息")
            return foods
            
        except Exception as e:
            logger.error(f"查询所有食品信息失败: {e}")
            raise

    def cleanup_empty_food_records(self) -> int:
        """
        清理空的食品记录（rfid_list为空的记录）
        用于清理出库后剩余的无效记录
        
        Returns:
            清理的记录数量
        """
        try:
            sql = "DELETE FROM food_info WHERE rfid_list IS NULL OR rfid_list = '' OR rfid_list = ','"
            self.cursor.execute(sql)
            deleted_count = self.cursor.rowcount
            self.conn.commit()
            
            if deleted_count > 0:
                logger.info(f"清理了 {deleted_count} 条空的食品记录")
            
            return deleted_count
            
        except Exception as e:
            logger.error(f"清理空记录失败: {e}")
            self.conn.rollback()
            raise


# ==================== 测试函数 ====================

if __name__ == "__main__":
    """测试函数 - 测试数据库管理器的核心功能"""
    print("🚀 开始测试数据库管理器...")
    
    # 使用上下文管理器创建数据库管理器
    with DatabaseManager() as db_manager:
        try:
            test_food_data = {
                'rfid_list': '1372,13421,132134',
                'name': '乐事薯片(原味)',
                'food_number': 3,
                'production_date': '2024-01-01',
                'shelf_life_year': 0,
                'shelf_life_month': 6,
                'shelf_life_day': 0,
                'expire_date': '2024-07-01',
                'net_value': 70.0,
                'net_unit': 'g',
                'calorie_per_unit': 1500.0,
                'protein_per_unit': 2.0,
                'fat_per_unit': 8.0,
                'carbo_per_unit': 15.0,
                'sugar_per_unit': 1.0,
                'sodium_per_unit': 150.0,
                'gluten_valid': 0,
                'cara_valid': 0,
                'fish_valid': 0,
                'egg_valid': 0,
                'peanut_valid': 0,
                'soy_valid': 0,
                'dairy_valid': 0,
                'nut_valid': 0,
                'category': 'food'
            }
            # 测试1: 保存食品信息
            print("\n📝 测试1: 保存食品信息")
            food_id = db_manager.save_food_info(test_food_data)
            print(f"✅ 食品信息保存成功，ID: {food_id}")
            
            # 测试2: 根据RFID ID查询食品ID
            print("\n🔍 测试2: 根据RFID ID查询食品ID")
            found_food_id = db_manager.get_food_id_by_rfid_id('1372')
            if found_food_id:
                print(f"✅ 查询成功，食品ID: {found_food_id}")
            else:
                print("❌ 查询失败")
            
            # 测试3: 标记为已同步
            print("\n🔄 测试3: 标记为已同步")
            if db_manager.mark_as_synced(food_id):
                print(f"✅ 标记为已同步成功，ID: {food_id}")
            else:
                print("❌ 标记为已同步失败")
            
            # 测试4: 删除特定RFID ID
            print("\n🗑️ 测试4: 删除特定RFID ID")
            if db_manager.delete_food(food_id, '1372'):
                print(f"✅ 删除RFID ID '1372' 成功，食品ID: {food_id}")
            else:
                print("❌ 删除RFID ID失败")
            
            # 测试5: 验证删除后的状态
            print("\n🔍 测试5: 验证删除后的状态")
            deleted_food_id = db_manager.get_food_id_by_rfid_id('1372')
            if deleted_food_id is None:
                print("✅ 删除验证成功，无法查询到已删除的RFID ID")
            else:
                print("❌ 删除验证失败，仍能查询到已删除的RFID ID")
            
        except Exception as e:
            print(f"❌ 测试过程中发生异常: {e}")
            import traceback
            traceback.print_exc()
