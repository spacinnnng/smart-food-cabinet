#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
智能食品柜核心模块包
包含硬件管理、RFID、数据库、Web API、信息处理等核心功能模块
"""

from .database import DatabaseManager
from .websocket import SmartFoodCabinetWebSocketServer
from .info_processor import FoodDrinkDetector, TableDateDetector

# 树莓派专用模块使用延迟导入，避免在Mac上导入失败
def get_hardware_manager():
    """延迟导入HardwareManager，避免在Mac上导入RPi.GPIO失败"""
    try:
        from .hardware import HardwareManager
        return HardwareManager
    except ImportError as e:
        if "RPi" in str(e):
            print("检测到RPi.GPIO导入错误")
            print("提示：HardwareManager模块需要在树莓派上运行，Mac上无法运行")
            return None
        else:
            raise e

def get_rfid_modules():
    """延迟导入RFID模块，避免在Mac上导入RPi.GPIO失败"""
    try:
        from .rfid import get_rfid_modules as rfid_getter
        return rfid_getter()
    except ImportError as e:
        if "RPi" in str(e):
            print("检测到RPi.GPIO导入错误")
            print("提示：RFID模块需要在树莓派上运行，Mac上无法运行")
            return None, None
        else:
            raise e

__all__ = [
    'DatabaseManager',
    'SmartFoodCabinetWebSocketServer',
    'FoodDrinkDetector',
    'TableDateDetector',
    'get_hardware_manager',
    'get_rfid_modules'
]
