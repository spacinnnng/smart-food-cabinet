#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
腾讯云OCR处理器 (Tencent OCR Processor)
使用腾讯云OCR服务对食品包装图片进行文字识别和信息提取。
"""

import os
import json
import sys
import base64
from tencentcloud.common import credential
from tencentcloud.common.profile.client_profile import ClientProfile
from tencentcloud.common.profile.http_profile import HttpProfile
from tencentcloud.ocr.v20181119 import ocr_client, models

# 添加项目根目录到Python路径，以便导入其他模块
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

from .field_mapper import FIELD_OCR_KEYS, MAPPER_TO_DB_FIELD, map_ocr_to_db
import logging
logger = logging.getLogger(__name__)

# 从config模块导入配置
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
from config import IMAGES_TEMP_DIR
from config import SECRET_ID, SECRET_KEY, OCR_ENDPOINT, DEBUG_MODE, db_data_list
from config import cleanup_error_images

# OCR请求函数
def call_tencent_ocr(image_base64):
    """
    调用腾讯云OCR接口，返回原始JSON
    """
    logger.debug("🔍 [DEBUG] 开始调用腾讯云OCR API...")
    
    try:
        logger.debug(f"🔍 [DEBUG] SECRET_ID: {SECRET_ID[:10]}..." if SECRET_ID else "❌ [ERROR] SECRET_ID未设置")
        logger.debug(f"🔍 [DEBUG] SECRET_KEY: {SECRET_KEY[:10]}..." if SECRET_KEY else "❌ [ERROR] SECRET_KEY未设置")
        logger.debug(f"🔍 [DEBUG] OCR_ENDPOINT: {OCR_ENDPOINT}")
        
        cred = credential.Credential(SECRET_ID, SECRET_KEY)
        logger.debug("🔍 [DEBUG] 凭证创建成功")
        
        httpProfile = HttpProfile()
        httpProfile.endpoint = OCR_ENDPOINT
        httpProfile.timeout = 90  # 增加超时时间到90秒，确保有足够时间处理
        logger.debug("🔍 [DEBUG] HTTP配置完成")
        
        clientProfile = ClientProfile()
        clientProfile.httpProfile = httpProfile
        client = ocr_client.OcrClient(cred, "", clientProfile)
        logger.debug("🔍 [DEBUG] OCR客户端创建成功")
        
        # 自动生成 item_names - 包含FIELD_OCR_KEYS中的所有关键词（已包含MAPPER_TO_DB_FIELD中的字段）
        item_names = list({k for norm_field in FIELD_OCR_KEYS.keys() for k in FIELD_OCR_KEYS.get(norm_field, [])})
        logger.debug(f"🔍 [DEBUG] 识别的字段名称: {item_names}")
        
        params = {
            "ImageBase64": image_base64,
            "ItemNames": item_names,
            "ItemNamesShowMode": True,
            "ReturnFullText": False,
            "ConfigId": "General",
            "EnableCoord": False,
            "OutputParentKey": False,
            "ConfigAdvanced": {"Scene": "only_hw"},
            "OutputLanguage": "cn"
        }
        logger.debug("🔍 [DEBUG] 请求参数准备完成")
        
        req = models.ExtractDocMultiRequest()
        req.from_json_string(json.dumps(params))
        logger.debug("🔍 [DEBUG] 请求对象创建成功")
        
        logger.debug("🔍 [DEBUG] 发送OCR请求...")
        resp = client.ExtractDocMulti(req)
        logger.debug("🔍 [DEBUG] OCR请求成功，解析响应...")
        
        result = json.loads(resp.to_json_string())
        logger.debug(f"🔍 [DEBUG] OCR响应解析成功，数据长度: {len(str(result))}")
        
        return result
        
    except Exception as e:
        logger.debug(f"❌ [ERROR] OCR调用失败: {e}")
        import traceback
        logger.debug(f"❌ [ERROR] 详细错误信息: {traceback.format_exc()}")
        raise


def process_images_to_db_data():
    """
    处理images_tempt文件夹中的图片，进行OCR识别，合并结果后填充到全局db_data_list
    返回处理后的db_data_list
    """
    logger.debug("🔍 [DEBUG] 开始处理图片到数据库数据...")
    
    # 清理错误图片文件
    cleaned_count = cleanup_error_images()
    if cleaned_count > 0:
        logger.debug(f"🔍 [DEBUG] 已清理 {cleaned_count} 个错误图片文件")
    
    # 第一步：读取images_tempt文件夹中的图片
    image_dir = str(IMAGES_TEMP_DIR)
    image_files = []
    
    logger.debug(f"🔍 [DEBUG] 图片目录路径: {image_dir}")
    logger.debug(f"🔍 [DEBUG] 图片目录是否存在: {os.path.exists(image_dir)}")

    if not os.path.exists(image_dir):
        logger.debug(f"❌ [ERROR] 图片文件夹 {image_dir} 不存在！")
        return db_data_list
    
    # 获取所有图片文件，按文件名排序
    try:
        all_files = os.listdir(image_dir)
        logger.debug(f"🔍 [DEBUG] 目录中的所有文件: {all_files}")
        
        for filename in sorted(all_files):
            if filename.lower().endswith(('.jpg', '.jpeg', '.png')):
                # 只处理正常的文件（1.jpg-6.jpg），忽略下划线开头的文件
                if not filename.startswith('_'):
                    image_files.append(os.path.join(image_dir, filename))
                    logger.debug(f"🔍 [DEBUG] 找到图片文件: {filename}")
                else:
                    logger.debug(f"🔍 [DEBUG] 跳过下划线文件: {filename}")
    except Exception as e:
        logger.debug(f"❌ [ERROR] 读取目录失败: {e}")
        return db_data_list
    
    if not image_files:
        logger.debug(f"❌ [ERROR] 在 {image_dir} 文件夹中未找到图片文件！")
        return db_data_list
    
    logger.debug(f"✅ [SUCCESS] 找到 {len(image_files)} 张图片文件: {[os.path.basename(f) for f in image_files]}")
    
    # 第二步：OCR识别和数据处理
    logger.debug("🔍 [DEBUG] 开始OCR识别和数据处理...")
    
    for idx, image_file in enumerate(image_files):
        try:
            logger.debug(f"🔍 [DEBUG] 正在处理第{idx+1}张图片: {os.path.basename(image_file)}")
            
            # 读取图片文件并转换为base64
            logger.debug(f"🔍 [DEBUG] 读取图片文件...")
            with open(image_file, "rb") as f:
                image_data = f.read()
                image_base64 = base64.b64encode(image_data).decode()
            logger.debug(f"🔍 [DEBUG] 图片文件大小: {len(image_data)} 字节")
            logger.debug(f"🔍 [DEBUG] Base64编码长度: {len(image_base64)} 字符")
            
            # 调用OCR识别
            logger.debug(f"🔍 [DEBUG] 调用腾讯云OCR API...")
            ocr_json = call_tencent_ocr(image_base64)
            logger.debug(f"🔍 [DEBUG] 第{idx+1}张图片OCR原始返回：{json.dumps(ocr_json, ensure_ascii=False, indent=2)}")
            
            # 映射到数据库字段
            logger.debug(f"🔍 [DEBUG] 开始字段映射...")
            db_data = map_ocr_to_db(ocr_json)
            logger.debug(f"🔍 [DEBUG] 第{idx+1}张图片映射后结果：{db_data}")
            
            # 只用非空字段覆盖已有字段，合并到全局db_data_list
            logger.debug(f"🔍 [DEBUG] 合并数据到全局列表...")
            for key, value in db_data.items():
                if value not in [None, '', []]:
                    db_data_list[key] = value
                    logger.debug(f"🔍 [DEBUG] 添加字段: {key} = {value}")
                    
            logger.debug(f"🔍 [DEBUG] 第{idx+1}张图片合并后全局数据：{db_data_list}")
                
        except Exception as e:
            logger.debug(f"❌ [ERROR] 第{idx+1}张图片识别失败: {e}")
            import traceback
            logger.debug(f"❌ [ERROR] 详细错误信息: {traceback.format_exc()}")
    
    # 第三步：输出最终结果
    logger.debug("\n" + "=" * 60)
    logger.debug("第三步：最终处理结果")
    logger.debug("=" * 60)
    
    logger.debug(f"✅ [SUCCESS] OCR处理完成，共处理 {len(image_files)} 张图片")
    logger.debug(f"🔍 [DEBUG] 最终合并后的数据：{db_data_list}")
    
    return db_data_list


if __name__ == "__main__":
    """
    主函数：处理图片并输出结果
    """
    # 智能日志配置
    from config import setup_logging_if_needed
    setup_logging_if_needed()
    
    print("🚀 开始测试腾讯云OCR...")
    print("🔍 检查环境配置...")
    
    # 检查配置
    print(f"🔍 SECRET_ID: {'已设置' if SECRET_ID else '未设置'}")
    print(f"🔍 SECRET_KEY: {'已设置' if SECRET_KEY else '未设置'}")
    print(f"🔍 OCR_ENDPOINT: {OCR_ENDPOINT}")
    print(f"🔍 IMAGES_TEMP_DIR: {IMAGES_TEMP_DIR}")
    print(f"🔍 DEBUG_MODE: {DEBUG_MODE}")
    
    try:
        result = process_images_to_db_data()
        if result:
            print("✅ 数据处理完成")
            print(f"处理结果: {result}")
        else:
            print("❌ 数据处理失败 - 返回空结果")
    except Exception as e:
        print(f"❌ 数据处理失败 - 发生异常: {e}")
        import traceback
        print(f"❌ 详细错误信息: {traceback.format_exc()}")
