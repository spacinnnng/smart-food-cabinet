#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
腾讯云OCR处理器 (Tencent OCR Processor)
使用腾讯云OCR服务对食品包装图片进行文字识别和信息提取。
"""

import os
import json
import sys
import base64
from tencentcloud.common import credential
from tencentcloud.common.profile.client_profile import ClientProfile
from tencentcloud.common.profile.http_profile import HttpProfile
from tencentcloud.ocr.v20181119 import ocr_client, models

# 添加项目根目录到Python路径，以便导入其他模块
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

from .field_mapper import FIELD_OCR_KEYS, MAPPER_TO_DB_FIELD, map_ocr_to_db
import logging
logger = logging.getLogger(__name__)

# 从config模块导入配置
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
from config import IMAGES_TEMP_DIR
from config import SECRET_ID, SECRET_KEY, OCR_ENDPOINT, DEBUG_MODE, db_data_list
from config import cleanup_error_images

# OCR请求函数
def call_tencent_ocr(image_base64):
    """
    调用腾讯云OCR接口，返回原始JSON
    """
    logger.info("开始调用腾讯云OCR API")
    
    try:
        # 验证配置
        if not SECRET_ID or not SECRET_KEY:
            logger.error("腾讯云OCR配置不完整：SECRET_ID或SECRET_KEY未设置")
            return None
            
        cred = credential.Credential(SECRET_ID, SECRET_KEY)
        
        httpProfile = HttpProfile()
        httpProfile.endpoint = OCR_ENDPOINT
        httpProfile.timeout = 90  # 增加超时时间到90秒，确保有足够时间处理
        
        clientProfile = ClientProfile()
        clientProfile.httpProfile = httpProfile
        client = ocr_client.OcrClient(cred, "", clientProfile)
        
        # 自动生成 item_names - 包含FIELD_OCR_KEYS中的所有关键词
        item_names = list({k for norm_field in FIELD_OCR_KEYS.keys() for k in FIELD_OCR_KEYS.get(norm_field, [])})
        
        params = {
            "ImageBase64": image_base64,
            "ItemNames": item_names,
            "ItemNamesShowMode": True,
            "ReturnFullText": False,
            "ConfigId": "General",
            "EnableCoord": False,
            "OutputParentKey": False,
            "ConfigAdvanced": {"Scene": "only_hw"},
            "OutputLanguage": "cn"
        }
        
        req = models.ExtractDocMultiRequest()
        req.from_json_string(json.dumps(params))
        
        resp = client.ExtractDocMulti(req)
        
        result = json.loads(resp.to_json_string())
        logger.info(f"OCR识别完成，识别到 {len(result.get('TextDetections', []))} 个文本区域")
        
        return result
        
    except Exception as e:
        logger.error(f"OCR调用失败: {e}")
        raise


def process_images_to_db_data():
    """
    处理images_tempt文件夹中的图片，进行OCR识别，合并结果后填充到全局db_data_list
    返回处理后的db_data_list
    """
    logger.info("开始处理图片到数据库数据")
    
    # 清理错误图片文件
    cleaned_count = cleanup_error_images()
    if cleaned_count > 0:
        logger.info(f"已清理 {cleaned_count} 个错误图片文件")
    
    # 第一步：读取images_tempt文件夹中的图片
    image_dir = str(IMAGES_TEMP_DIR)
    image_files = []
    
    if not os.path.exists(image_dir):
        logger.error(f"图片目录不存在: {image_dir}")
        return False
    
    # 获取所有图片文件，按文件名排序
    try:
        all_files = os.listdir(image_dir)
        
        for filename in sorted(all_files):
            if filename.lower().endswith(('.jpg', '.jpeg', '.png')):
                # 只处理正常的文件（1.jpg-6.jpg），忽略下划线开头的文件
                if not filename.startswith('_'):
                    image_files.append(os.path.join(image_dir, filename))
    except Exception as e:
        logger.error(f"读取目录失败: {e}")
        return db_data_list
    
    if not image_files:
        logger.warning(f"在 {image_dir} 文件夹中未找到图片文件")
        return db_data_list
    
    logger.info(f"找到 {len(image_files)} 张图片文件")
    
    # 第二步：OCR识别和数据处理
    logger.info("开始OCR识别和数据处理")
    
    for idx, image_file in enumerate(image_files):
        try:
            logger.info(f"正在处理第{idx+1}张图片: {os.path.basename(image_file)}")
            
            # 读取图片文件并转换为base64
            with open(image_file, "rb") as f:
                image_data = f.read()
                image_base64 = base64.b64encode(image_data).decode()
            
            # 调用OCR识别
            ocr_json = call_tencent_ocr(image_base64)
            
            # 记录OCR识别结果
            logger.info(f"第{idx+1}张图片OCR识别完成")
            
            # 只打印非base64字段的关键信息
            safe_data = {}
            for key, value in ocr_json.items():
                if key.lower() not in ['imagebase64', 'image_base64', 'base64']:
                    if isinstance(value, str) and len(value) > 100:
                        safe_data[key] = f"{value[:100]}... (长度: {len(value)})"
                    else:
                        safe_data[key] = value
                else:
                    safe_data[key] = f"[Base64数据已隐藏] (长度: {len(value) if isinstance(value, str) else 'unknown'})"
            
            logger.debug(json.dumps(safe_data, ensure_ascii=False, indent=2))
            
            # 解析并展示结构化数据
            if 'StructuralList' in ocr_json:
                structural_list = ocr_json['StructuralList']
                
                for struct_idx, struct in enumerate(structural_list):
                    if 'Groups' in struct:
                        for group_idx, group in enumerate(struct['Groups']):
                            logger.debug(f"  组 {group_idx + 1}:")
                            if 'Lines' in group:
                                for line_idx, line in enumerate(group['Lines']):
                                    key_info = line.get('Key', {})
                                    value_info = line.get('Value', {})
                                    key_name = key_info.get('ConfigName') or key_info.get('AutoName', '未知')
                                    value_content = value_info.get('AutoContent', '')
            
            # 展示其他可能的字段
            for key, value in ocr_json.items():
                if key != 'StructuralList' and value:
                    pass  # 跳过非结构化数据
            
            # 映射到数据库字段
            db_data = map_ocr_to_db(ocr_json)
            
            # 只用非空字段覆盖已有字段，合并到全局db_data_list
            for key, value in db_data.items():
                if value not in [None, '', []]:
                    db_data_list[key] = value
                    
                
        except Exception as e:
            logger.error(f"第{idx+1}张图片识别失败: {e}")
    
    # 第三步：最终数据检查和补充
    logger.info(f"OCR处理完成，共处理 {len(image_files)} 张图片")
    logger.info(f"数据处理完成，共处理 {len(db_data_list)} 个字段")
    # 第四步：补充计算到期日期
    logger.info("补充计算到期日期")
    
    # 检查是否需要计算到期日期
    if not db_data_list.get("expire_date") and db_data_list.get("production_date"):
        production_date = db_data_list["production_date"]
        shelf_life_year = db_data_list.get("shelf_life_year", 0) or 0
        shelf_life_month = db_data_list.get("shelf_life_month", 0) or 0
        shelf_life_day = db_data_list.get("shelf_life_day", 0) or 0
        
        # 如果有任何保质期信息，则计算到期日期
        if shelf_life_year > 0 or shelf_life_month > 0 or shelf_life_day > 0:
            try:
                from datetime import datetime as dt, timedelta
                from dateutil.relativedelta import relativedelta
                
                # 解析生产日期
                prod_date = dt.strptime(production_date, "%Y-%m-%d").date()
                
                # 计算到期日期
                expire_date = prod_date
                if shelf_life_year > 0:
                    expire_date = expire_date + relativedelta(years=shelf_life_year)
                if shelf_life_month > 0:
                    expire_date = expire_date + relativedelta(months=shelf_life_month)
                if shelf_life_day > 0:
                    expire_date = expire_date + timedelta(days=shelf_life_day)
                
                db_data_list["expire_date"] = expire_date.strftime("%Y-%m-%d")
                logger.info(f"补充计算到期日期: 生产日期 {production_date} + 保质期 {shelf_life_year}年{shelf_life_month}个月{shelf_life_day}天 = {db_data_list['expire_date']}")
                
            except Exception as e:
                logger.error(f"补充计算到期日期失败: {e}")
        else:
            logger.warning("没有保质期信息，无法计算到期日期")
    else:
        if not db_data_list.get("expire_date"):
            logger.warning("没有生产日期，无法计算到期日期")
    
    # 统计识别到的字段类型
    recognized_fields = {
        '基本信息': ['name', 'food_number', 'category'],
        '日期信息': ['production_date', 'expire_date'],
        '保质期信息': ['shelf_life_year', 'shelf_life_month', 'shelf_life_day'],
        '营养成分': ['net_value', 'net_unit', 'calorie_per_unit', 'protein_per_unit', 
                   'fat_per_unit', 'carbo_per_unit', 'sugar_per_unit', 'sodium_per_unit'],
        '过敏原信息': ['gluten_valid', 'cara_valid', 'fish_valid', 'egg_valid', 
                    'peanut_valid', 'soy_valid', 'dairy_valid', 'nut_valid']
    }
    
    logger.info("字段识别统计:")
    for category, fields in recognized_fields.items():
        recognized_count = sum(1 for field in fields if field in db_data_list and db_data_list[field] not in [None, '', []])
        total_count = len(fields)
        logger.info(f"  {category}: {recognized_count}/{total_count} 字段已识别")
    
    return db_data_list


if __name__ == "__main__":
    """
    主函数：处理图片并输出结果
    """
    # 智能日志配置
    from config import setup_logging_if_needed
    setup_logging_if_needed()
    
    print("开始测试腾讯云OCR...")
    print("检查环境配置...")
    
    # 检查配置
    print(f"SECRET_ID: {'已设置' if SECRET_ID else '未设置'}")
    print(f"SECRET_KEY: {'已设置' if SECRET_KEY else '未设置'}")
    print(f"OCR_ENDPOINT: {OCR_ENDPOINT}")
    print(f"IMAGES_TEMP_DIR: {IMAGES_TEMP_DIR}")
    # DEBUG_MODE已设置
    
    try:
        result = process_images_to_db_data()
        if result:
            print("数据处理完成")
            print(f"处理结果: {result}")
        else:
            print("数据处理失败 - 返回空结果")
    except Exception as e:
        print(f"数据处理失败 - 发生异常: {e}")
        import traceback
        print(f"详细错误信息: {traceback.format_exc()}")
