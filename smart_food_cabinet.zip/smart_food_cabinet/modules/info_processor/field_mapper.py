#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
字段映射器 (Field Mapper)
将OCR识别结果转换为标准化的数据库字段格式。
"""

import re
import logging
from datetime import datetime

# 配置日志
logger = logging.getLogger(__name__)

# 过敏原关键词映射（与文档一致）
ALLERGEN_KEYWORDS = {
    'gluten_valid': ["麸质", "小麦","全麦","麦","谷物", "谷蛋白"],
    'cara_valid': ["甲壳", "虾", "蟹"],
    'fish_valid': ["鱼"],
    'egg_valid': ["蛋", "蛋制品", "蛋类"],
    'peanut_valid': ["花生"],
    'soy_valid': ["大豆", "大豆制品"],
    'dairy_valid': ["乳", "乳制品", "奶", "奶制品"],
    'nut_valid': ["坚果", "杏仁", "榛子", "腰果", "芝麻"]
}

# 净含量单位兼容映射
NET_CONTENT_UNIT_MAP = {
    'g': ["g", "克"],
    'kg': ["kg", "千克"],
    'ml': ["ml", "mL", "毫升"],
    'l': ["l", "L", "升"]
}

# 营养成分表单位兼容映射
NUTRITION_UNIT_MAP = {
    'g': ["g", "克"],
    'mg': ["mg", "毫克"],
    'kJ': ["KJ", "kj", "千焦"]
}

# 保质期单位归一化映射表
TIME_MAP = {
    "D": ["天", "日"],
    "M": ["月"],
    "Y": ["年"]
}

# 字段与OCR Key映射
FIELD_OCR_KEYS = {
    "name": ["食品名称", "产品名称", "商品名称", "品名", "名称"],
    "date": ["日期", "生产日期", "保质期"],
    "shelf_life": ["保质期"],
    "net_content": ["净含量", "规格", "重量"],
    "calorie": ["能量"],
    "protein": ["蛋白质"],
    "fat": ["脂肪"],
    "carbohydrate": ["碳水化合物"],
    "sugar": ["糖"],
    "sodium": ["钠"],
    "allergen": ["致敏物质", "过敏原", "致敏原", "过敏物质", "过敏原信息", "致敏物质提示", "过敏物质温馨提示", "配料"],
}

MAPPER_TO_DB_FIELD = {
    "net_content": "net_value",
    "calorie": "calorie_per_unit",
    "protein": "protein_per_unit",
    "fat": "fat_per_unit",
    "carbohydrate": "carbo_per_unit",
    "sugar": "sugar_per_unit",
    "sodium": "sodium_per_unit",
}

# 支持的日期格式
DATE_FORMATS = ["%Y-%m-%d", "%Y%m%d", "%Y/%m/%d", "%Y.%m.%d", "%Y年%m月%d日"]
DATE_REGEX = r"\d{4}[-/.]?\d{2}[-/.]?\d{2}"

def parse_date(date_str: str):
    """
    支持多种日期格式的解析
    """
    for fmt in DATE_FORMATS:
        try:
            return datetime.strptime(date_str, fmt)
        except ValueError:
            continue
    return None

def fuzzy_normalize_unit(value, unit_map):
    """
    模糊匹配单位，只要单位字符串包含 unit_map 中的别名即可，返回(数值, 标准单位)或(None, None)
    """
    import re
    match = re.match(r"([\d.]+)\s*([a-zA-Z\u4e00-\u9fa5()]+)", value)
    if match:
        num = float(match.group(1))
        unit = match.group(2)
        std_unit = None
        for k, aliases in unit_map.items():
            for alias in aliases:
                if alias in unit:
                    std_unit = k
                    break
            if std_unit:
                break
        if std_unit:
            return num, std_unit
    return None, None

def fuzzy_normalize_time_unit(value):
    """
    模糊匹配保质期单位，只要单位字符串包含 TIME_MAP 中的关键字即可
    返回字典格式：{'shelf_life_year': x, 'shelf_life_month': y, 'shelf_life_day': z}
    
    Args:
        value: 保质期字符串，如"两年六个月"、"180天"、"6个月"等
        
    Returns:
        包含年、月、日字段的字典，未识别的字段为None
    """
    import re
    
    result = {
        'shelf_life_year': None,
        'shelf_life_month': None, 
        'shelf_life_day': None
    }
    
    # 中文数字转阿拉伯数字的映射
    chinese_num_map = {
        '一': 1, '二': 2, '两': 2, '三': 3, '四': 4, '五': 5,
        '六': 6, '七': 7, '八': 8, '九': 9, '十': 10,
    }
    
    def chinese_to_arabic(chinese_str):
        """将中文数字转换为阿拉伯数字"""
        if chinese_str.isdigit():
            return int(chinese_str)
        
        # 处理简单的中文数字
        if chinese_str in chinese_num_map:
            return chinese_num_map[chinese_str]
        
        # 处理"十"的组合，如"十二"、"二十"
        if '十' in chinese_str:
            if chinese_str.startswith('十'):
                # "十二" -> 12
                return 10 + chinese_num_map.get(chinese_str[1], 0)
            elif chinese_str.endswith('十'):
                # "二十" -> 20
                return chinese_num_map.get(chinese_str[0], 0) * 10
            else:
                # "二十五" -> 25
                parts = chinese_str.split('十')
                if len(parts) == 2:
                    return chinese_num_map.get(parts[0], 0) * 10 + chinese_num_map.get(parts[1], 0)
        
        return None
    
    # 匹配数字+单位的模式，数字可以是中文或阿拉伯数字
    # 使用简单的模式：数字 + 包含年月日天的字符串
    pattern = r'([一二三四五六七八九十两\d]+)\s*([^\d一二三四五六七八九十两\s]+)'
    matches = re.findall(pattern, value)
    
    for num_str, unit in matches:
        num = chinese_to_arabic(num_str)
        if num is not None:
            # 模糊匹配：只要单位字符串包含TIME_MAP中的关键字就匹配成功
            # 使用已有的TIME_MAP，但需要映射到新的数据库字段
            if any(alias in unit for alias in TIME_MAP["Y"]):  # 年
                result['shelf_life_year'] = num
            elif any(alias in unit for alias in TIME_MAP["M"]):  # 月
                result['shelf_life_month'] = num
            elif any(alias in unit for alias in TIME_MAP["D"]):  # 日/天
                result['shelf_life_day'] = num
    
    # 验证结果：至少有一个字段有值
    if any(v is not None for v in result.values()):
        return result
    
    return None

def map_ocr_to_db(ocr_json: dict) -> dict:
    """
    归一化提取 ConfigName（优先）或 AutoName: AutoContent 对，兼容自动和自定义字段名。
    返回时自动转换为数据库字段名。
    对数值字段，自动做单位标准化。
    对日期字段，所有相关字段统一归一化为'date'，遍历所有date值，最晚历史/今天为production_date，最早未来为expire_date。
    保质期字段单独做数值+单位提取和校验，合法则存shelf_life_value和shelf_life_unit。
    对 net_value 字段，要求 value 必须是数值+单位格式，且单位必须是 g、克、ml、mL、毫升、升、L、kg、千克、英寸 中的一个，否则不录入。
    对 name 字段，优先选用含有食品关键词的内容，且在这类中先来后到；含有"公司""成分"则直接舍弃。
    """
    # ===== 第一步：初始化变量 =====
    result = {}
    allergen_content = ""
    today = datetime.today().date()
    dates = []
    name_candidates = []
    food_keywords = ["饼", "奶", "片", "糕", "茶", "包", "面", "卷", "酥", "派", "糖", "果", "豆"]
    forbidden_keywords = ["公司", "成分", "月", "日", "年"]
    struct_list = ocr_json.get('StructuralList', [])
    
    # ===== 第二步：遍历OCR结果，处理各个字段 =====
    for struct in struct_list:
        for group in struct.get('Groups', []):
            for line in group.get('Lines', []):
                key = line.get('Key', {}).get('ConfigName') or line.get('Key', {}).get('AutoName')
                value = line.get('Value', {}).get('AutoContent')
                if key and value:
                    for norm_field, ocr_keys in FIELD_OCR_KEYS.items():
                        if key in ocr_keys and value not in [None, '', []]:
                            db_field = MAPPER_TO_DB_FIELD.get(norm_field, norm_field)
                            
                            # --- 处理名称字段 ---
                            if norm_field == "name":
                                if any(fk in value for fk in forbidden_keywords):
                                    continue
                                name_candidates.append(value)
                            
                            # --- 处理日期字段 ---
                            elif norm_field == "date":
                                dt = parse_date(value)
                                if dt:
                                    dates.append(dt.date())
                            
                            # --- 处理保质期字段 ---
                            elif norm_field == "shelf_life":
                                shelf_life_data = fuzzy_normalize_time_unit(value)
                                if shelf_life_data:
                                    for key, value in shelf_life_data.items():
                                        if value is not None:
                                            result[key] = value
                            
                            # --- 处理净含量字段 ---
                            elif norm_field == "net_content":
                                num, std_unit = fuzzy_normalize_unit(value, NET_CONTENT_UNIT_MAP)
                                if num is not None and std_unit:
                                    result[db_field] = num
                                    result["net_unit"] = std_unit
                            
                            # --- 处理营养成分字段 ---
                            elif norm_field in ["protein", "fat", "carbohydrate", "sugar"]:
                                v, u = fuzzy_normalize_unit(value, NUTRITION_UNIT_MAP)
                                if v is not None and u:
                                    result[db_field] = v
                            elif norm_field == "sodium":
                                v, u = fuzzy_normalize_unit(value, NUTRITION_UNIT_MAP)
                                if v is not None and u:
                                    result[db_field] = v
                            elif norm_field == "calorie":
                                v, u = fuzzy_normalize_unit(value, NUTRITION_UNIT_MAP)
                                if v is not None and u:
                                    result[db_field] = v
                            
                            # --- 处理过敏原字段 ---
                            elif norm_field == "allergen":
                                allergen_content += str(value) + ";"
                            
                            # --- 处理其他字段 ---
                            else:
                                result[db_field] = value
    
    # ===== 第三步：处理名称筛选逻辑 =====
    name_final = None
    for n in name_candidates:
        if any(fk in n for fk in forbidden_keywords):
            continue
        if any(fk in n for fk in food_keywords):
            name_final = n
            break
    if not name_final and name_candidates:
        name_final = name_candidates[0]
    if name_final:
        result["name"] = name_final
    
    # ===== 第四步：处理日期分配逻辑 =====
    if dates:
        prod = max([d for d in dates if d <= today], default=None)
        exp = min([d for d in dates if d > today], default=None)
        if prod:
            result["production_date"] = prod.strftime("%Y-%m-%d")
        # 暂时不设置expire_date，优先使用计算出的到期日期
        # if exp:
        #     result["expire_date"] = exp.strftime("%Y-%m-%d")
    
    # ===== 第四步补充：根据生产日期和保质期计算到期日期 =====
    # 优先使用计算出的到期日期，如果没有计算出来，再使用OCR识别的到期日期
    if result.get("production_date"):
        production_date = result["production_date"]
        shelf_life_year = result.get("shelf_life_year", 0) or 0
        shelf_life_month = result.get("shelf_life_month", 0) or 0
        shelf_life_day = result.get("shelf_life_day", 0) or 0
        
        # 如果有任何保质期信息，则计算到期日期
        if shelf_life_year > 0 or shelf_life_month > 0 or shelf_life_day > 0:
            try:
                from datetime import datetime as dt, timedelta
                from dateutil.relativedelta import relativedelta
                
                # 解析生产日期
                prod_date = dt.strptime(production_date, "%Y-%m-%d").date()
                
                # 计算到期日期
                expire_date = prod_date
                if shelf_life_year > 0:
                    expire_date = expire_date + relativedelta(years=shelf_life_year)
                if shelf_life_month > 0:
                    expire_date = expire_date + relativedelta(months=shelf_life_month)
                if shelf_life_day > 0:
                    expire_date = expire_date + timedelta(days=shelf_life_day)
                
                result["expire_date"] = expire_date.strftime("%Y-%m-%d")
                logger.info(f"根据生产日期 {production_date} 和保质期计算到期日期: {result['expire_date']}")
                
            except Exception as e:
                logger.error(f"计算到期日期失败: {e}")
                # 如果计算失败，使用OCR识别的到期日期作为兜底
                if dates:
                    exp = min([d for d in dates if d > today], default=None)
                    if exp:
                        result["expire_date"] = exp.strftime("%Y-%m-%d")
                        logger.info(f"使用OCR识别的到期日期作为兜底: {result['expire_date']}")
    
    # ===== 第五步：处理过敏原匹配 =====
    for valid_field, keywords in ALLERGEN_KEYWORDS.items():
        result[valid_field] = 1 if any(kw in allergen_content for kw in keywords) else 0
    
    # ===== 第六步：兜底补充处理 =====
    # 收集所有值用于兜底补充
    all_values = []
    for struct in struct_list:
        for group in struct.get('Groups', []):
            for line in group.get('Lines', []):
                value = line.get('Value', {}).get('AutoContent')
                if value:
                    all_values.append(value)
    
    # 兜底补充 calorie_per_unit
    if not result.get("calorie_per_unit"):
        for v in all_values:
            m = re.match(r"([\d.]+)\s*([a-zA-Z\u4e00-\u9fa5()]+)", v)
            if m:
                num = float(m.group(1))
                unit = m.group(2)
                for k, aliases in NUTRITION_UNIT_MAP.items():
                    if k == "kJ" and any(alias in unit for alias in aliases):
                        result["calorie_per_unit"] = num
                        break
            if result.get("calorie_per_unit"):
                break
    
    
    return result


if __name__ == "__main__":
    pass
