#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
信息处理模块
包含OCR识别、食品分类、日期检测等核心功能
"""

from .category_detector import FoodDrinkDetector
from .table_date_detector import TableDateDetector

__all__ = [
    'FoodDrinkDetector',
    'TableDateDetector'
]
