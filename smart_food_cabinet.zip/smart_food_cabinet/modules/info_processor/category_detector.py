#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
食品和饮品检测程序
使用YOLO模型识别图片中的食品和饮品对象
"""

import os
import cv2
import numpy as np
import logging
import sys

# 添加项目根目录到Python路径，以便导入config模块
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

# 为PyTorch 2.6+添加安全全局变量支持（必须在导入ultralytics之前）
try:
    import torch
    print(f"🔍 [DEBUG] PyTorch版本: {torch.__version__}")
    
    # 检查是否有add_safe_globals方法
    if hasattr(torch.serialization, 'add_safe_globals'):
        torch.serialization.add_safe_globals(['ultralytics.nn.tasks.DetectionModel'])
        print("🔍 [DEBUG] 已添加安全全局变量支持")
    else:
        print("🔍 [DEBUG] PyTorch版本不支持add_safe_globals，跳过")
        
    # 修复torch.load的兼容性问题
    original_torch_load = torch.load
    
    def patched_torch_load(*args, **kwargs):
        # 如果weights_only参数存在且为True，设置为False
        if 'weights_only' in kwargs and kwargs['weights_only']:
            kwargs['weights_only'] = False
            print("🔍 [DEBUG] 修复torch.load: weights_only=False")
        return original_torch_load(*args, **kwargs)
    
    torch.load = patched_torch_load
    print("🔍 [DEBUG] 已应用torch.load补丁")
        
except Exception as e:
    print(f"❌ [ERROR] PyTorch配置失败: {e}")
    import traceback
    print(f"❌ [ERROR] 详细错误: {traceback.format_exc()}")

logger = logging.getLogger(__name__)
from config import db_data_list, IMAGES_TEMP_DIR

class FoodDrinkDetector:
    """食品和饮品检测器类"""
    
    def __init__(self, model_path):
        """
        初始化检测器
        
        Args:
            model_path (str): YOLO模型文件路径
        """
        self.model_path = model_path
        
        # 从配置文件获取参数设置
        from config import YOLO_CONFIDENCE_THRESHOLD, YOLO_IOU_THRESHOLD
        
        # 固定参数设置
        self.image_size = 640  # 图像尺寸设置为640px
        self.confidence_threshold = YOLO_CONFIDENCE_THRESHOLD  # 从配置文件获取置信度阈值
        self.iou_threshold = YOLO_IOU_THRESHOLD  # 从配置文件获取IoU阈值
        
        # 加载模型
        self.model = self._load_model()
        
        # 设置类别名称
        self.class_names = ['food', 'drink']
        
    def _load_model(self):
        """
        加载YOLO模型
        
        Returns:
            torch.nn.Module: 加载的模型
        """
        try:
            # 加载YOLOv8模型
            from ultralytics import YOLO
            
            # 加载自定义训练的YOLOv8模型
            model = YOLO(self.model_path)
            
            logger.debug(f"模型加载成功: {self.model_path}")
            logger.debug(f"参数设置 - 图像尺寸: {self.image_size}px, 置信度阈值: {self.confidence_threshold}, IoU阈值: {self.iou_threshold}")
            
            return model
            
        except Exception as e:
            print(f"模型加载失败: {e}")
            raise
    
    def preprocess_image(self, image_path):
        """
        预处理图像
        
        Args:
            image_path (str): 图像文件路径
            
        Returns:
            numpy.ndarray: 预处理后的图像
        """
        # 读取图像
        image = cv2.imread(image_path)
        if image is None:
            raise ValueError(f"无法读取图像: {image_path}")
        
        # 转换为RGB格式
        image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        
        return image_rgb
    
    def detect_objects(self, image_path):
        """
        检测图像中的食品和饮品对象
        
        Args:
            image_path (str): 图像文件路径
            
        Returns:
            tuple: (原始图像, 检测结果)
        """
        # 预处理图像
        image = self.preprocess_image(image_path)
        
        # 执行检测 - 使用YOLOv8的API
        results = self.model(image, conf=self.confidence_threshold, iou=self.iou_threshold, imgsz=self.image_size)
        
        return image, results

    def get_images_from_folder(self, images_dir):
        """
        从指定目录中获取所有图片文件
        
        Args:
            images_dir (str): 图片目录路径
            
        Returns:
            list: 图片路径列表
        """
        image_extensions = ['.jpg', '.jpeg', '.png', '.bmp', '.tiff']
        image_files = []
        
        # 遍历目录查找图片文件
        for root, dirs, files in os.walk(images_dir):
            for file in files:
                if any(file.lower().endswith(ext) for ext in image_extensions):
                    image_files.append(os.path.join(root, file))
        
        if not image_files:
            raise ValueError(f"在目录 {images_dir} 中未找到图片文件")
        
        # 按文件名排序
        image_files.sort()
        
        logger.debug(f"在目录 {images_dir} 中找到 {len(image_files)} 张图片:")
        for i, img_path in enumerate(image_files, 1):
            logger.debug(f"  {i}. {os.path.basename(img_path)}")
        
        return image_files
    
    def analyze_images_tempt(self, images_dir=None):
        """
        分析images_tempt文件夹中的图片，统计food和drink次数
        
        Args:
            images_dir (str): 图片目录路径，如果为None则使用配置中的路径
            
        Returns:
            str: 分析结果
        """
        try:
            if images_dir is None:
                images_dir = str(IMAGES_TEMP_DIR)
            
            # 获取所有图片
            image_paths = self.get_images_from_folder(images_dir)
            
            # 统计总体结果
            total_food_count = 0
            total_drink_count = 0
            
            logger.debug("\n" + "="*60)
            logger.debug("开始分析images_tempt文件夹中的图片...")
            logger.debug("="*60)
            
            # 逐张图片进行检测
            for i, image_path in enumerate(image_paths, 1):
                logger.debug(f"\n--- 处理第 {i}/{len(image_paths)} 张图片 ---")
                logger.debug(f"图片: {os.path.basename(image_path)}")
                
                try:
                    # 执行检测
                    image, results = self.detect_objects(image_path)
                    
                    # 统计检测结果
                    if len(results) > 0 and len(results[0].boxes) > 0:
                        boxes = results[0].boxes
                        confidences = boxes.conf.cpu().numpy()
                        class_ids = boxes.cls.cpu().numpy()
                        
                        valid_mask = confidences >= self.confidence_threshold
                        valid_class_ids = class_ids[valid_mask]
                        
                        food_count = len(valid_class_ids[valid_class_ids == 0])
                        drink_count = len(valid_class_ids[valid_class_ids == 1])
                        
                        total_food_count += food_count
                        total_drink_count += drink_count
                        
                        logger.debug(f"检测结果: 食品: {food_count}, 饮品: {drink_count}")
                    else:
                        logger.debug("检测结果: 未检测到任何对象")
                    
                except Exception as e:
                    print(f"处理图片 {os.path.basename(image_path)} 时出现错误: {e}")
                    continue
            
            # 输出最终结果
            logger.debug("\n" + "="*60)
            logger.debug("分析完成！统计结果:")
            logger.debug("="*60)
            logger.debug(f"处理图片数量: {len(image_paths)}")
            logger.debug(f"食品对象总数: {total_food_count}")
            logger.debug(f"饮品对象总数: {total_drink_count}")
            
            # 根据统计结果输出结论
            if total_food_count > total_drink_count:
                result = "food"
                logger.debug(f"结论: food (食品数量更多: {total_food_count} > {total_drink_count})")
            elif total_drink_count > total_food_count:
                result = "drink"
                logger.debug(f"结论: drink (饮品数量更多: {total_drink_count} > {total_food_count})")
            else:
                result = "无法判断"
                logger.debug(f"结论: 无法判断 (食品和饮品数量相等: {total_food_count} = {total_drink_count})")
            
            # 将结果添加到全局db_data_list中
            db_data_list['category'] = result
            logger.debug(f"已将结果添加到db_data_list: category = {result}")
            
            return result
            
        except Exception as e:
            print(f"分析过程中出现错误: {e}")
            raise

    def analyze_category(self, image_path):
        """
        分析单张图片的食品类别
        
        Args:
            image_path (str): 单张图片的路径
            
        Returns:
            str: 分析结果 ('food', 'drink', 或 '无法判断')
        """
        try:
            if not os.path.exists(image_path):
                raise ValueError(f"图片文件不存在: {image_path}")
            
            logger.debug(f"开始分析单张图片: {os.path.basename(image_path)}")
            
            # 执行检测
            image, results = self.detect_objects(image_path)
            
            # 统计检测结果
            food_count = 0
            drink_count = 0
            
            if len(results) > 0 and len(results[0].boxes) > 0:
                boxes = results[0].boxes
                confidences = boxes.conf.cpu().numpy()
                class_ids = boxes.cls.cpu().numpy()
                
                valid_mask = confidences >= self.confidence_threshold
                valid_class_ids = class_ids[valid_mask]
                
                food_count = len(valid_class_ids[valid_class_ids == 0])
                drink_count = len(valid_class_ids[valid_class_ids == 1])
                
                logger.debug(f"检测结果: 食品: {food_count}, 饮品: {drink_count}")
            else:
                logger.debug("检测结果: 未检测到任何对象")
            
            # 根据统计结果输出结论
            if food_count > drink_count:
                result = "food"
                logger.debug(f"结论: food (食品数量更多: {food_count} > {drink_count})")
            elif drink_count > food_count:
                result = "drink"
                logger.debug(f"结论: drink (饮品数量更多: {drink_count} > {food_count})")
            else:
                result = "无法判断"
                logger.debug(f"结论: 无法判断 (食品和饮品数量相等: {food_count} = {drink_count})")
            
            # 将结果添加到全局db_data_list中
            from config import db_data_list
            db_data_list['category'] = result
            logger.debug(f"已将结果添加到db_data_list: category = {result}")
            
            return result
            
        except Exception as e:
            logger.error(f"分析单张图片时出现错误: {e}")
            raise


def run_category_detection(model_path=None, images_dir=None):
    """
    运行食品和饮品分类检测
    
    Args:
        model_path (str): 模型文件路径，如果为None则使用配置文件中的路径
        images_dir (str): 图片目录路径，如果为None则使用配置中的路径
        
    Returns:
        str: 检测结果 ('food', 'drink', 或 '无法判断')
    """
    # 如果没有指定模型路径，使用配置文件中的路径
    if model_path is None:
        from config import YOLO_CATEGORY_MODEL_PATH
        model_path = YOLO_CATEGORY_MODEL_PATH
    
    # 如果没有指定图片目录，使用配置中的路径
    if images_dir is None:
        images_dir = str(IMAGES_TEMP_DIR)
    
    # 检查文件是否存在
    if not os.path.exists(model_path):
        print(f"错误: 模型文件不存在: {model_path}")
        return None
    
    if not os.path.exists(images_dir):
        print(f"错误: images_tempt目录不存在: {images_dir}")
        return None
    
    try:
        # 创建检测器
        detector = FoodDrinkDetector(model_path)
        
        # 分析images_tempt文件夹中的图片
        result = detector.analyze_images_tempt(images_dir)
        
        # 输出最终结果
        print(f"\n最终输出结果: {result}")
        logger.debug(f"db_data_list内容: {db_data_list}")
        
        return result
        
    except Exception as e:
        print(f"程序执行失败: {e}")
        return None


if __name__ == "__main__":
    result = run_category_detection()
    if result:
        print(f"检测完成，结果: {result}")
