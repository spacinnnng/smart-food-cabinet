#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
YOLO表格日期检测器 (YOLO Table Date Detector)
使用YOLO深度学习模型自动识别食品包装图片中的表格区域和日期信息。
"""

import os
import cv2
import numpy as np
import sys
from pathlib import Path

# 添加项目根目录到Python路径，以便导入config模块
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

# 为PyTorch 2.6+添加安全全局变量支持（必须在导入ultralytics之前）
try:
    import torch
    print(f"🔍 [DEBUG] PyTorch版本: {torch.__version__}")
    
    # 检查是否有add_safe_globals方法
    if hasattr(torch.serialization, 'add_safe_globals'):
        torch.serialization.add_safe_globals(['ultralytics.nn.tasks.DetectionModel'])
        print("🔍 [DEBUG] 已添加安全全局变量支持")
    else:
        print("🔍 [DEBUG] PyTorch版本不支持add_safe_globals，跳过")
        
    # 修复torch.load的兼容性问题
    original_torch_load = torch.load
    
    def patched_torch_load(*args, **kwargs):
        # 如果weights_only参数存在且为True，设置为False
        if 'weights_only' in kwargs and kwargs['weights_only']:
            kwargs['weights_only'] = False
            print("🔍 [DEBUG] 修复torch.load: weights_only=False")
        return original_torch_load(*args, **kwargs)
    
    torch.load = patched_torch_load
    print("🔍 [DEBUG] 已应用torch.load补丁")
        
except Exception as e:
    print(f"❌ [ERROR] PyTorch配置失败: {e}")
    import traceback
    print(f"❌ [ERROR] 详细错误: {traceback.format_exc()}")

class TableDateDetector:
    """表格和日期检测器类"""
    
    def __init__(self, model_path):
        """
        初始化检测器
        
        Args:
            model_path (str): YOLO模型文件路径
        """
        self.model_path = model_path
        
        # 从配置文件获取参数设置
        from config import YOLO_CONFIDENCE_THRESHOLD, YOLO_IOU_THRESHOLD
        
        # 固定参数设置
        self.image_size = 640  # 图像尺寸设置为640px
        self.confidence_threshold = YOLO_CONFIDENCE_THRESHOLD  # 从配置文件获取置信度阈值
        self.iou_threshold = YOLO_IOU_THRESHOLD  # 从配置文件获取IoU阈值
        
        # 加载模型
        self.model = self._load_model()
        
        # 类别名称和显示标签
        self.class_names = ['date', 'table']
        self.display_names = ['Date', 'Nutrition Table']  # 英文显示标签，避免中文显示问题
        self.colors = [(255, 0, 0), (0, 255, 0)]  # 红色用于日期，绿色用于表格
        
    def _load_model(self):
        """
        加载YOLO模型
        
        Returns:
            加载的YOLO模型
        """
        try:
            # 加载YOLOv8模型
            from ultralytics import YOLO
            
            # 加载自定义训练的YOLOv8模型
            model = YOLO(self.model_path)
            
            # 设置模型参数
            model.conf = self.confidence_threshold  # 置信度阈值
            model.iou = self.iou_threshold  # IoU阈值
            model.classes = None  # 检测所有类别
            
            print(f"模型加载成功: {self.model_path}")
            print(f"参数设置 - 图像尺寸: {self.image_size}px, 置信度阈值: {self.confidence_threshold}, IoU阈值: {self.iou_threshold}")
            
            return model
            
        except Exception as e:
            print(f"模型加载失败: {e}")
            raise
    
    def preprocess_image(self, image_path):
        """
        预处理图像
        
        Args:
            image_path (str): 图像文件路径
            
        Returns:
            numpy.ndarray: 预处理后的图像
        """
        # 读取图像
        image = cv2.imread(image_path)
        if image is None:
            raise ValueError(f"无法读取图像: {image_path}")
        
        # 转换为RGB格式
        image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        
        return image_rgb
    
    def detect_objects(self, image_path):
        """
        检测图像中的表格和日期对象
        
        Args:
            image_path (str): 图像文件路径
            
        Returns:
            tuple: (原始图像, 检测结果)
        """
        # 预处理图像
        image = self.preprocess_image(image_path)
        
        # 执行检测 - 使用YOLOv8的API
        results = self.model(image, conf=self.confidence_threshold, iou=self.iou_threshold, imgsz=self.image_size)
        
        return image, results
    
    def visualize_results(self, image, results, save_path=None):
        """
        可视化检测结果
        
        Args:
            image (numpy.ndarray): 原始图像
            results: YOLO检测结果
            save_path (str, optional): 保存路径
            
        Returns:
            numpy.ndarray: 可视化图像
        """
        # 创建可视化图像副本
        vis_image = image.copy()
        
        # 获取检测结果 - YOLOv8格式
        if len(results) > 0 and len(results[0].boxes) > 0:
            boxes = results[0].boxes
            detections = boxes.xyxy.cpu().numpy()  # 边界框坐标
            confidences = boxes.conf.cpu().numpy()  # 置信度
            class_ids = boxes.cls.cpu().numpy()  # 类别ID
            
            # 绘制检测框
            for i in range(len(detections)):
                x1, y1, x2, y2 = detections[i]
                conf = confidences[i]
                cls = class_ids[i]
                
                if conf >= self.confidence_threshold:
                    # 获取类别信息
                    class_id = int(cls)
                    class_name = self.class_names[class_id]
                    display_name = self.display_names[class_id]
                    color = self.colors[class_id]
                    
                    # 绘制矩形框
                    cv2.rectangle(vis_image, (int(x1), int(y1)), (int(x2), int(y2)), color, 2)
                    
                    # 添加标签
                    label = f'{display_name}: {conf:.2f}'
                    
                    # 计算文字大小
                    font_scale = 0.6
                    thickness = 2
                    (text_width, text_height), baseline = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, font_scale, thickness)
                    
                    # 绘制标签背景
                    cv2.rectangle(vis_image, 
                                 (int(x1), int(y1) - text_height - 10), 
                                 (int(x1) + text_width, int(y1)), 
                                 color, -1)
                    
                    # 绘制文字
                    cv2.putText(vis_image, label, 
                               (int(x1), int(y1) - 5), 
                               cv2.FONT_HERSHEY_SIMPLEX, font_scale, (255, 255, 255), thickness)
        
        # 添加统计信息
        if len(results) > 0 and len(results[0].boxes) > 0:
            boxes = results[0].boxes
            confidences = boxes.conf.cpu().numpy()
            class_ids = boxes.cls.cpu().numpy()
            
            valid_mask = confidences >= self.confidence_threshold
            valid_confidences = confidences[valid_mask]
            valid_class_ids = class_ids[valid_mask]
            
            date_count = len(valid_class_ids[valid_class_ids == 0])
            table_count = len(valid_class_ids[valid_class_ids == 1])
            
            info_text = f'Detected {date_count} dates, {table_count} nutrition tables'
            
            # 绘制统计信息背景
            cv2.rectangle(vis_image, (10, 10), (400, 50), (255, 255, 255), -1)
            cv2.rectangle(vis_image, (10, 10), (400, 50), (0, 0, 0), 2)
            
            # 绘制统计信息文字
            cv2.putText(vis_image, info_text, (20, 35), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 0), 2)
        
        # 保存结果
        if save_path:
            # 转换为BGR格式保存（opencv默认格式）
            vis_image_bgr = cv2.cvtColor(vis_image, cv2.COLOR_RGB2BGR)
            cv2.imwrite(save_path, vis_image_bgr)
            print(f"结果已保存到: {save_path}")
        
        return vis_image
    
    def get_all_images(self, images_dir):
        """
        从指定目录中获取所有图片文件
        
        Args:
            images_dir (str): 图片目录路径
            
        Returns:
            list: 所有图片路径列表（按文件名排序）
        """
        image_extensions = ['.jpg', '.jpeg', '.png', '.bmp', '.tiff']
        image_files = []
        
        # 遍历目录查找图片文件
        for root, dirs, files in os.walk(images_dir):
            for file in files:
                if any(file.lower().endswith(ext) for ext in image_extensions):
                    image_files.append(os.path.join(root, file))
        
        if not image_files:
            raise ValueError(f"在目录 {images_dir} 中未找到图片文件")
        
        # 按文件名排序
        image_files.sort()
        
        print(f"找到 {len(image_files)} 张图片:")
        for i, img_path in enumerate(image_files, 1):
            print(f"  {i}. {os.path.basename(img_path)}")
        
        return image_files
    
    def run_detection(self, images_dir, output_dir=None):
        """
        运行检测程序
        
        Args:
            images_dir (str): 图片目录路径
            output_dir (str, optional): 输出目录路径
        """
        try:
            # 创建输出目录
            if output_dir:
                os.makedirs(output_dir, exist_ok=True)
            
            # 获取所有图片
            image_paths = self.get_all_images(images_dir)
            
            # 统计总体结果
            total_detections = 0
            total_date_count = 0
            total_table_count = 0
            
            print("\n" + "="*60)
            print("开始批量检测...")
            print("="*60)
            
            # 逐张图片进行检测
            for i, image_path in enumerate(image_paths, 1):
                print(f"\n--- 处理第 {i}/{len(image_paths)} 张图片 ---")
                print(f"图片路径: {image_path}")
                
                try:
                    # 执行检测
                    image, results = self.detect_objects(image_path)
                    
                    # 统计检测结果
                    if len(results) > 0 and len(results[0].boxes) > 0:
                        boxes = results[0].boxes
                        confidences = boxes.conf.cpu().numpy()
                        class_ids = boxes.cls.cpu().numpy()
                        
                        valid_mask = confidences >= self.confidence_threshold
                        valid_class_ids = class_ids[valid_mask]
                        
                        date_count = len(valid_class_ids[valid_class_ids == 0])
                        table_count = len(valid_class_ids[valid_class_ids == 1])
                        current_detections = len(valid_class_ids)
                        
                        total_detections += current_detections
                        total_date_count += date_count
                        total_table_count += table_count
                        
                        print(f"检测结果: {current_detections} 个对象 (日期: {date_count}, 营养成分表: {table_count})")
                    else:
                        print("检测结果: 未检测到任何对象")
                    
                    # 可视化结果
                    if output_dir:
                        output_path = os.path.join(output_dir, f"detection_result_{i:02d}_{Path(image_path).stem}.png")
                    else:
                        output_path = None
                    
                    vis_image = self.visualize_results(image, results, output_path)
                    
                    # 打印详细结果
                    self.print_detection_details(results)
                    
                except Exception as e:
                    print(f"处理图片 {image_path} 时出现错误: {e}")
                    continue
            
            # 打印总体统计
            print("\n" + "="*60)
            print("批量检测完成！总体统计:")
            print("="*60)
            print(f"处理图片数量: {len(image_paths)}")
            print(f"总检测对象数: {total_detections}")
            print(f"日期对象总数: {total_date_count}")
            print(f"营养成分表对象总数: {total_table_count}")
            print(f"平均每张图片检测对象数: {total_detections/len(image_paths):.1f}")
            
            if output_dir:
                print(f"\n所有结果已保存到: {output_dir}")
            
        except Exception as e:
            print(f"检测过程中出现错误: {e}")
            raise
    
    def print_detection_details(self, results):
        """
        打印检测详细信息
        
        Args:
            results: YOLO检测结果
        """
        print("\n" + "="*50)
        print("检测详细信息:")
        print("="*50)
        
        if len(results) > 0 and len(results[0].boxes) > 0:
            boxes = results[0].boxes
            confidences = boxes.conf.cpu().numpy()
            class_ids = boxes.cls.cpu().numpy()
            detections = boxes.xyxy.cpu().numpy()
            
            valid_mask = confidences >= self.confidence_threshold
            valid_confidences = confidences[valid_mask]
            valid_class_ids = class_ids[valid_mask]
            valid_detections = detections[valid_mask]
            
            if len(valid_detections) == 0:
                print("未检测到任何对象（置信度低于阈值）")
                return
            
            print(f"有效检测对象数量: {len(valid_detections)}")
            print("-" * 30)
            
            for i in range(len(valid_detections)):
                x1, y1, x2, y2 = valid_detections[i]
                conf = valid_confidences[i]
                cls = valid_class_ids[i]
                class_id = int(cls)
                class_name = self.class_names[class_id]
                
                print(f"对象 {i+1}:")
                print(f"  类别: {self.display_names[class_id]}")
                print(f"  置信度: {conf:.3f}")
                print(f"  边界框: ({x1:.1f}, {y1:.1f}) -> ({x2:.1f}, {y2:.1f})")
                print(f"  尺寸: {x2-x1:.1f} x {y2-y1:.1f}")
                print()
        else:
            print("未检测到任何对象")


if __name__ == "__main__":
    """主函数"""
    # 从配置文件获取路径
    from config import YOLO_TABLE_DATE_MODEL_PATH, IMAGES_TEMP_DIR, IMAGES_RETURN_DIR
    
    # 配置路径
    model_path = YOLO_TABLE_DATE_MODEL_PATH
    images_dir = str(IMAGES_TEMP_DIR)
    output_dir = str(IMAGES_RETURN_DIR)
    
    # 检查文件是否存在
    if not os.path.exists(model_path):
        print(f"错误: 模型文件不存在: {model_path}")
        exit(1)
    
    if not os.path.exists(images_dir):
        print(f"错误: 图片目录不存在: {images_dir}")
        exit(1)
    
    try:
        # 创建检测器
        detector = TableDateDetector(model_path)
        
        # 运行检测
        detector.run_detection(images_dir, output_dir)
        
    except Exception as e:
        print(f"程序执行失败: {e}")
