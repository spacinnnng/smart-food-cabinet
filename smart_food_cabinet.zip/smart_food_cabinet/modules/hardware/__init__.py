#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
硬件管理模块
"""

from .hardware_manager import HardwareManager

__all__ = ['HardwareManager']
