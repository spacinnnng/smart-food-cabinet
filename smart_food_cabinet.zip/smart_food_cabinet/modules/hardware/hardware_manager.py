#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
硬件管理器
负责LED、蜂鸣器、霍尔传感器的控制
"""

import time
import asyncio
import logging
import sys
import os
import RPi.GPIO as GPIO
from typing import Callable

# 添加项目根目录到Python路径，以便导入config模块
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

from config import (
    LED_GREEN_PIN, LED_RED_PIN, LED_BLUE_PIN, BUZZER_PIN,
    HALL_SENSOR_PIN, HALL_SENSOR_PULL_UP_DOWN, HALL_SENSOR_ACTIVE_LOW,
    BUZZER_SHORT_DURATION, BUZZER_LONG_DURATION, LED_BLINK_INTERVAL
)

# 配置日志
logger = logging.getLogger(__name__)

class HardwareManager:
    """
    硬件管理器
    统一管理LED、蜂鸣器、霍尔传感器
    """
    
    def __init__(self):
        """初始化硬件管理器"""
        self._init_gpio()
        self.hall_callback = None
        self.is_monitoring = False
        
        logger.info("硬件管理器初始化完成")
    
    def _init_gpio(self):
        """初始化GPIO引脚"""
        try:
            # 检查GPIO是否已经初始化，避免重复设置
            if GPIO.getmode() is None:
                # 设置GPIO模式
                GPIO.setmode(GPIO.BCM)
                logger.info("GPIO模式已设置为BCM")
            else:
                logger.info(f"GPIO模式已存在: {GPIO.getmode()}")
            
            # 设置霍尔传感器引脚为输入（避免重复设置）
            try:
                if HALL_SENSOR_PULL_UP_DOWN == "UP":
                    pull_up_down = GPIO.PUD_UP
                elif HALL_SENSOR_PULL_UP_DOWN == "DOWN":
                    pull_up_down = GPIO.PUD_DOWN
                else:
                    pull_up_down = GPIO.PUD_OFF
                
                GPIO.setup(HALL_SENSOR_PIN, GPIO.IN, pull_up_down=pull_up_down)
                logger.debug(f"霍尔传感器引脚 {HALL_SENSOR_PIN} 已设置为输入")
            except Exception as e:
                logger.warning(f"设置霍尔传感器引脚失败: {e}")
            
            # 设置LED和蜂鸣器引脚为输出（避免重复设置）
            try:
                GPIO.setup(LED_GREEN_PIN, GPIO.OUT)
                GPIO.setup(LED_RED_PIN, GPIO.OUT)
                GPIO.setup(LED_BLUE_PIN, GPIO.OUT)
                GPIO.setup(BUZZER_PIN, GPIO.OUT)
                logger.debug("LED和蜂鸣器引脚已设置为输出")
            except Exception as e:
                logger.warning(f"设置输出引脚失败: {e}")
            
            # 初始状态：所有输出低电平
            GPIO.output(LED_GREEN_PIN, GPIO.LOW)
            GPIO.output(LED_RED_PIN, GPIO.LOW)
            GPIO.output(LED_BLUE_PIN, GPIO.LOW)
            GPIO.output(BUZZER_PIN, GPIO.LOW)
            
            logger.info("GPIO初始化完成")
            
        except Exception as e:
            logger.error(f"GPIO初始化失败: {e}")
            raise
    
    # ==================== LED控制 ====================
    def control_led(self, action: str):
        """
        控制LED状态
        
        Args:
            action: 'green_on', 'green_off', 'red_on', 'red_off', 'blue_on', 'blue_off',
                    'green_blink_3', 'red_blink_3'
        """
        try:
            if action == 'green_on':
                self._set_led_green(True)
            elif action == 'green_off':
                self._set_led_green(False)
            elif action == 'red_on':
                self._set_led_red(True)
            elif action == 'red_off':
                self._set_led_red(False)
            elif action == 'blue_on':
                self._set_led_blue(True)
            elif action == 'blue_off':
                self._set_led_blue(False)
            elif action == 'green_blink_3':
                self._blink_led_green(3)
            elif action == 'red_blink_3':
                self._blink_led_red(3)
                
        except Exception as e:
            logger.error(f"LED控制失败: {e}")
    
    def _set_led_green(self, state: bool):
        """设置绿灯状态"""
        GPIO.output(LED_GREEN_PIN, GPIO.HIGH if state else GPIO.LOW)
        logger.debug(f"LED绿灯{'常亮' if state else '熄灭'}")
    
    def _set_led_red(self, state: bool):
        """设置红灯状态"""
        GPIO.output(LED_RED_PIN, GPIO.HIGH if state else GPIO.LOW)
        logger.debug(f"LED红灯{'常亮' if state else '熄灭'}")
    
    def _set_led_blue(self, state: bool):
        """设置蓝灯状态"""
        GPIO.output(LED_BLUE_PIN, GPIO.HIGH if state else GPIO.LOW)
        logger.debug(f"LED蓝灯{'常亮' if state else '熄灭'}")
    
    def _blink_led_green(self, times: int):
        """绿灯闪烁指定次数"""
        for i in range(times):
            GPIO.output(LED_GREEN_PIN, GPIO.HIGH)
            time.sleep(LED_BLINK_INTERVAL)
            GPIO.output(LED_GREEN_PIN, GPIO.LOW)
            time.sleep(LED_BLINK_INTERVAL)
        logger.info(f"LED绿灯闪烁{times}次完成")
    
    def _blink_led_red(self, times: int):
        """红灯闪烁指定次数"""
        for i in range(times):
            GPIO.output(LED_RED_PIN, GPIO.HIGH)
            time.sleep(LED_BLINK_INTERVAL)
            GPIO.output(LED_RED_PIN, GPIO.LOW)
            time.sleep(LED_BLINK_INTERVAL)
        logger.info(f"LED红灯闪烁{times}次完成")
    
    async def control_led_async(self, action: str):
        """
        异步控制LED状态（非阻塞版本）
        
        Args:
            action: 'green_on', 'green_off', 'red_on', 'red_off', 'blue_on', 'blue_off',
                    'green_blink_3', 'red_blink_3'
        """
        try:
            if action == 'green_on':
                self._set_led_green(True)
            elif action == 'green_off':
                self._set_led_green(False)
            elif action == 'red_on':
                self._set_led_red(True)
            elif action == 'red_off':
                self._set_led_red(False)
            elif action == 'blue_on':
                self._set_led_blue(True)
            elif action == 'blue_off':
                self._set_led_blue(False)
            elif action == 'green_blink_3':
                await self._blink_led_green_async(3)
            elif action == 'red_blink_3':
                await self._blink_led_red_async(3)
                
        except Exception as e:
            logger.error(f"异步LED控制失败: {e}")
    
    async def _blink_led_green_async(self, times: int):
        """异步绿灯闪烁指定次数"""
        for i in range(times):
            GPIO.output(LED_GREEN_PIN, GPIO.HIGH)
            await asyncio.sleep(LED_BLINK_INTERVAL)
            GPIO.output(LED_GREEN_PIN, GPIO.LOW)
            await asyncio.sleep(LED_BLINK_INTERVAL)
        logger.info(f"LED绿灯闪烁{times}次完成")
    
    async def _blink_led_red_async(self, times: int):
        """异步红灯闪烁指定次数"""
        for i in range(times):
            GPIO.output(LED_RED_PIN, GPIO.HIGH)
            await asyncio.sleep(LED_BLINK_INTERVAL)
            GPIO.output(LED_RED_PIN, GPIO.LOW)
            await asyncio.sleep(LED_BLINK_INTERVAL)
        logger.info(f"LED红灯闪烁{times}次完成")
    
    # ==================== 蜂鸣器控制 ====================
    def beep_once(self):
        """蜂鸣器蜂鸣一次（短鸣）"""
        try:
            # 使用PWM产生更好的蜂鸣效果
            pwm = GPIO.PWM(BUZZER_PIN, 1000)  # 1000Hz频率
            pwm.start(50)  # 50%占空比
            time.sleep(BUZZER_SHORT_DURATION)
            pwm.stop()
            logger.debug("蜂鸣器蜂鸣一次")
        except Exception as e:
            logger.error(f"蜂鸣器控制失败: {e}")
            # 如果PWM失败，回退到简单的高电平控制
            try:
                GPIO.output(BUZZER_PIN, GPIO.HIGH)
                time.sleep(BUZZER_SHORT_DURATION)
                GPIO.output(BUZZER_PIN, GPIO.LOW)
            except Exception as e2:
                logger.error(f"蜂鸣器回退控制也失败: {e2}")
    
    def beep_long(self):
        """蜂鸣器长鸣一次"""
        try:
            # 使用PWM产生更好的蜂鸣效果
            pwm = GPIO.PWM(BUZZER_PIN, 800)  # 800Hz频率，稍低一些
            pwm.start(50)  # 50%占空比
            time.sleep(BUZZER_LONG_DURATION)
            pwm.stop()
            logger.debug("蜂鸣器长鸣一次")
        except Exception as e:
            logger.error(f"蜂鸣器控制失败: {e}")
            # 如果PWM失败，回退到简单的高电平控制
            try:
                GPIO.output(BUZZER_PIN, GPIO.HIGH)
                time.sleep(BUZZER_LONG_DURATION)
                GPIO.output(BUZZER_PIN, GPIO.LOW)
            except Exception as e2:
                logger.error(f"蜂鸣器回退控制也失败: {e2}")
    
    def beep_pattern(self, pattern: str = "short_short_long"):
        """
        蜂鸣器模式蜂鸣
        
        Args:
            pattern: 蜂鸣模式
                - "short_short_long": 短-短-长（成功模式）
                - "long_short_long": 长-短-长（警告模式）
                - "short_short_short": 短-短-短（错误模式）
        """
        try:
            if pattern == "short_short_long":
                self.beep_once()
                time.sleep(0.2)
                self.beep_once()
                time.sleep(0.2)
                self.beep_long()
            elif pattern == "long_short_long":
                self.beep_long()
                time.sleep(0.2)
                self.beep_once()
                time.sleep(0.2)
                self.beep_long()
            elif pattern == "short_short_short":
                self.beep_once()
                time.sleep(0.2)
                self.beep_once()
                time.sleep(0.2)
                self.beep_once()
            else:
                logger.warning(f"未知的蜂鸣模式: {pattern}")
        except Exception as e:
            logger.error(f"蜂鸣器模式控制失败: {e}")
    
    # ==================== 霍尔传感器控制 ====================
    def get_door_status(self) -> bool:
        """
        获取门的状态
        
        Returns:
            bool: True表示门开，False表示门关
        """
        try:
            # 检查GPIO是否已经初始化
            current_mode = GPIO.getmode()
            if current_mode is None:
                logger.warning("GPIO未初始化，无法获取门状态")
                return False
            
            hall_state = GPIO.input(HALL_SENSOR_PIN)
            
            # 根据sensor.py的逻辑判断门的状态
            # 低电平=有磁场=门关，高电平=无磁场=门开
            door_open = (hall_state == GPIO.HIGH)
            
            return door_open
            
        except Exception as e:
            logger.error(f"获取门状态失败: {e}")
            return False
    
    async def start_hall_monitoring(self, callback: Callable[[bool], None], interval: float = 0.1):
        """
        开始霍尔传感器监控（异步版本）
        
        Args:
            callback: 门状态变化时的回调函数，参数为门状态(bool)
            interval: 监控间隔（秒）
        """
        if self.is_monitoring:
            logger.warning("霍尔传感器监控已在运行中")
            return
        
        self.hall_callback = callback
        self.is_monitoring = True
        
        # 启动异步监控任务
        self.monitor_task = asyncio.create_task(self._hall_monitoring_loop(interval))
        
        logger.info("霍尔传感器异步监控已启动")
    
    def stop_hall_monitoring(self):
        """停止霍尔传感器监控"""
        if not self.is_monitoring:
            return
        
        self.is_monitoring = False
        
        if hasattr(self, 'monitor_task') and not self.monitor_task.done():
            self.monitor_task.cancel()
        
        logger.info("霍尔传感器监控已停止")
    
    async def _hall_monitoring_loop(self, interval: float):
        """霍尔传感器异步监控循环"""
        last_door_status = None
        
        try:
            while self.is_monitoring:
                current_door_status = self.get_door_status()
                
                # 检测状态变化
                if current_door_status != last_door_status:
                    if self.hall_callback:
                        # 如果回调函数是异步的，使用await
                        if asyncio.iscoroutinefunction(self.hall_callback):
                            await self.hall_callback(current_door_status)
                        else:
                            self.hall_callback(current_door_status)
                    last_door_status = current_door_status
                
                # 非阻塞等待
                await asyncio.sleep(interval)
                
        except asyncio.CancelledError:
            logger.info("霍尔传感器监控任务被取消")
        except Exception as e:
            logger.error(f"霍尔传感器监控异常: {e}")
    
    # ==================== 组合控制 ====================
    def provide_success_feedback(self):
        """提供成功反馈：绿灯闪烁3次 + 蜂鸣器短鸣"""
        self.control_led('green_blink_3')
        self.beep_once()
    
    def provide_failure_feedback(self):
        """提供失败反馈：红灯闪烁3次 + 蜂鸣器长鸣"""
        self.control_led('red_blink_3')
        self.beep_long()
    
    def cleanup(self):
        """清理硬件资源"""
        try:
            # 停止监控
            self.stop_hall_monitoring()
            
            # 等待监控任务完全停止
            if hasattr(self, 'monitor_task') and not self.monitor_task.done():
                # 给监控任务一些时间来完成
                import time
                time.sleep(0.1)
            
            # 检查GPIO是否已经初始化，如果没有初始化则跳过清理
            if GPIO.getmode() is None:
                logger.warning("GPIO未初始化，跳过GPIO清理")
                return
            
            # 关闭所有输出（但不清理GPIO，因为其他模块可能还在使用）
            try:
                GPIO.output(LED_GREEN_PIN, GPIO.LOW)
                GPIO.output(LED_RED_PIN, GPIO.LOW)
                GPIO.output(LED_BLUE_PIN, GPIO.LOW)
                GPIO.output(BUZZER_PIN, GPIO.LOW)
                logger.debug("所有输出引脚已设置为低电平")
            except Exception as e:
                logger.warning(f"设置输出引脚失败: {e}")
            
            # 注意：不调用GPIO.cleanup()，因为其他模块可能还在使用GPIO
            logger.info("硬件资源清理完成（保留GPIO供其他模块使用）")
            
        except Exception as e:
            logger.error(f"硬件资源清理失败: {e}")


# 使用示例
if __name__ == "__main__":
    # 智能日志配置
    from config import setup_logging_if_needed
    setup_logging_if_needed()
    
    print("🔧 硬件管理器测试开始...")
    print("=" * 50)
    
    # 创建硬件管理器
    hw_manager = HardwareManager()
    
    try:
        # ==================== LED测试 ====================
        print("💡 测试LED控制...")
        
        # 测试绿灯
        print("  🟢 绿灯测试...")
        hw_manager.control_led('green_on')
        time.sleep(2)
        hw_manager.control_led('green_off')
        time.sleep(0.5)
        
        # 测试红灯
        print("  🔴 红灯测试...")
        hw_manager.control_led('red_on')
        time.sleep(2)
        hw_manager.control_led('red_off')
        time.sleep(0.5)
        
        # 测试蓝灯
        print("  🔵 蓝灯测试...")
        hw_manager.control_led('blue_on')
        time.sleep(2)
        hw_manager.control_led('blue_off')
        time.sleep(0.5)
        
        # 测试绿灯闪烁
        print("  🟢 绿灯闪烁测试...")
        hw_manager.control_led('green_blink_3')
        time.sleep(1)
        
        # 测试红灯闪烁
        print("  🔴 红灯闪烁测试...")
        hw_manager.control_led('red_blink_3')
        time.sleep(1)
        
        print("✅ LED测试完成")
        print()
        
        # ==================== 蜂鸣器测试 ====================
        print("🔊 测试蜂鸣器控制...")
        
        # 测试短鸣
        print("  🔊 短鸣测试...")
        hw_manager.beep_once()
        time.sleep(1)
        
        # 测试长鸣
        print("  🔊 长鸣测试...")
        hw_manager.beep_long()
        time.sleep(1)
        
        # 测试蜂鸣模式
        print("  🔊 成功模式测试 (短-短-长)...")
        hw_manager.beep_pattern("short_short_long")
        time.sleep(1)
        
        print("  🔊 警告模式测试 (长-短-长)...")
        hw_manager.beep_pattern("long_short_long")
        time.sleep(1)
        
        print("  🔊 错误模式测试 (短-短-短)...")
        hw_manager.beep_pattern("short_short_short")
        time.sleep(1)
        
        print("✅ 蜂鸣器测试完成")
        print()
        
        # ==================== 霍尔传感器测试 ====================
        print("🚪 测试霍尔传感器...")
        
        # 获取当前门状态
        current_status = hw_manager.get_door_status()
        status_text = "开" if current_status else "关"
        print(f"  当前门状态: {status_text}")
        
        # 设置门状态变化回调
        def door_status_callback(door_open):
            status = "开" if door_open else "关"
            timestamp = time.strftime("%H:%M:%S")
            print(f"  [{timestamp}] 门状态变化: {status}")
        
        print("  开始监控门状态变化...")
        print("  💡 请手动开关门来测试霍尔传感器")
        print("  💡 按 Ctrl+C 停止测试")
        
        # 启动霍尔传感器监控（异步方式）
        import asyncio
        
        async def run_hall_test():
            await hw_manager.start_hall_monitoring(door_status_callback)
            
            # 持续监控30秒
            try:
                for i in range(30):
                    await asyncio.sleep(1)
                    if i % 5 == 0:
                        remaining = 30 - i
                        print(f"  ⏰ 剩余测试时间: {remaining}秒")
            except KeyboardInterrupt:
                print("\n  ⏹️  用户中断测试")
            finally:
                hw_manager.stop_hall_monitoring()
        
        # 运行异步测试
        asyncio.run(run_hall_test())
        
        print("✅ 霍尔传感器测试完成")
        
    except Exception as e:
        print(f"❌ 测试过程中出现错误: {e}")
        logger.error(f"硬件测试失败: {e}")
        
    finally:
        print("\n🧹 清理硬件资源...")
        hw_manager.cleanup()
        print("✅ 硬件管理器测试结束")
