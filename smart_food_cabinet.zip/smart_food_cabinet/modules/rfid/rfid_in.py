#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
RFID读取器类
支持自动读卡模式、LED控制、蜂鸣器控制和标签收集功能
"""

import time
import logging
import sys
import os
from typing import Dict, Set

# 添加项目根目录到Python路径，以便导入config模块
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

from config import (
    RFID_TAG_TIMEOUT, db_data_list,
    RFID_CPU_DELAY
)

# 使用相对导入，确保从任何目录都能正确找到同目录的rfid_manager
from .rfid_manager import RFIDManager

# 延迟导入hardware_manager，避免模块链问题
def get_hardware_manager():
    """延迟导入hardware_manager，避免导入链问题"""
    try:
        import importlib.util
        
        # 直接导入hardware_manager文件
        hardware_manager_path = os.path.join(os.path.dirname(__file__), '..', 'hardware', 'hardware_manager.py')
        spec = importlib.util.spec_from_file_location("hardware_manager", hardware_manager_path)
        hardware_manager_module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(hardware_manager_module)
        return hardware_manager_module.HardwareManager
    except ImportError as e:
        if "RPi" in str(e):
            print("检测到RPi.GPIO导入错误")
            print("提示：RFID模块需要在树莓派上运行，Mac上无法运行")
            print("请在树莓派上运行：python modules/rfid/rfid_in.py")
            return None
        else:
            raise e

# 配置日志
logger = logging.getLogger(__name__)

class RFIDReader:
    """
    RFID读取器类
    支持自动持续读取模式，带LED和蜂鸣器反馈
    """
    
    def __init__(self):
        """初始化RFID读取器"""
        # 初始化硬件管理器（使用延迟导入）
        HardwareManager = get_hardware_manager()
        if HardwareManager is None:
            print("硬件管理器初始化失败，无法在Mac上运行RFID模块")
            print("请在树莓派上运行此模块")
            exit(1)
        self.hardware_manager = HardwareManager()
        
        # 初始化RFID管理器
        self.rfid_manager = RFIDManager()
        
        # 状态变量（直接使用rfid_manager的状态）
        self.cancel_requested = False  # 取消请求标志
        
        logger.info("RFID读取器初始化完成")

    # ==================== 连接管理 ====================
    def connect(self) -> bool:
        """连接RFID读取器"""
        try:
            # 检查是否已经连接
            if self.rfid_manager.is_connected and self.rfid_manager.serial_conn and self.rfid_manager.serial_conn.is_open:
                logger.info("RFID读取器已经连接")
                return True
            
            # 初始化串口连接
            if not self.rfid_manager.init_serial_connection():
                logger.error("初始化RFID串口连接失败")
                return False
            
            # 设置连接状态
            self.rfid_manager.is_connected = True
            
            logger.info("RFID读取器连接成功")
            return True
            
        except Exception as e:
            logger.error(f"RFID读取器连接异常: {e}")
            return False

    # ==================== 主要串联函数 ====================
    # 主要串联函数：整合完整的入库读取流程
    # - 作用：连接管理 + 读取模式控制 + 读取控制 + 硬件反馈
    # - 流程：初始化连接 → 设置自动读卡模式 → 启动读取 → 收集标签 → 硬件反馈
    def read_multiple_unique_tags_with_feedback(self) -> Dict:
        """
        读取指定数量的不同RFID标签ID，并提供LED和蜂鸣器反馈
        使用config中配置的food_number作为目标数量，无超时限制
        
        硬件反馈说明：
        - 开始读取时：LED绿灯常亮，表示正在等待标签
        - 每读取到新标签：蜂鸣器蜂鸣一次，提示用户标签已识别
        - 读取成功时：LED绿灯闪烁3次后关闭，表示完成目标数量
        - 读取被取消时：LED红灯闪烁3次后关闭，表示操作被取消
        - 异常情况：LED红灯闪烁3次后关闭，表示发生错误
        
        业务流程：
        1. 初始化自动读卡模式
        2. LED绿灯常亮，开始等待标签
        3. 每检测到新标签ID时蜂鸣器响一次
        4. 收集到目标数量或被取消后停止
        5. 根据结果提供相应的LED反馈
        6. 将标签列表存储到db_data_list中
        
        Returns:
            dict: {
                'success': bool,           # 是否成功读取到目标数量
                'tag_count': int,          # 实际读取到的标签数量
                'rfid_list': str           # 逗号分隔的标签ID字符串
            }
        """
        # 使用config中的配置参数（动态获取，确保获取最新值）
        import config
        target_count = config.food_number
        
        logger.info(f"开始读取{target_count}个不同标签，无超时限制")
        
        # 硬件管理器GPIO已在初始化时自动设置，无需重复调用
        
        # 初始化RFID连接（参考rfid_out.py的成功模式）
        if not self.rfid_manager.init_serial_connection():
            logger.error("初始化RFID串口连接失败")
            return {'success': False, 'tag_count': 0, 'rfid_list': ''}
        
        if not self.rfid_manager.connect():
            logger.error("RFID连接失败")
            return {'success': False, 'tag_count': 0, 'rfid_list': ''}
        
        # 初始化自动读卡模式
        if not self.rfid_manager.init_auto_read_mode():
            logger.error("初始化自动读卡模式失败")
            return {'success': False, 'tag_count': 0, 'rfid_list': ''}
        
        # LED绿灯常亮
        self.hardware_manager.control_led('green_on')
        
        # 开始收集标签
        collected_tags: Set[str] = set()
        start_time = time.time()
        
        # 定义标签回调函数
        def on_tag_read(card_id: str):
            # 检查是否是新ID（card_id为十进制格式）
            if card_id not in collected_tags:
                collected_tags.add(card_id)
                logger.info(f"收集到新标签 {len(collected_tags)}/{target_count}: {card_id} (十进制)")
                
                # 蜂鸣器蜂鸣一次
                self.hardware_manager.beep_once()
        
        # 启动RFID读取
        if not self.rfid_manager.start_reading(on_tag_read):
            logger.error("启动RFID读取失败")
            return {'success': False, 'tag_count': 0, 'rfid_list': ''}
        
        try:
            # 移除超时限制，只等待达到目标数量或被取消
            while (len(collected_tags) < target_count and 
                   not self.cancel_requested):
                # 简单延迟，降低CPU占用
                time.sleep(RFID_CPU_DELAY)
            
            # 判断结果
            if self.cancel_requested:
                logger.info("RFID读取被用户取消")
                success = False
            else:
                success = len(collected_tags) >= target_count
            
            # 存储到db_data_list（所有标签ID都是十进制格式）
            if collected_tags:
                db_data_list['rfid_list'] = ','.join(sorted(collected_tags))
                logger.info(f"标签已存储到db_data_list (十进制格式): {db_data_list['rfid_list']}")
            
            # LED反馈
            if success:
                logger.info("读取完成")
                self.hardware_manager.control_led('green_blink_3')
                self.hardware_manager.control_led('green_off')
            else:
                logger.warning(f"读取未完成，仅读取到{len(collected_tags)}个标签，LED红灯闪烁3次")
                self.hardware_manager.control_led('red_blink_3')
                self.hardware_manager.control_led('red_off')
            
            return {
                'success': success,
                'tag_count': len(collected_tags),
                'rfid_list': db_data_list.get('rfid_list', '')
            }
            
        except Exception as e:
            logger.error(f"读取过程中发生异常: {e}")
            self.hardware_manager.control_led('red_blink_3')
            self.hardware_manager.control_led('red_off')
            return {'success': False, 'tag_count': len(collected_tags), 'rfid_list': db_data_list.get('rfid_list', '')}
    
    def cancel_reading(self):
        """取消当前RFID读取操作"""
        self.cancel_requested = True
        if self.rfid_manager:
            self.rfid_manager.stop_reading()
        logger.info("RFID读取取消请求已发送")
    
    # ==================== 资源管理 ====================
    def cleanup(self):
        """清理资源"""
        try:
            # 清理硬件管理器
            if hasattr(self, 'hardware_manager'):
                self.hardware_manager.cleanup()
            
            # 清理RFID管理器（包含停止读取、断开连接等）
            if hasattr(self, 'rfid_manager'):
                self.rfid_manager.cleanup()
            
            logger.info("RFID读取器资源清理完成")
        except Exception as e:
            logger.error(f"清理资源失败: {e}")


# 测试函数
if __name__ == "__main__":
    # 智能日志配置
    from config import setup_logging_if_needed
    setup_logging_if_needed()
    
    print("=" * 60)
    print("RFID读取器测试程序")
    print("=" * 60)
    
    # 创建RFID读取器
    rfid_reader = RFIDReader()
    
    try:
        # 硬件管理器已在初始化时自动设置GPIO
        print("硬件管理器初始化成功")
        
        # 测试RFID读取功能（内部会自动处理连接）
        print("\n开始测试RFID标签读取功能...")
        print("请将RFID标签靠近读卡器...")
        
        # 临时修改food_number用于测试
        import config
        original_food_number = config.food_number
        config.food_number = 5  # 测试时读取5个标签
        print(f"测试配置：需要读取{config.food_number}个不同标签")
        
        result = rfid_reader.read_multiple_unique_tags_with_feedback()
        
        # 恢复原始配置
        config.food_number = original_food_number
        
        print("\n" + "=" * 40)
        print("测试结果:")
        print("=" * 40)
        print(f"读取成功: {result['success']}")
        print(f"读取到标签数量: {result['tag_count']}")
        print(f"标签列表 (十进制格式): {result['rfid_list']}")
        
        if result['success']:
            print("RFID读取功能测试通过")
        else:
            print("RFID读取功能测试失败")
            print("请检查:")
            print("1. RFID设备是否正确连接")
            print("2. 串口配置是否正确")
            print("3. 设备权限是否足够")
            
    except KeyboardInterrupt:
        print("\n用户中断测试")
    except Exception as e:
        print(f"测试过程中发生错误: {e}")
    finally:
        print("\n正在清理资源...")
        rfid_reader.cleanup()
        print("资源清理完成")
