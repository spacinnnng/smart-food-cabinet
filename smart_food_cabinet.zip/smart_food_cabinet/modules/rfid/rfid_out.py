#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
RFID出库管理器
负责RFID标签读取、出库流程控制和数据库操作
"""

import time
import logging
import sys
import os
from typing import Optional
from datetime import datetime

# 添加项目根目录到Python路径，以便导入config模块
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

from config import HALL_MONITOR_INTERVAL, ActionTypes, StatusTypes

# 延迟导入hardware_manager，避免模块链问题
def get_hardware_manager():
    """延迟导入hardware_manager，避免导入链问题"""
    try:
        import importlib.util
        
        # 直接导入hardware_manager文件
        hardware_manager_path = os.path.join(os.path.dirname(__file__), '..', 'hardware', 'hardware_manager.py')
        spec = importlib.util.spec_from_file_location("hardware_manager", hardware_manager_path)
        hardware_manager_module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(hardware_manager_module)
        return hardware_manager_module.HardwareManager
    except ImportError as e:
        if "RPi" in str(e):
            print("检测到RPi.GPIO导入错误")
            print("提示：RFID模块需要在树莓派上运行，Mac上无法运行")
            print("请在树莓派上运行：python modules/rfid/rfid_out.py")
            return None
        else:
            raise e

# 延迟导入database_manager，避免模块链问题
def get_database_manager():
    """延迟导入database_manager，避免导入链问题"""
    try:
        import importlib.util
        
        # 直接导入data_manager文件
        data_manager_path = os.path.join(os.path.dirname(__file__), '..', 'database', 'data_manager.py')
        spec = importlib.util.spec_from_file_location("data_manager", data_manager_path)
        data_manager_module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(data_manager_module)
        return data_manager_module.DatabaseManager
    except ImportError as e:
        print(f"数据库管理器导入失败: {e}")
        return None

# 使用相对导入，确保从任何目录都能正确找到同目录的rfid_manager
from .rfid_manager import RFIDManager

# 配置日志
logger = logging.getLogger(__name__)

class RFIDOutboundManager:
    """
    RFID出库管理器
    负责霍尔传感器监控、RFID读取、硬件反馈、数据库操作
    """
    
    def __init__(self):
        """初始化出库管理器"""
        # 初始化数据库管理器（使用延迟导入）
        DatabaseManager = get_database_manager()
        if DatabaseManager is None:
            print("数据库管理器初始化失败")
            print("将使用模拟模式运行")
            self.db_manager = None
        else:
            # 为出库监控创建独立的数据库连接，避免线程问题
            # 注意：数据库连接将在出库线程中创建，确保线程安全
            self.DatabaseManager = DatabaseManager
            self.db_manager = None
            logger.info("出库监控数据库管理器已准备")
        
        # 初始化硬件管理器（使用延迟导入）
        HardwareManager = get_hardware_manager()
        if HardwareManager is None:
            print("硬件管理器初始化失败，无法在Mac上运行RFID模块")
            print("请在树莓派上运行此模块")
            exit(1)
        self.hardware_manager = HardwareManager()
        
        # 初始化RFID管理器
        self.rfid_manager = RFIDManager()
        
        # 状态变量
        self.is_monitoring = False
        self.is_door_open = False
        self.is_rfid_reading = False
        
        # 防重复机制：使用复合键记录处理时间
        self.last_process_time = {}  # 记录每个标签的最后处理时间
        
        
        logger.info("RFID出库管理器初始化完成")
    
    # ==================== 主要串联函数 ====================
    # 主要串联函数：整合完整的出库监控流程
    # - 作用：霍尔传感器监控 + 柜门状态处理 + RFID读取控制 + 硬件反馈
    # - 流程：监控霍尔传感器 → 检测柜门开关 → 启动/停止RFID读取 → 处理标签 → 硬件反馈
    def start_outbound_monitoring_with_feedback(self, test_mode: bool = False):
        """
        启动出库监控并提供完整的硬件反馈
        这是一个串联函数，整合了完整的出库监控流程
        
        硬件反馈说明：
        - 监控状态：LED全部关闭，表示出库监控已启动
        - 柜门打开：LED蓝灯亮起，RFID开始读取
        - 检测到标签：蜂鸣器蜂鸣一次（成功）或长鸣一次（失败）
        - 失败情况：红灯闪烁三次
        - 柜门关闭：LED全部关闭，RFID停止读取
        
        业务流程：
        1. 初始化硬件管理器
        2. LED全部关闭，开始监控霍尔传感器
        3. 检测到柜门打开时LED蓝灯亮起，启动RFID读取
        4. 每检测到标签时查询数据库并处理
        5. 柜门关闭时LED全部关闭，停止RFID读取
        6. 持续监控直到手动停止
        
        Args:
            test_mode (bool): 是否为测试模式，测试模式下不发送WebSocket通知
        
        Returns:
            bool: 监控是否成功启动
        """
        if self.is_monitoring:
            logger.warning("出库监控已在运行中")
            return False
        
        logger.info("启动出库监控流程")
        
        # 设置测试模式标志
        self._test_mode = test_mode
        if test_mode:
            logger.info("运行在测试模式下，不会发送WebSocket通知")
        
        # 初始化硬件管理器
        if not self.hardware_manager:
            logger.error("硬件管理器未初始化")
            return False
        
        # 监控状态：所有LED关闭
        self.hardware_manager.control_led('blue_off')
        self.hardware_manager.control_led('green_off')
        self.hardware_manager.control_led('red_off')
        
        self.is_monitoring = True
        logger.info("出库监控已启动，LED全部关闭")
        
        try:
            while self.is_monitoring:
                self.monitor_hall_sensor()
                time.sleep(HALL_MONITOR_INTERVAL)
                
        except KeyboardInterrupt:
            logger.info("用户中断监控")
        except Exception as e:
            logger.error(f"监控过程中发生异常: {e}")
        finally:
            self.cleanup()
        
        return True
    
    # ==================== 霍尔传感器监控 ====================
    # 霍尔传感器监控：检测柜门开关状态
    # - 作用：持续监控霍尔传感器，检测柜门状态变化
    # - 触发：柜门打开时启动RFID读取，柜门关闭时停止RFID读取
    def monitor_hall_sensor(self):
        """监控霍尔传感器状态"""
        try:
            # 使用硬件管理器获取门状态
            door_open = self.hardware_manager.get_door_status()
            
            # 检测状态变化
            if door_open != self.is_door_open:
                if door_open:
                    self.handle_door_open()
                else:
                    self.handle_door_close()
                
                self.is_door_open = door_open
                
        except Exception as e:
            logger.error(f"监控霍尔传感器失败: {e}")
    
    # ==================== 柜门状态处理 ====================
    # 柜门状态处理：响应柜门开关事件
    # - 作用：处理柜门打开/关闭事件，控制LED和RFID读取
    # - 打开：LED蓝灯亮起，启动RFID读取
    # - 关闭：LED全部关闭，停止RFID读取
    def handle_door_open(self):
        """处理柜门打开事件"""
        logger.info("检测到柜门打开，启动出库流程")
        
        # LED蓝灯亮起（表示出库流程开始）
        self.hardware_manager.control_led('blue_on')
        
        # 启动RFID读取（传递测试模式参数）
        self.start_rfid_reading(test_mode=getattr(self, '_test_mode', False))
    
    def handle_door_close(self):
        """处理柜门关闭事件"""
        logger.info("检测到柜门关闭，停止出库流程")
        
        # 停止RFID读取
        self.stop_rfid_reading()
        
        # 关闭LED（回到监控状态）
        self.hardware_manager.control_led('blue_off')
        self.hardware_manager.control_led('red_off')
    
    # ==================== RFID读取控制 ====================
    # RFID读取控制：管理RFID的读取行为（调用rfid_manager的方法）
    # - 作用：启动/停止RFID持续读取
    # - 流程：初始化连接 → 设置自动读卡模式 → 启动读取线程
    # - 注意：这里调用rfid_manager的底层方法，不重复实现
    def start_rfid_reading(self, test_mode: bool = False):
        """启动RFID持续读取"""
        if self.is_rfid_reading:
            return
        
        self.is_rfid_reading = True
        
        # 初始化RFID管理器
        if not self.rfid_manager.init_serial_connection():
            logger.error("初始化RFID串口连接失败")
            return
        
        if not self.rfid_manager.connect():
            logger.error("RFID连接失败")
            return
        
        if not self.rfid_manager.init_auto_read_mode():
            logger.error("初始化自动读卡模式失败")
            return
        
        # 创建标签处理函数（支持测试模式）
        def tag_handler(rfid_id: str):
            self.process_rfid_tag(rfid_id, test_mode)
        
        # 启动RFID读取
        if not self.rfid_manager.start_reading(tag_handler):
            logger.error("启动RFID读取失败")
            return
        
        logger.info("RFID持续读取已启动")
    
    def stop_rfid_reading(self):
        """停止RFID读取"""
        if not self.is_rfid_reading:
            return
        
        self.is_rfid_reading = False
        
        # 停止RFID管理器读取
        self.rfid_manager.stop_reading()
        
        logger.info("RFID持续读取已停止")
    
    # ==================== RFID标签处理 ====================
    # RFID标签处理：处理读取到的RFID标签
    # - 作用：查询数据库，根据结果调用成功/失败处理
    # - 成功：删除RFID记录，发送WebSocket通知
    # - 失败：硬件反馈，发送错误通知
    def process_rfid_tag(self, rfid_id: str, test_mode: bool = False):
        """处理读取到的RFID标签"""
        import time
        
        current_time = time.time()
        
        # 防重复机制：检查是否在短时间内重复处理同一标签
        process_key = f"process_{rfid_id}"
        if process_key in self.last_process_time:
            time_diff = current_time - self.last_process_time[process_key]
            if time_diff < 2.0:  # 2秒内重复处理同一标签，忽略
                logger.info(f"忽略重复标签 (2秒内): {rfid_id}, 时间间隔: {time_diff:.2f}秒")
                return
        
        # 更新处理时间
        self.last_process_time[process_key] = current_time
        
        # 清理过期的处理时间记录（超过10秒的记录）
        expired_tags = [tag for tag, timestamp in self.last_process_time.items() 
                       if current_time - timestamp > 10.0]
        for tag in expired_tags:
            del self.last_process_time[tag]
        
        logger.info(f"处理RFID标签 (十进制格式): {rfid_id}")
        
        # 查询数据库获取食品ID
        food_id = self.query_database(rfid_id)
        
        if food_id:
            # 成功情况：找到对应的食品
            self.handle_success(rfid_id, food_id, test_mode)
        else:
            # 失败情况：未找到对应的食品
            self.handle_failure(rfid_id)
    
    def query_database(self, rfid_id: str) -> Optional[int]:
        """查询数据库获取食品ID"""
        try:
            # 如果数据库管理器未初始化，在出库线程中创建
            if self.db_manager is None:
                if hasattr(self, 'DatabaseManager') and self.DatabaseManager is not None:
                    # 在出库线程中创建独立的数据库连接
                    self.db_manager = self.DatabaseManager()
                    logger.info("在出库线程中创建了独立的数据库连接")
                else:
                    logger.warning("数据库管理器类未初始化，返回模拟数据")
                    return 1  # 返回默认的food_id
            
            # 使用修改后的函数，只返回food_id
            food_id = self.db_manager.get_food_id_by_rfid_id(rfid_id)
            return food_id
        except Exception as e:
            logger.error(f"查询数据库失败: {e}")
            # 如果是线程安全问题，尝试重新创建数据库连接
            if "thread" in str(e).lower() or "same thread" in str(e).lower():
                logger.warning("检测到线程安全问题，尝试重新创建数据库连接")
                try:
                    if hasattr(self, 'DatabaseManager') and self.DatabaseManager is not None:
                        self.db_manager = self.DatabaseManager()
                        logger.info("重新创建数据库连接成功")
                        # 重试查询
                        food_id = self.db_manager.get_food_id_by_rfid_id(rfid_id)
                        return food_id
                except Exception as retry_e:
                    logger.error(f"重试查询仍然失败: {retry_e}")
            return None
    
    # ==================== 出库结果处理 ====================
    # 出库结果处理：处理RFID标签读取的结果
    # - 成功：蜂鸣器响，删除数据库记录，发送WebSocket通知
    # - 失败：蜂鸣器长鸣，红灯闪烁，发送错误通知
    def handle_success(self, rfid_id: str, food_id: int, test_mode: bool = False):
        """处理成功情况"""
        try:
            import time
            current_time = time.time()
            
            # 防重复机制：检查是否在短时间内重复处理同一食品
            success_key = f"success_{food_id}_{rfid_id}"
            if success_key in self.last_process_time:
                time_diff = current_time - self.last_process_time[success_key]
                if time_diff < 2.0:  # 2秒内重复处理同一食品，忽略
                    logger.info(f"忽略重复出库处理 (2秒内): food_id={food_id}, rfid_id={rfid_id}, 时间间隔: {time_diff:.2f}秒")
                    return
            
            # 更新处理时间
            self.last_process_time[success_key] = current_time
            
            # 清理过期的处理时间记录（超过10秒的记录）
            expired_keys = [key for key, timestamp in self.last_process_time.items() 
                           if current_time - timestamp > 10.0]
            for key in expired_keys:
                del self.last_process_time[key]
            
            logger.info(f"成功找到食品，RFID (十进制): {rfid_id}, 食品ID: {food_id}")
            
            # 蜂鸣器蜂鸣一次确认
            self.hardware_manager.beep_once()
            
            # 立即删除该food条目下的该rfid_id
            if self.db_manager is None:
                logger.warning("数据库管理器未初始化，跳过删除操作")
                delete_success = True  # 模拟删除成功
            else:
                delete_success = self.db_manager.delete_food(food_id, rfid_id)
            
            if delete_success:
                logger.info(f"RFID ID (十进制) {rfid_id} 删除成功，食品ID: {food_id}")
                
                # 根据模式选择WebSocket通知方式
                if test_mode:
                    self.send_websocket_notification_test_mode(food_id, rfid_id)
                else:
                    self.send_websocket_notification(food_id, rfid_id)
            else:
                logger.error(f"RFID ID (十进制) {rfid_id} 删除失败，食品ID: {food_id}")
                # 即使数据库删除失败，也发送通知，让用户知道检测到了标签
                if test_mode:
                    self.send_websocket_notification_test_mode(food_id, rfid_id)
                else:
                    self.send_websocket_notification(food_id, rfid_id)
            
        except Exception as e:
            logger.error(f"处理成功情况失败: {e}")
    
    def handle_failure(self, rfid_id: str):
        """处理失败情况"""
        logger.warning(f"未找到RFID (十进制) {rfid_id} 对应的食品信息")
        
        # 蜂鸣器长鸣一次
        self.hardware_manager.beep_long()
        
        # 红灯闪烁三次
        self.hardware_manager.control_led('red_blink_3')
        
        # 通过WebSocket发送失败通知
        self.send_websocket_failure_notification(rfid_id)
    
    # ==================== WebSocket通知 ====================
    # WebSocket通知：向手机端发送出库通知
    # - 成功通知：发送food_id，手机端删除对应食品条目
    # - 失败通知：发送错误信息，手机端显示错误提示
    def send_websocket_failure_notification(self, rfid_id: str):
        """通过WebSocket发送出库失败通知"""
        try:
            notification_data = {
                'status': StatusTypes.SHOW_ERROR_NOTIFICATION,
                'rfid_id': rfid_id,
                'error_message': '未找到对应食品信息',
                'timestamp': datetime.now().isoformat(),
                'message': f'某时间扫码出库失败，请核对食品清单'
            }
            
            # 尝试直接调用WebSocket服务器的推送方法
            try:
                from ..websocket.websocket import broadcast_outbound_notification_sync
                if broadcast_outbound_notification_sync(ActionTypes.ERROR, notification_data):
                    logger.info(f"WebSocket出库失败通知已发送: rfid_id (十进制)={rfid_id}")
                    return True
            except ImportError:
                logger.warning("无法导入WebSocket推送方法，使用回调函数")
            
            # 如果直接调用失败，记录错误
            logger.error("WebSocket推送方法不可用，无法发送失败通知")
            return False
            
        except Exception as e:
            logger.error(f"发送WebSocket失败通知失败: {e}")
            return False
    
    def send_websocket_notification(self, food_id: int, rfid_id: str):
        """通过WebSocket通知小程序出库事件"""
        try:
            notification_data = {
                'status': StatusTypes.DELETE_FOOD_ITEM,
                'food_id': food_id,
                'timestamp': datetime.now().isoformat(),
                'message': f'检测到食品出库，请删除ID为{food_id}的食品条目'
            }
            
            # 尝试直接调用WebSocket服务器的推送方法
            try:
                from ..websocket.websocket import broadcast_outbound_notification_sync
                if broadcast_outbound_notification_sync(ActionTypes.SUCCESS, notification_data):
                    logger.info(f"WebSocket出库通知已发送: food_id={food_id}")
                    return True
            except ImportError:
                logger.warning("无法导入WebSocket推送方法，使用回调函数")
            
            # 如果直接调用失败，记录错误
            logger.error("WebSocket推送方法不可用，无法发送通知")
            return False
            
        except Exception as e:
            logger.error(f"发送WebSocket通知失败: {e}")
            return False
    
    def send_websocket_notification_test_mode(self, food_id: int, rfid_id: str):
        """测试模式下的WebSocket通知（不实际发送）"""
        try:
            notification_data = {
                'status': StatusTypes.DELETE_FOOD_ITEM,
                'food_id': food_id,
                'timestamp': datetime.now().isoformat(),
                'message': f'检测到食品出库，请删除ID为{food_id}的食品条目'
            }
            
            # 测试模式下只打印通知信息，不实际发送
            logger.info(f"[测试模式] WebSocket通知: action={ActionTypes.SUCCESS}, data={notification_data}")
            print(f"📱 [测试模式] 出库通知: 食品ID {food_id}, RFID (十进制) {rfid_id}")
            return True
            
        except Exception as e:
            logger.error(f"测试模式WebSocket通知失败: {e}")
            return False
    
    
    # ==================== 资源管理 ====================
    # 资源管理：清理所有资源
    # - 作用：停止监控，清理硬件管理器、RFID管理器、数据库连接
    # - 注意：调用各组件自己的cleanup方法，避免重复实现
    def cleanup(self):
        """清理资源"""
        try:
            # 停止监控
            self.is_monitoring = False
            
            # 清理硬件管理器
            if self.hardware_manager:
                self.hardware_manager.cleanup()
            
            # 清理RFID管理器（包含停止读取、断开连接等）
            if self.rfid_manager:
                self.rfid_manager.cleanup()
            
            # 关闭数据库连接
            if self.db_manager:
                self.db_manager.close()
            
            logger.info("RFID出库管理器资源清理完成")
            
        except Exception as e:
            logger.error(f"清理资源失败: {e}")
    

# 测试函数
if __name__ == "__main__":
    # 智能日志配置
    from config import setup_logging_if_needed
    setup_logging_if_needed()
    
    print("=" * 60)
    print("RFID出库监控测试程序")
    print("=" * 60)
    
    # 创建出库管理器
    outbound_manager = RFIDOutboundManager()
    
    try:
        # 测试硬件初始化
        print("正在初始化硬件管理器...")
        if outbound_manager.hardware_manager.init_gpio():
            print("硬件管理器初始化成功")
        else:
            print("硬件管理器初始化失败")
            exit(1)
        
        # 测试RFID连接
        print("正在初始化RFID连接...")
        if outbound_manager.rfid_manager.init_serial_connection() and outbound_manager.rfid_manager.connect():
            print("RFID连接成功")
        else:
            print("RFID连接失败")
            print("请检查RFID设备连接")
            exit(1)
        
        # 测试数据库连接
        print("正在测试数据库连接...")
        try:
            outbound_manager.db_manager.init_database()
            print("数据库连接成功")
        except Exception as e:
            print(f"数据库连接失败: {e}")
            print("将使用模拟模式进行测试")
        
        print("\n" + "=" * 40)
        print("开始出库监控测试")
        print("=" * 40)
        print("测试说明:")
        print("1. LED蓝灯将常亮，表示监控已启动")
        print("2. 请打开柜门（模拟霍尔传感器触发）")
        print("3. 将RFID标签靠近读卡器")
        print("4. 观察硬件反馈（蜂鸣器、LED等）")
        print("5. 按 Ctrl+C 停止测试")
        print("=" * 40)
        
        # 启动出库监控（测试模式，不依赖WebSocket）
        outbound_manager.start_outbound_monitoring_with_feedback(test_mode=True)
        
    except KeyboardInterrupt:
        print("\n用户中断测试")
    except Exception as e:
        print(f"测试过程中发生错误: {e}")
        import traceback
        print(f"详细错误信息: {traceback.format_exc()}")
    finally:
        print("\n正在清理资源...")
        outbound_manager.cleanup()
        print("资源清理完成")
