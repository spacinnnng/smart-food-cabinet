#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
RFID管理器
整合RFID的通用功能，包括串口初始化、自动读卡模式设置、标签解析等
"""

import serial
import time
import logging
import threading
import sys
import os
from typing import Optional, Callable, Dict, Any

# 添加项目根目录到Python路径，以便导入config模块
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

from config import (
    RFID_PORT, RFID_TIMEOUT,
    RFID_COMMAND_RESPONSE_DELAY, RFID_CPU_DELAY
)

# 配置日志
logger = logging.getLogger(__name__)

class RFIDManager:
    """
    RFID管理器
    负责RFID的基础功能：串口管理、自动读卡模式、标签解析
    """
    
    def __init__(self):
        """初始化RFID管理器"""
        self.serial_conn = None
        self.is_connected = False
        self.is_auto_mode = False
        self.is_reading = False
        self.reading_thread = None
        self.tag_callback = None
        
        logger.info("RFID管理器初始化完成")
    
    # ==================== 连接管理 ====================
    def connect(self) -> bool:
        """连接RFID读取器（检查连接状态）"""
        try:
            if self.serial_conn and self.serial_conn.is_open:
                self.is_connected = True
                logger.info("RFID读取器连接状态正常")
                return True
            else:
                logger.warning("RFID读取器未连接")
                self.is_connected = False
                return False
        except Exception as e:
            logger.error(f"RFID读取器连接检查异常: {e}")
            self.is_connected = False
            return False
    
    def disconnect(self):
        """断开RFID读取器连接"""
        if self.serial_conn and self.serial_conn.is_open:
            self.serial_conn.close()
            self.is_connected = False
            logger.info("RFID读取器连接已断开")
            
            # 等待一小段时间确保串口完全释放
            import time
            time.sleep(0.1)
    
    def init_serial_connection(self) -> bool:
        """初始化串口连接"""
        try:
            # 检查是否已经有连接
            if self.serial_conn and self.serial_conn.is_open:
                logger.info("RFID串口连接已存在")
                return True
            
            # 关闭现有连接（如果存在但未打开）
            if self.serial_conn:
                try:
                    self.serial_conn.close()
                except:
                    pass
            
            self.serial_conn = serial.Serial(
                port=RFID_PORT,
                baudrate=9600,
                parity=serial.PARITY_NONE,
                stopbits=serial.STOPBITS_ONE,
                bytesize=serial.EIGHTBITS,
                timeout=RFID_TIMEOUT
            )
            
            # 清空串口缓冲区，确保连接建立后没有残留数据
            self.serial_conn.reset_input_buffer()
            self.serial_conn.reset_output_buffer()
            
            logger.info(f"RFID串口连接初始化完成，端口: {RFID_PORT}")
            return True
            
        except Exception as e:
            logger.error(f"RFID串口连接初始化失败: {e}")
            return False
    
    # ==================== 读取模式控制 ====================
    # 读取模式控制：配置RFID硬件的工作模式
    # - 作用：发送硬件命令，设置RFID为"自动读卡模式"
    # - 时机：在开始读取之前，只需要执行一次
    # - 本质：硬件配置，告诉RFID硬件如何工作
    def init_auto_read_mode(self) -> bool:
        """
        初始化自动读卡模式
        
        Returns:
            bool: 初始化是否成功
        """
        if not self.serial_conn or not self.serial_conn.is_open:
            logger.error("RFID串口未连接")
            return False
        
        try:
            # 清空串口缓冲区，确保没有残留数据
            self.serial_conn.reset_input_buffer()
            self.serial_conn.reset_output_buffer()
            logger.debug("已清空串口缓冲区")
            
            # 步骤1：关闭蜂鸣器LED提示命令（0xC2）
            close_buzzer_cmd = bytes([0x03, 0x08, 0xC2, 0x20, 0x00, 0x00, 0x00, 0x16])
            self.serial_conn.write(close_buzzer_cmd)
            logger.debug(f"已发送关闭提示命令：{close_buzzer_cmd.hex().upper()}")
            time.sleep(RFID_COMMAND_RESPONSE_DELAY)
            
            # 读取0xC2命令返回结果
            resp_c2 = self.serial_conn.read(8)
            if len(resp_c2) == 8 and resp_c2[4] == 0x00:
                logger.info("关闭提示成功")
            else:
                logger.warning(f"关闭提示失败，返回数据：{resp_c2.hex().upper() if resp_c2 else '无'}")
                return False
            
            # 步骤2：设置自动读卡号（主动上传）命令（0xC1）
            auto_read_cmd = bytes([0x03, 0x08, 0xC1, 0x20, 0x02, 0x00, 0x00, 0x17])
            self.serial_conn.write(auto_read_cmd)
            logger.debug(f"已发送自动读卡号模式命令：{auto_read_cmd.hex().upper()}")
            time.sleep(RFID_COMMAND_RESPONSE_DELAY)
            
            # 读取0xC1命令返回结果
            resp_c1 = self.serial_conn.read(8)
            if len(resp_c1) == 8 and resp_c1[4] == 0x00:
                logger.info("自动读卡号模式设置成功")
            else:
                logger.warning(f"自动读卡号模式设置失败，返回数据：{resp_c1.hex().upper() if resp_c1 else '无'}")
                return False
            
            # 步骤3：设置自动读卡方式为"读一次"（0xC8命令）
            auto_read_mode_cmd = bytes([0x03, 0x08, 0xC8, 0x20, 0x00, 0x00, 0x00, 0x1C])
            self.serial_conn.write(auto_read_mode_cmd)
            logger.debug(f"已发送自动读卡方式命令（读一次）：{auto_read_mode_cmd.hex().upper()}")
            time.sleep(RFID_COMMAND_RESPONSE_DELAY)
            
            # 读取0xC8命令返回结果
            resp_c8 = self.serial_conn.read(8)
            if len(resp_c8) == 8 and resp_c8[4] == 0x00:
                logger.info("自动读卡方式设置成功（读一次）")
                self.is_auto_mode = True
                return True
            else:
                logger.error(f"自动读卡方式设置失败，返回数据：{resp_c8.hex().upper() if resp_c8 else '无'}")
                return False
                
        except Exception as e:
            logger.error(f"初始化自动读卡模式失败: {e}")
            return False
    
    def _hex_to_decimal(self, hex_string: str) -> str:
        """
        将十六进制字符串转换为十进制字符串
        
        Args:
            hex_string: 十六进制字符串（如 "12345678"）
            
        Returns:
            str: 十进制字符串（如 "305419896"）
        """
        try:
            # 将十六进制字符串转换为整数，再转换为十进制字符串
            decimal_value = int(hex_string, 16)
            return str(decimal_value)
        except ValueError as e:
            logger.error(f"十六进制转十进制失败: {hex_string}, 错误: {e}")
            return hex_string  # 转换失败时返回原值
    
    def _parse_tag_response(self, response: bytes) -> Optional[str]:
        """
        解析RFID标签响应（私有方法）
        
        Args:
            response: 12字节的响应数据
            
        Returns:
            str: 标签ID（十进制格式），失败返回None
        """
        try:
            if len(response) == 12:
                # 解析返回包：命令类型=0x04，返回命令=0x02，状态=0x00为成功
                if response[0] == 0x04 and response[2] == 0x02 and response[4] == 0x00:
                    # 先获取十六进制格式
                    hex_card_id = response[7:11].hex().upper()
                    # 转换为十进制格式
                    decimal_card_id = self._hex_to_decimal(hex_card_id)
                    logger.debug(f"成功解析标签ID: 十六进制={hex_card_id}, 十进制={decimal_card_id}")
                    return decimal_card_id
                else:
                    logger.debug(f"响应数据格式不正确: {response.hex().upper()}")
                    return None
            else:
                logger.debug(f"响应数据长度不正确: {len(response)}")
                return None
                
        except Exception as e:
            logger.error(f"解析标签响应失败: {e}")
            return None
    
    # ==================== 读取控制 ====================
    # 读取控制：控制RFID的读取行为
    # - 作用：启动/停止读取线程，处理标签数据
    # - 时机：每次需要读取时都要调用
    # - 本质：软件控制，管理读取线程和数据处理
    def start_reading(self, tag_callback: Callable[[str], None]) -> bool:
        """
        开始RFID读取
        
        Args:
            tag_callback: 标签读取回调函数，参数为标签ID
            
        Returns:
            bool: 启动是否成功
        """
        if self.is_reading:
            logger.warning("RFID读取已在运行中")
            return False
        
        if not self.is_auto_mode:
            logger.error("自动读卡模式未初始化")
            return False
        
        self.tag_callback = tag_callback
        self.is_reading = True
        
        # 启动读取线程
        self.reading_thread = threading.Thread(target=self._reading_loop)
        self.reading_thread.daemon = True
        self.reading_thread.start()
        
        logger.info("RFID读取已启动")
        return True
    
    def stop_reading(self):
        """停止RFID读取"""
        if not self.is_reading:
            return
        
        self.is_reading = False
        
        # 等待读取线程结束
        if self.reading_thread and self.reading_thread.is_alive():
            self.reading_thread.join(timeout=1.0)
        
        logger.info("RFID读取已停止")
    
    def _reading_loop(self):
        """RFID读取循环"""
        logger.info("进入RFID读取循环")
        
        try:
            while self.is_reading:
                # 监听自动读卡数据
                resp_data = self.serial_conn.read(12)
                
                if len(resp_data) == 12:
                    # 解析标签ID
                    card_id = self._parse_tag_response(resp_data)
                    
                    if card_id and self.tag_callback:
                        logger.info(f"读取到RFID标签: {card_id}")
                        # 调用回调函数处理标签
                        self.tag_callback(card_id)
                
                # 短暂延迟，降低CPU占用
                time.sleep(RFID_CPU_DELAY)
                
        except Exception as e:
            logger.error(f"RFID读取循环异常: {e}")
    
    def send_command(self, command: bytes, wait_response: bool = True) -> Optional[bytes]:
        """
        发送RFID命令
        
        Args:
            command: 要发送的命令
            wait_response: 是否等待响应
            
        Returns:
            bytes: 响应数据，失败返回None
        """
        try:
            if not self.serial_conn or not self.serial_conn.is_open:
                logger.error("RFID串口未连接")
                return None
            
            # 清空串口缓冲区，确保没有残留数据
            self.serial_conn.reset_input_buffer()
            self.serial_conn.reset_output_buffer()
            
            self.serial_conn.write(command)
            logger.debug(f"已发送命令: {command.hex().upper()}")
            
            if wait_response:
                time.sleep(RFID_COMMAND_RESPONSE_DELAY)
                response = self.serial_conn.read(8)
                return response
            
            return None
            
        except Exception as e:
            logger.error(f"发送RFID命令失败: {e}")
            return None
    
    # ==================== 资源管理 ====================
    def cleanup(self):
        """清理RFID资源"""
        try:
            # 停止读取
            self.stop_reading()
            
            # 断开连接
            self.disconnect()
            
            logger.info("RFID资源清理完成")
            
        except Exception as e:
            logger.error(f"RFID资源清理失败: {e}")


# 使用示例
if __name__ == "__main__":
    # 智能日志配置
    from config import setup_logging_if_needed
    setup_logging_if_needed()
    
    # 创建RFID管理器
    rfid_manager = RFIDManager()
    
    try:
        # 初始化串口连接
        if rfid_manager.init_serial_connection():
            # 连接
            if rfid_manager.connect():
                # 初始化自动读卡模式
                if rfid_manager.init_auto_read_mode():
                    # 开始读取（标签读取结果会通过日志记录）
                    if rfid_manager.start_reading(lambda tag_id: None):
                        print("RFID读取已启动，按Ctrl+C停止...")
                        # 持续运行直到用户中断
                        try:
                            while True:
                                time.sleep(1)
                        except KeyboardInterrupt:
                            print("\n用户中断程序")
                    else:
                        print("启动RFID读取失败")
                else:
                    print("初始化自动读卡模式失败")
            else:
                print("RFID连接失败")
        else:
            print("初始化串口连接失败")
            
    except KeyboardInterrupt:
        print("\n用户中断程序")
    finally:
        rfid_manager.cleanup()
