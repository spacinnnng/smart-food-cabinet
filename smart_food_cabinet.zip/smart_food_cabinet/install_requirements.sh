#!/bin/bash

# 智能食品柜项目依赖安装脚本
# 适用于64位ARM架构的树莓派

echo "🔧 开始安装智能食品柜项目依赖..."

# 检查Python版本
python_version=$(python3 --version 2>&1 | cut -d' ' -f2)
echo "🐍 Python版本: $python_version"

# 检查是否在虚拟环境中
if [[ "$VIRTUAL_ENV" == "" ]]; then
    echo "⚠️  警告：未检测到虚拟环境"
    echo "建议在虚拟环境中运行此脚本"
    read -p "是否继续安装？(y/n): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        echo "❌ 安装已取消"
        exit 1
    fi
fi

# 升级pip
echo "📦 升级pip..."
python3 -m pip install --upgrade pip

# 安装基础依赖
echo "📦 安装基础依赖..."
pip install numpy==1.24.3
pip install python-dotenv==1.0.0
pip install PyYAML==6.0

# 安装硬件控制库
echo "🔌 安装硬件控制库..."
pip install RPi.GPIO==0.7.1
pip install pyserial==3.5

# 安装Web框架和网络库
echo "🌐 安装Web框架和网络库..."
pip install Flask==2.3.3
pip install websockets==11.0.3
pip install aiohttp>=3.8.0,<4.0.0

# 安装图像处理库
echo "🖼️  安装图像处理库..."
pip install opencv-python==4.8.1.78

# 安装深度学习框架（CPU版本，适合ARM架构）
echo "🧠 安装深度学习框架..."
pip install torch==2.1.0+cpu torchvision==0.16.0+cpu --index-url https://download.pytorch.org/whl/cpu

# 安装YOLO模型库
echo "🎯 安装YOLO模型库..."
pip install ultralytics==8.0.196

# 安装腾讯云SDK
echo "☁️  安装腾讯云SDK..."
pip install tencentcloud-sdk-python==3.0.1035

# 验证安装
echo "🔍 验证安装..."
python3 -c "
import torch
import torchvision
import cv2
import numpy as np
import RPi.GPIO as GPIO
import serial
import flask
import websockets
import aiohttp
import ultralytics
import tencentcloud
print('✅ 所有依赖库导入成功！')
print(f'PyTorch版本: {torch.__version__}')
print(f'OpenCV版本: {cv2.__version__}')
print(f'NumPy版本: {np.__version__}')
print(f'aiohttp版本: {aiohttp.__version__}')
"

if [ $? -eq 0 ]; then
    echo ""
    echo "🎉 依赖安装完成！"
    echo ""
    echo "📋 已安装的库:"
    echo "  - PyTorch 2.1.0 (CPU版本)"
    echo "  - TorchVision 0.16.0 (CPU版本)"
    echo "  - OpenCV 4.8.1.78"
    echo "  - NumPy 1.24.3"
    echo "  - RPi.GPIO 0.7.1"
    echo "  - PySerial 3.5"
    echo "  - Flask 2.3.3"
    echo "  - WebSockets 11.0.3"
    echo "  - aiohttp >=3.8.0,<4.0.0"
    echo "  - Ultralytics 8.0.196"
    echo "  - 腾讯云SDK 3.0.1035"
    echo ""
    echo "🚀 现在可以运行智能食品柜项目了！"
    echo ""
    echo "📖 运行方式:"
    echo "  - 完整系统: python main.py"
    echo "  - 仅Web服务器: python test_web_server.py"
    echo "  - 仅HTTP服务器(非树莓派): python test_web_only.py"
else
    echo "❌ 安装验证失败"
    echo "请检查安装日志并手动安装缺失的库"
    exit 1
fi
