#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
智能食品柜配置文件
负责读取环境变量和设置默认配置值
"""

import os
from pathlib import Path
from dotenv import load_dotenv

# 获取项目根目录的绝对路径
PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))

# 加载环境变量文件
load_dotenv(os.path.join(PROJECT_ROOT, 'config.env'))

# ==================== 项目路径配置 ====================
# === 图片处理相关路径 ===
IMAGES_TEMP_DIR = Path(PROJECT_ROOT) / 'images_tempt'      # 临时图片存储目录
IMAGES_RETURN_DIR = Path(PROJECT_ROOT) / 'images_return'   # 处理结果图片目录

# ==================== 环境变量配置 ====================
# === 腾讯云OCR配置 ===
SECRET_ID = os.getenv("TENCENTCLOUD_SECRET_ID")
SECRET_KEY = os.getenv("TENCENTCLOUD_SECRET_KEY")
OCR_ENDPOINT = os.getenv("OCR_ENDPOINT", "ocr.tencentcloudapi.com")

# === 调试和日志配置 ===
DEBUG_MODE = os.getenv("DEBUG_MODE", "false").lower() == "true"
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO").upper()
ENABLE_FILE_LOGGING = os.getenv("ENABLE_FILE_LOGGING", "true").lower() == "true"

# === 数据库配置 ===
# 支持在config.env中配置完整的数据库路径，如果配置的是相对路径则相对于项目根目录
DATABASE_PATH = os.getenv("DATABASE_PATH", "sfc_database.db")
if not os.path.isabs(DATABASE_PATH):
    # 如果是相对路径，相对于项目根目录
    DATABASE_PATH = os.path.join(PROJECT_ROOT, DATABASE_PATH)

# === Web API配置 ===
WEB_API_HOST = '0.0.0.0'               # Web API服务器监听地址
WEB_API_PORT = int(os.getenv("WEB_API_PORT", "8080"))  # Web服务器监听端口
WEBSOCKET_PORT = int(os.getenv("WEBSOCKET_PORT", "5001"))  # WebSocket服务器监听端口

# ==================== 硬件配置 ====================
# === GPIO引脚配置 ===
LED_RED_PIN = 17        # RGB红色GPIO引脚（BCM编号）
LED_GREEN_PIN = 22      # RGB绿色GPIO引脚（BCM编号）
LED_BLUE_PIN = 27       # RGB蓝色GPIO引脚（BCM编号）
BUZZER_PIN = 18         # 蜂鸣器GPIO引脚（BCM编号）

# === 霍尔传感器配置 ===
HALL_SENSOR_PIN = 23                    # GPIO引脚号（BCM编号）
HALL_SENSOR_PULL_UP_DOWN = "DOWN"       # 上拉/下拉设置（DOWN:下拉电阻, UP:上拉电阻）
HALL_SENSOR_BOUNCETIME = 0.2            # 防抖时间（秒，避免机械振动造成的误触发）
HALL_SENSOR_ACTIVE_LOW = True            # 低电平有效（低电平=有磁场=门关, 高电平=无磁场=门开）
HALL_SENSOR_TYPE = "HS-S40A"            # 传感器型号（用于日志记录和调试）

# === RFID硬件配置 ===
RFID_PORT = "/dev/ttyS0"                # 串口设备路径
RFID_TIMEOUT = 1.0                      # 串口超时时间（秒）
RFID_TAG_TIMEOUT = 60.0                 # 标签读取超时时间（秒，1分钟）
RFID_BAUDRATE = int(os.getenv("RFID_BAUDRATE", "9600"))  # 串口波特率（M3650A-HA默认9600Bit/S）

# ==================== 软件配置 ====================
# === YOLO模型配置 ===
YOLO_DETECT_MODEL_PATH = os.path.join(PROJECT_ROOT, "models/yolo_detect.pt")                    # 通用检测模型路径
YOLO_CATEGORY_MODEL_PATH = os.path.join(PROJECT_ROOT, "models/yolo_category_detector.pt")       # 食品分类模型路径
YOLO_TABLE_DATE_MODEL_PATH = os.path.join(PROJECT_ROOT, "models/yolo_table_date_detector.pt")   # 表格日期检测模型路径
YOLO_CONFIDENCE_THRESHOLD = 0.25       # 置信度阈值（0.0-1.0，值越高检测越严格）
YOLO_IOU_THRESHOLD = 0.45              # IoU阈值（0.0-1.0，用于非极大值抑制）

# === 硬件控制配置 ===
HALL_MONITOR_INTERVAL = 0.1             # 霍尔传感器监控间隔（秒）
RFID_TAG_READ_INTERVAL = 1.0            # RFID标签读取间隔（秒）
RFID_COMMAND_RESPONSE_DELAY = 0.1       # RFID命令响应延迟（秒）
RFID_CPU_DELAY = 0.1                    # CPU延迟间隔（秒）
BUZZER_SHORT_DURATION = 0.5             # 蜂鸣器短鸣持续时间（秒）
BUZZER_LONG_DURATION = 2.0              # 蜂鸣器长鸣持续时间（秒）
LED_BLINK_INTERVAL = 0.5                # LED闪烁间隔（秒）

# === Web客户端配置 ===
MAX_INBOUND_IMAGES = int(os.getenv("MAX_INBOUND_IMAGES", "6"))  # 最大入库图片数量
MAX_SHARE_IMAGES = int(os.getenv("MAX_SHARE_IMAGES", "4"))      # 最大分享图片数量
DEFAULT_USER_NAME = os.getenv("DEFAULT_USER_NAME", "体验用户")  # 默认用户名
DEFAULT_USER_AVATAR = os.getenv("DEFAULT_USER_AVATAR", "/images/default-avatar.png")  # 默认用户头像路径
SUPPORTED_ALLERGENS = os.getenv("SUPPORTED_ALLERGENS", "含麸质的谷物及其制品(如小麦、黑麦、大麦、燕麦);乳及乳制品(包括乳糖);坚果及其果仁类制品;蛋类及其制品;花生及其制品;大豆及其制品;甲壳纲类动物及其制品(如虾、龙虾、蟹等);鱼类及其制品").split(";")  # 支持的过敏原列表

# ==================== 消息类型常量定义 ====================
class MessageTypes:
    """
    消息类型常量类
    统一管理所有WebSocket通信的消息类型msg_type
    """
    
    # ==================== 系统消息类型 ====================
    CONNECTION = 'connection'           # 连接相关消息
    ERROR = 'error'                    # 错误消息
    # ==================== 入库流程消息类型 ====================
    INBOUND_FOOD_NUMBER = 'inbound_food_number'    # 食品数量设置
    INBOUND_READY = 'inbound_ready'                # 准备完成
    INBOUND_RFID_READING = 'inbound_rfid_reading'  # RFID读取
    INBOUND_RFID_RESULT = 'inbound_rfid_result'    # RFID读取结果
    INBOUND_OCR_PROCESS = 'inbound_info_process'    # 信息处理请求
    INBOUND_UPLOAD_SUCCESS = 'inbound_upload_success' # 上传成功确认
    INBOUND_END = 'inbound_end'                    # 入库结束
    INBOUND_CANCEL = 'inbound_cancel'              # 中止入库请求
    
    # ==================== 出库流程消息类型 ====================
    OUTBOUND_NOTIFICATION = 'outbound_notification' # 出库通知（树莓派主动推送）

# ==================== 状态类型常量定义 ====================
class StatusTypes:
    """
    状态类型常量类
    统一管理所有WebSocket通信的status状态值
    """
    
    # ==================== 系统状态 ====================
    CONNECTED = 'connected'            # 连接成功
    ERROR = 'error'                    # 错误状态
    
    # ==================== 入库流程状态 ====================
    # 图片、食品数量设置阶段
    READY = 'ready'                    # 准备完成
    
    # RFID读取阶段
    RFID_READING_SUCCESS = 'rfid_reading_success' # RFID读取成功
    RFID_READING_TIMEOUT = 'rfid_reading_timeout' # RFID读取超时
    
    # 数据处理阶段
    DATA_READY = 'data_ready'          # 数据准备完成
    IMAGES_READY = 'images_ready'      # 图片处理完成
    
    # 完成阶段
    UPLOAD_SUCCESS = 'upload_success'  # 上传成功
    END_SUCCESS = 'end_success'        # 入库结束成功
    CANCELLED = 'cancelled'            # 取消成功
    
    # ==================== 出库流程状态 ====================
    # 出库广播
    DELETE_FOOD_ITEM = 'delete_food_item'           # 删除食品条目
    SHOW_ERROR_NOTIFICATION = 'show_error_notification'  # 显示错误通知
    
    # ==================== 通用状态 ====================
    SUCCESS = 'success'              # 操作成功
# ==================== Action常量定义 ====================
class ActionTypes:
    """
    Action类型常量类
    统一管理所有WebSocket通信和硬件控制的action值
    """
    
    # ==================== WebSocket通信Action ====================
    # 结果类Action
    SUCCESS = 'success'     # 完全成功
    FAILED = 'failed'       # 完全失败
    TIMEOUT = 'timeout'     # 超时
    
    # 数据类Action
    IMAGES = 'images'       # 图片处理完成
    DATA = 'data'           # 数据通知
    
    # 通知类Action
    ERROR = 'error'         # 错误
    
    
    # ==================== 硬件控制Action ====================
    # LED控制
    GREEN_ON = 'green_on'           # 绿灯开启
    GREEN_OFF = 'green_off'         # 绿灯关闭
    RED_ON = 'red_on'               # 红灯开启
    RED_OFF = 'red_off'             # 红灯关闭
    BLUE_ON = 'blue_on'             # 蓝灯开启
    BLUE_OFF = 'blue_off'           # 蓝灯关闭
    GREEN_BLINK_3 = 'green_blink_3' # 绿灯闪烁3次
    RED_BLINK_3 = 'red_blink_3'     # 红灯闪烁3次
    
    # 蜂鸣器控制
    BEEP_ONCE = 'beep_once'         # 蜂鸣一次
    BEEP_LONG = 'beep_long'         # 长蜂鸣
    BEEP_OFF = 'beep_off'           # 停止蜂鸣
    
    # 硬件状态同步
    HARDWARE_STATUS = 'hardware_status'  # 硬件状态更新

# ==================== 全局数据存储 ====================
# 全局静态变量：用于在多个模块间共享的数据库数据字典
# 所有文件导入的都是同一个实例，确保数据一致性
# 格式: {'rifd_id': 'xxx', 'name': 'xxx', 'production_date': 'xxx', ...}
db_data_list = {}

# 当前类食品数量
food_number = 1

# ==================== 日志配置工具 ====================
def setup_logging_if_needed():
    """
    智能日志配置函数
    如果日志系统还没有配置，则进行配置
    如果已经配置，则不做任何操作
    """
    import logging
    
    # 检查是否已经有处理器配置
    if not logging.getLogger().handlers:
        # 获取日志级别
        log_level = getattr(logging, LOG_LEVEL)
        
        # 配置日志
        logging.basicConfig(
            level=log_level,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        print(f"日志系统已配置，级别: {LOG_LEVEL}")
    else:
        print("日志系统已配置，跳过重复配置")

# ==================== 配置验证 ====================
def validate_config():
    """
    验证配置的完整性
    """
    errors = []
    
    # 检查必须的环境变量
    if not SECRET_ID:
        errors.append("TENCENTCLOUD_SECRET_ID 未设置")
    if not SECRET_KEY:
        errors.append("TENCENTCLOUD_SECRET_KEY 未设置")
    
    # 检查日志级别
    valid_log_levels = ['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL']
    if LOG_LEVEL not in valid_log_levels:
        errors.append(f"LOG_LEVEL 必须是以下值之一: {', '.join(valid_log_levels)}")
    
    return errors

# 配置验证
CONFIG_ERRORS = validate_config()

if CONFIG_ERRORS:
    print("配置错误:")
    for error in CONFIG_ERRORS:
        print(f"  - {error}")
    print("请检查 config.env 文件中的配置")

# ==================== 配置导出 ====================
__all__ = [
    # 新增：项目根目录
    'PROJECT_ROOT',
    
    # 环境变量配置
    'SECRET_ID', 'SECRET_KEY', 'OCR_ENDPOINT',
    'DEBUG_MODE', 'LOG_LEVEL', 'ENABLE_FILE_LOGGING',
    'DATABASE_PATH', 'WEB_API_HOST', 'WEB_API_PORT', 'WEBSOCKET_PORT',
    'IMAGES_TEMP_DIR', 'IMAGES_RETURN_DIR',
    
    # 硬件配置
    'LED_GREEN_PIN', 'LED_RED_PIN', 'LED_BLUE_PIN', 'BUZZER_PIN',
    'HALL_SENSOR_PIN', 'HALL_SENSOR_PULL_UP_DOWN', 'HALL_SENSOR_BOUNCETIME',
    'HALL_SENSOR_ACTIVE_LOW', 'HALL_SENSOR_TYPE',
    'RFID_PORT', 'RFID_TIMEOUT', 'RFID_TAG_TIMEOUT', 'RFID_BAUDRATE',
    
    # 软件配置
    'YOLO_DETECT_MODEL_PATH', 'YOLO_CATEGORY_MODEL_PATH', 'YOLO_TABLE_DATE_MODEL_PATH', 
    'YOLO_CONFIDENCE_THRESHOLD', 'YOLO_IOU_THRESHOLD',
    'HALL_MONITOR_INTERVAL', 'RFID_TAG_READ_INTERVAL', 'RFID_COMMAND_RESPONSE_DELAY', 
    'RFID_CPU_DELAY', 'BUZZER_SHORT_DURATION', 'BUZZER_LONG_DURATION', 'LED_BLINK_INTERVAL',
    
    # Web客户端配置
    'MAX_INBOUND_IMAGES', 'MAX_SHARE_IMAGES', 'DEFAULT_USER_NAME', 'DEFAULT_USER_AVATAR', 'SUPPORTED_ALLERGENS',
    
    # 消息类型、状态类型和Action常量
    'MessageTypes', 'StatusTypes', 'ActionTypes',
    
    # 全局数据
    'db_data_list', 'food_number',
    
    # 系统配置
    'CONFIG_ERRORS',
    
    # 工具函数
    'cleanup_error_images'
]

# ==================== 工具函数 ====================

def cleanup_error_images():
    """
    清理images_tempt目录中的错误图片（以下划线开头的文件）
    
    这个函数会删除所有以下划线开头的图片文件，但保留正常的图片文件。
    正常的图片文件命名格式为：food_时间戳.jpg（中间有下划线，但以下划线开头）
    错误文件格式为：_1.jpg, _2.jpg 等（以下划线开头）
    
    Returns:
        int: 清理的文件数量
    """
    import os
    import logging
    
    logger = logging.getLogger(__name__)
    cleaned_count = 0
    
    try:
        if not IMAGES_TEMP_DIR.exists():
            logger.debug(f"图片目录不存在: {IMAGES_TEMP_DIR}")
            return 0
        
        # 获取目录中的所有文件
        all_files = list(IMAGES_TEMP_DIR.iterdir())
        logger.debug(f"检查目录 {IMAGES_TEMP_DIR} 中的文件: {[f.name for f in all_files]}")
        
        for file_path in all_files:
            if file_path.is_file():
                filename = file_path.name
                
                # 只清理以下划线开头的图片文件
                if (filename.startswith('_') and 
                    filename.lower().endswith(('.jpg', '.jpeg', '.png', '.bmp', '.tiff'))):
                    
                    try:
                        file_path.unlink()  # 删除文件
                        cleaned_count += 1
                        logger.debug(f"已删除错误图片: {filename}")
                    except Exception as e:
                        logger.error(f"删除错误图片失败: {filename}, 错误: {e}")
        
        if cleaned_count > 0:
            logger.info(f"图片清理完成，共删除 {cleaned_count} 个错误文件")
        else:
            logger.debug("未发现需要清理的错误图片文件")
            
        return cleaned_count
        
    except Exception as e:
        logger.error(f"清理图片时发生错误: {e}")
        return 0
