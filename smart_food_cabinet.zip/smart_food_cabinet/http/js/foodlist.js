/**
 * 食品列表管理类
 * 负责食品列表的搜索、编辑等功能
 */

class FoodListManager {
    constructor() {
        this.searchQuery = '';
        this.filteredFoods = [];
        this.init();
    }

    /**
     * 初始化食品列表管理器
     */
    init() {
        this.setupEventListeners();
    }

    /**
     * 设置事件监听器
     */
    setupEventListeners() {
        // 搜索输入事件
        const searchInput = document.getElementById('searchInput');
        if (searchInput) {
            searchInput.addEventListener('input', (e) => {
                this.searchFoods(e.target.value);
            });
        }
    }

    /**
     * 搜索食品
     * @param {string} query 搜索关键词
     */
    searchFoods(query) {
        this.searchQuery = query.toLowerCase().trim();
        
        if (this.searchQuery === '') {
            this.filteredFoods = app.foodList;
        } else {
            this.filteredFoods = app.foodList.filter(food => 
                food.name && food.name.toLowerCase().includes(this.searchQuery)
            );
        }
        
        this.renderFoodList();
    }

    /**
     * 清空搜索
     */
    clearSearch() {
        const searchInput = document.getElementById('searchInput');
        if (searchInput) {
            searchInput.value = '';
        }
        this.searchFoods('');
    }

    /**
     * 渲染食品列表
     */
    renderFoodList() {
        const foodListContainer = document.getElementById('foodList');
        if (!foodListContainer) return;

        const foodsToShow = this.searchQuery ? this.filteredFoods : app.foodList;

        if (foodsToShow.length === 0) {
            const emptyMessage = this.searchQuery ? 
                `没有找到包含"${this.searchQuery}"的食品` : 
                '暂无食品数据';
            foodListContainer.innerHTML = `<div class="empty-state">${emptyMessage}</div>`;
            return;
        }

        const foodListHTML = foodsToShow.map(food => {
            // 使用第一张图片作为封面，如果没有图片则使用默认图片
            let imageSrc = 'images/default-food.png';
            if (food.image) {
                // 如果是base64格式的图片
                if (food.image.startsWith('data:image/')) {
                    imageSrc = food.image;
                } else {
                    // 如果是URL格式
                    imageSrc = food.image;
                }
            } else if (food.detailImages && food.detailImages.length > 0) {
                // 如果没有主图但有详情图片，使用第一张详情图片
                imageSrc = food.detailImages[0];
            }

            return `
                <div class="food-item" data-food-id="${food.food_id}">
                    <div class="food-info">
                        <img src="${imageSrc}" alt="${food.name}" class="food-image">
                        <div class="food-details">
                            <div class="food-name editable" contenteditable="true" data-field="name">${food.name || '未知食品'}</div>
                            <div class="food-meta">净含量: ${food.net_weight || '未知'}</div>
                            <div class="food-meta">生产日期: ${food.production_date || '未知'}</div>
                            <div class="food-meta">保质期: ${food.expiry_period || '未知'}</div>
                            <div class="food-meta">在库数量: ${food.quantity || 0}</div>
                            ${this.renderAllergenTags(food.allergens)}
                            <button class="detail-btn" onclick="app.showFoodDetail(${food.food_id})">查看详情</button>
                        </div>
                    </div>
                </div>
            `;
        }).join('');

        foodListContainer.innerHTML = foodListHTML;
        
        // 添加可编辑字段事件
        this.setupEditableFields();
    }

    /**
     * 设置可编辑字段
     */
    setupEditableFields() {
        const editableFields = document.querySelectorAll('.editable');
        editableFields.forEach(field => {
            // 移除之前的事件监听器
            field.removeEventListener('blur', this.handleFieldEdit);
            
            // 添加新的事件监听器
            field.addEventListener('blur', this.handleFieldEdit.bind(this));
            
            // 添加焦点样式
            field.addEventListener('focus', (e) => {
                e.target.style.background = '#e8f5e8';
                e.target.style.outline = '2px solid #4CAF50';
            });
            
            field.addEventListener('blur', (e) => {
                e.target.style.background = '';
                e.target.style.outline = '';
            });
        });
    }

    /**
     * 处理字段编辑
     * @param {Event} event 事件对象
     */
    handleFieldEdit(event) {
        const foodItem = event.target.closest('.food-item');
        const foodId = parseInt(foodItem.dataset.foodId);
        const fieldName = event.target.dataset.field;
        const newValue = event.target.textContent.trim();
        
        // 更新本地数据
        const food = app.foodList.find(f => f.food_id === foodId);
        if (food) {
            const oldValue = food[fieldName];
            food[fieldName] = newValue;
            
            // 保存到本地存储
            app.saveUserData();
            
            // 发送WebSocket消息更新数据库
            this.updateFoodInDatabase(foodId, fieldName, newValue);
            
            // 显示保存提示
            if (oldValue !== newValue) {
                app.showMessage('已保存', 'success');
            }
            
            // 更新通知（如果相关字段改变）
            if (fieldName === 'production_date' || fieldName === 'expiry_period') {
                app.updateNotifications();
            }
        }
    }

    /**
     * 渲染过敏原标签
     * @param {Array} allergens 过敏原数组
     * @returns {string} HTML字符串
     */
    renderAllergenTags(allergens) {
        if (!allergens || allergens.length === 0) return '';
        
        const userAllergens = app.userAllergens;
        const matchedAllergens = allergens.filter(allergen => 
            userAllergens.includes(allergen)
        );

        if (matchedAllergens.length === 0) return '';

        return `
            <div class="allergen-tags">
                ${matchedAllergens.map(allergen => 
                    `<span class="allergen-tag">${allergen}</span>`
                ).join('')}
            </div>
        `;
    }

    /**
     * 刷新食品列表
     */
    refreshFoodList() {
        this.searchFoods(this.searchQuery);
        app.showMessage('食品列表已刷新', 'success');
    }

    /**
     * 添加新食品
     * @param {Object} foodData 食品数据
     */
    addFood(foodData) {
        const newFood = {
            id: Date.now(), // 简单的ID生成
            ...foodData,
            createdAt: new Date().toISOString()
        };
        
        app.foodList.push(newFood);
        app.saveUserData();
        this.renderFoodList();
        app.updateNotifications();
    }

    /**
     * 删除食品
     * @param {number} foodId 食品ID
     */
    deleteFood(foodId) {
        const food = app.foodList.find(f => f.food_id === foodId);
        if (food) {
            // 添加到废纸篓
            app.trashItems.push({
                ...food,
                deletedAt: new Date().toISOString()
            });
            
            // 从食品列表移除
            app.foodList = app.foodList.filter(f => f.food_id !== foodId);
            app.saveUserData();
            this.renderFoodList();
            app.updateNotifications();
            
            app.showMessage('食品已删除', 'success');
        }
    }

    /**
     * 获取搜索结果
     * @returns {Array} 搜索结果
     */
    getSearchResults() {
        return this.filteredFoods;
    }

    /**
     * 获取搜索关键词
     * @returns {string} 搜索关键词
     */
    getSearchQuery() {
        return this.searchQuery;
    }

    /**
     * 更新食品信息（仅本地存储）
     * @param {number} foodId 食品ID
     * @param {string} fieldName 字段名
     * @param {string} newValue 新值
     */
    updateFoodInDatabase(foodId, fieldName, newValue) {
        // 注意：现在食品列表完全基于本地存储，不再需要同步到服务器数据库
        console.log(`食品信息已更新到本地存储: foodId=${foodId}, field=${fieldName}, value=${newValue}`);
        
        // 数据已经通过 app.saveUserData() 保存到本地存储
        // 这里只需要记录日志即可
    }
}

// 创建食品列表管理器实例
const foodListManager = new FoodListManager();

// 全局函数
function searchFoods(query) {
    foodListManager.searchFoods(query);
}

function clearSearch() {
    foodListManager.clearSearch();
}

function refreshFoodList() {
    foodListManager.refreshFoodList();
}
