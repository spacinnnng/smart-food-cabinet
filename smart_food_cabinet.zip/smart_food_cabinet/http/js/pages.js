/**
 * 页面管理类
 * 负责页面切换和导航
 */

class PageManager {
    constructor() {
        this.currentPage = 'home';
        this.init();
    }

    /**
     * 初始化页面管理器
     */
    init() {
        this.setupPageEvents();
    }

    /**
     * 设置页面事件
     */
    setupPageEvents() {
        // 监听模态框点击关闭
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('modal')) {
                e.target.style.display = 'none';
            }
        });
    }

    /**
     * 显示页面
     * @param {string} pageName 页面名称
     */
    showPage(pageName) {
        // 隐藏所有页面
        const pages = document.querySelectorAll('.page');
        pages.forEach(page => {
            page.classList.remove('active');
        });

        // 显示目标页面
        const targetPage = document.getElementById(`${pageName}-page`);
        if (targetPage) {
            targetPage.classList.add('active');
            this.currentPage = pageName;
        }

        // 更新导航状态
        this.updateNavigation(pageName);

        // 页面特定的初始化
        this.initPageContent(pageName);
    }

    /**
     * 更新导航状态
     * @param {string} pageName 页面名称
     */
    updateNavigation(pageName) {
        const navItems = document.querySelectorAll('.nav-item');
        navItems.forEach(item => {
            item.classList.remove('active');
        });

        // 激活对应的导航项
        const targetNav = document.querySelector(`[onclick="showPage('${pageName}')"]`);
        if (targetNav) {
            targetNav.classList.add('active');
        }
    }

    /**
     * 初始化页面内容
     * @param {string} pageName 页面名称
     */
    initPageContent(pageName) {
        switch (pageName) {
            case 'home':
                this.initHomePage();
                break;
            case 'foodlist':
                this.initFoodListPage();
                break;
            case 'diary':
                this.initDiaryPage();
                break;
            case 'settings':
                this.initSettingsPage();
                break;
            case 'trash':
                this.initTrashPage();
                break;
        }
    }

    /**
     * 初始化首页
     */
    initHomePage() {
        // 更新通知显示
        app.updateNotifications();
        console.log('首页已初始化');
    }

    /**
     * 初始化食品列表页面
     */
    initFoodListPage() {
        app.loadFoodList();
        console.log('食品列表页面已初始化');
    }

    /**
     * 初始化社交页面
     */
    initSocialPage() {
        this.loadSocialContent();
        console.log('社交页面已初始化');
    }

    /**
     * 初始化设置页面
     */
    initSettingsPage() {
        this.loadUserInfo();
        console.log('设置页面已初始化');
    }

    /**
     * 初始化废纸篓页面
     */
    initTrashPage() {
        this.loadTrashContent();
        console.log('废纸篓页面已初始化');
    }

    /**
     * 初始化日记页面
     */
    initDiaryPage() {
        this.loadDiaryContent();
    }

    /**
     * 加载日记内容
     */
    loadDiaryContent() {
        const container = document.getElementById('diaryContent');
        if (!container) return;

        if (app.socialPosts.length === 0) {
            container.innerHTML = '<div class="empty-state">暂无日记内容</div>';
            return;
        }

        const diaryHTML = app.socialPosts.map(post => `
            <div class="diary-post">
                <div class="post-header">
                    <img src="${post.userAvatar || 'images/default-avatar.png'}" alt="用户头像" class="user-avatar">
                    <div class="user-info">
                        <div class="user-name">${post.userName}</div>
                        <div class="post-time">${post.time}</div>
                    </div>
                    <div class="post-actions-header">
                        <button class="delete-btn" onclick="deletePost(${post.id})" title="删除日记">
                            <span class="delete-icon">🗑️</span>
                        </button>
                    </div>
                </div>
                <div class="post-content">
                    ${post.title ? `<h4 class="diary-title">${post.title}</h4>` : ''}
                    <p>${post.content}</p>
                    ${post.images ? `
                        <div class="post-images">
                            ${post.images.map(img => `<img src="${img}" alt="日记图片" class="post-image">`).join('')}
                        </div>
                    ` : ''}
                </div>
                <div class="post-actions">
                    <button class="action-btn ${post.isFavorited ? 'favorited' : ''}" onclick="favoritePost(${post.id})">
                        <span class="action-icon">${post.isFavorited ? '⭐' : '☆'}</span>
                    </button>
                    <button class="action-btn" onclick="commentPost(${post.id})">
                        <span class="action-icon">💬</span>
                        <span class="action-count">${post.comments || 0}</span>
                    </button>
                </div>
                ${post.commentList && post.commentList.length > 0 ? `
                    <div class="comments-section">
                        <div class="comments-header">评论 (${post.commentList.length})</div>
                        <div class="comments-list">
                            ${post.commentList.map(comment => `
                                <div class="comment-item">
                                    <div class="comment-header">
                                        <span class="comment-user">${comment.user}</span>
                                        <span class="comment-time">${comment.time}</span>
                                    </div>
                                    <div class="comment-content">${comment.content}</div>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                ` : ''}
            </div>
        `).join('');

        container.innerHTML = diaryHTML;
    }

    /**
     * 加载用户信息
     */
    loadUserInfo() {
        const userName = document.getElementById('userName');
        const userAvatar = document.getElementById('userAvatar');

        if (userName) {
            userName.textContent = localStorage.getItem('userName') || '体验用户';
        }
        if (userAvatar) {
            userAvatar.src = localStorage.getItem('userAvatar') || 'images/default-avatar.png';
        }
    }

    /**
     * 加载废纸篓内容
     */
    loadTrashContent() {
        const container = document.getElementById('trashContent');
        if (!container) return;

        if (app.trashItems.length === 0) {
            container.innerHTML = '<div class="empty-state">废纸篓为空</div>';
            return;
        }

        const trashHTML = app.trashItems.map(item => `
            <div class="trash-item">
                <div class="trash-info">
                    <img src="${item.image || 'images/default-food.png'}" alt="${item.name}" class="trash-image">
                    <div class="trash-details">
                        <div class="trash-name">${item.name}</div>
                        <div class="trash-time">出库时间: ${new Date(item.deletedAt).toLocaleString()}</div>
                    </div>
                </div>
            </div>
        `).join('');

        container.innerHTML = trashHTML;
    }

    /**
     * 显示分享页面
     */
    showSharePage() {
        this.showPage('share');
    }

    /**
     * 显示废纸篓页面
     */
    showTrashPage() {
        this.showPage('trash');
    }

    /**
     * 显示用户反馈
     */
    showFeedback() {
        const feedback = prompt('请输入您的反馈意见：');
        if (feedback) {
            app.showMessage('感谢您的反馈！', 'success');
        }
    }

    /**
     * 退出登录
     */
    logout() {
        // 显示确认对话框
        confirm('确定要退出当前账号吗？');
        // 不执行任何实际操作
    }
}

// 创建页面管理器实例
const pageManager = new PageManager();

// 全局函数
function showPage(pageName) {
    pageManager.showPage(pageName);
}

function showSharePage() {
    pageManager.showSharePage();
}

function showTrashPage() {
    pageManager.showTrashPage();
}

function showFeedback() {
    pageManager.showFeedback();
}

function logout() {
    pageManager.logout();
}

function closeModal() {
    const modals = document.querySelectorAll('.modal');
    modals.forEach(modal => {
        modal.style.display = 'none';
    });
}

// 收藏/取消收藏功能
function favoritePost(postId) {
    const post = app.socialPosts.find(p => p.id === postId);
    if (post) {
        const today = new Date().toLocaleDateString();
        const title = post.title || '无标题日记';
        
        if (post.isFavorited) {
            // 取消收藏
            console.log('取消收藏:', title); // 调试日志
            post.isFavorited = false;
            app.saveUserData();
            pageManager.loadDiaryContent();
            
            // 添加取消收藏通知
            app.addDiaryNotification('unfavorite', today, `你取消了收藏【${title}】`);
            
            app.showMessage('已取消收藏', 'info');
        } else {
            // 添加收藏
            console.log('添加收藏:', title); // 调试日志
            post.isFavorited = true;
            app.saveUserData();
            pageManager.loadDiaryContent();
            
            // 添加收藏通知
            app.addDiaryNotification('favorite', today, `你收藏了【${title}】`);
            
            app.showMessage('收藏成功！', 'success');
        }
    }
}

// 评论功能
function commentPost(postId) {
    const comment = prompt('请输入评论内容：');
    if (comment) {
        const post = app.socialPosts.find(p => p.id === postId);
        if (post) {
            // 初始化评论数组
            if (!post.commentList) {
                post.commentList = [];
            }
            
            // 添加新评论
            const newComment = {
                id: Date.now(),
                content: comment,
                time: new Date().toLocaleString(),
                user: localStorage.getItem('userName') || '用户'
            };
            
            post.commentList.push(newComment);
            post.comments = post.commentList.length; // 更新评论数量
            app.saveUserData();
            pageManager.loadDiaryContent();
            
            // 添加日记评论通知
            const today = new Date().toLocaleDateString();
            const title = post.title || '无标题日记';
            app.addDiaryNotification('comment', today, `你评论了【${title}】`);
            
            app.showMessage('评论成功！', 'success');
        }
    }
}

// 删除日记功能
function deletePost(postId) {
    const post = app.socialPosts.find(p => p.id === postId);
    if (!post) return;
    
    // 显示确认删除弹窗
    const confirmDelete = confirm(`确定要删除日记"${post.title || '无标题日记'}"吗？\n\n删除后将无法恢复！`);
    
    if (confirmDelete) {
        // 从日记列表中删除该帖子
        app.socialPosts = app.socialPosts.filter(p => p.id !== postId);
        
        // 添加删除通知
        const today = new Date().toLocaleDateString();
        console.log('正在添加删除通知:', post.title || '无标题日记'); // 调试日志
        app.addDiaryNotification('delete', today, `你删除了一条日记【${post.title || '无标题日记'}】`);
        console.log('删除通知已添加'); // 调试日志
        
        // 保存数据
        app.saveUserData();
        
        // 重新加载日记内容
        pageManager.loadDiaryContent();
        
        // 显示删除成功消息
        app.showMessage('日记已删除', 'success');
    }
}
