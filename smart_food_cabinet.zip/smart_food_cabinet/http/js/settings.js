/**
 * 设置管理类
 * 负责用户设置、过敏原配置等功能
 */

class SettingsManager {
    constructor() {
        this.init();
    }

    /**
     * 初始化设置管理器
     */
    init() {
        this.setupEventListeners();
        this.loadSettings();
    }

    /**
     * 设置事件监听器
     */
    setupEventListeners() {
        // 过敏原设置事件
        const allergenCheckboxes = document.querySelectorAll('.allergen-item input[type="checkbox"]');
        allergenCheckboxes.forEach(checkbox => {
            checkbox.addEventListener('change', (e) => {
                this.updateAllergenSettings();
            });
        });
    }

    /**
     * 加载设置
     */
    loadSettings() {
        this.loadUserInfo();
        this.loadAllergenSettings();
        this.loadNetworkSettings();
    }

    /**
     * 加载用户信息
     */
    loadUserInfo() {
        const userName = document.getElementById('userName');
        const userAvatar = document.getElementById('userAvatar');

        if (userName) {
            userName.textContent = localStorage.getItem('userName') || '体验用户';
        }
        if (userAvatar) {
            userAvatar.src = localStorage.getItem('userAvatar') || 'images/default-avatar.png';
        }
    }

    /**
     * 加载过敏原设置
     */
    loadAllergenSettings() {
        const userAllergens = JSON.parse(localStorage.getItem('userAllergens') || '[]');
        const allergenCheckboxes = document.querySelectorAll('.allergen-item input[type="checkbox"]');
        
        allergenCheckboxes.forEach(checkbox => {
            checkbox.checked = userAllergens.includes(checkbox.value);
        });
    }

    /**
     * 加载网络设置
     */
    loadNetworkSettings() {
        const raspberryPiIP = document.getElementById('raspberryPiIP');
        const connectionStatus = document.getElementById('connectionStatus');
        
        if (raspberryPiIP) {
            raspberryPiIP.value = localStorage.getItem('raspberryPiIP') || '183.172.187.250';
        }
        
        if (connectionStatus) {
            const isConnected = wsManager.getConnectionStatus();
            connectionStatus.textContent = isConnected ? '已连接' : '未连接';
            connectionStatus.className = `connection-status-text ${isConnected ? 'connected' : 'disconnected'}`;
        }
    }

    /**
     * 更新过敏原设置
     */
    updateAllergenSettings() {
        const allergenCheckboxes = document.querySelectorAll('.allergen-item input[type="checkbox"]');
        const userAllergens = [];
        
        allergenCheckboxes.forEach(checkbox => {
            if (checkbox.checked) {
                userAllergens.push(checkbox.value);
            }
        });
        
        // 保存到本地存储
        localStorage.setItem('userAllergens', JSON.stringify(userAllergens));
        
        // 更新应用数据
        app.userAllergens = userAllergens;
        
        // 更新通知和食品列表
        app.updateNotifications();
        app.loadFoodList();
        
        app.showMessage('过敏原设置已保存', 'success');
    }

    /**
     * 显示废纸篓页面
     */
    showTrashPage() {
        pageManager.showPage('trash');
    }

    /**
     * 显示用户反馈
     */
    showFeedback() {
        const feedback = prompt('请输入您的反馈意见：');
        if (feedback && feedback.trim()) {
            // 这里可以将反馈发送到服务器
            app.showMessage('感谢您的反馈！', 'success');
        }
    }

    /**
     * 连接到树莓派
     */
    async connectToRaspberryPi() {
        const ipInput = document.getElementById('raspberryPiIP');
        const connectBtn = document.querySelector('.connect-btn');
        const connectionStatus = document.getElementById('connectionStatus');
        
        if (!ipInput || !connectBtn) return;
        
        const ip = ipInput.value.trim();
        if (!ip) {
            app.showMessage('请输入树莓派IP地址', 'error');
            return;
        }
        
        // 验证IP地址格式
        const ipRegex = /^(\d{1,3}\.){3}\d{1,3}$/;
        if (!ipRegex.test(ip)) {
            app.showMessage('请输入有效的IP地址', 'error');
            return;
        }
        
        // 保存IP地址
        localStorage.setItem('raspberryPiIP', ip);
        
        // 更新按钮状态
        connectBtn.disabled = true;
        connectBtn.textContent = '连接中...';
        
        try {
            // 断开现有连接
            if (wsManager.getConnectionStatus()) {
                wsManager.disconnect();
            }
            
            // 尝试连接
            await wsManager.connect(ip, 5001);
            
            // 更新连接状态
            if (connectionStatus) {
                connectionStatus.textContent = '已连接';
                connectionStatus.className = 'connection-status-text connected';
            }
            
            app.showMessage('连接成功！', 'success');
            
        } catch (error) {
            // 连接失败
            if (connectionStatus) {
                connectionStatus.textContent = '连接失败';
                connectionStatus.className = 'connection-status-text disconnected';
            }
            
            app.showMessage('连接失败: ' + error.message, 'error');
        } finally {
            // 恢复按钮状态
            connectBtn.disabled = false;
            connectBtn.textContent = '连接';
        }
    }

    /**
     * 退出登录
     */
    logout() {
        // 显示确认对话框，但无论选择什么都只是关闭弹窗
        confirm('确定要退出当前账号吗？');
        // 不执行任何实际操作
    }

    /**
     * 获取过敏原设置
     * @returns {Array} 过敏原数组
     */
    getAllergenSettings() {
        return JSON.parse(localStorage.getItem('userAllergens') || '[]');
    }

    /**
     * 设置过敏原
     * @param {Array} allergens 过敏原数组
     */
    setAllergenSettings(allergens) {
        localStorage.setItem('userAllergens', JSON.stringify(allergens));
        app.userAllergens = allergens;
        this.loadAllergenSettings();
    }

    /**
     * 获取用户信息
     * @returns {Object} 用户信息对象
     */
    getUserInfo() {
        return {
            name: localStorage.getItem('userName') || '体验用户',
            avatar: localStorage.getItem('userAvatar') || 'images/default-avatar.png'
        };
    }

    /**
     * 设置用户信息
     * @param {Object} userInfo 用户信息对象
     */
    setUserInfo(userInfo) {
        if (userInfo.name) {
            localStorage.setItem('userName', userInfo.name);
        }
        if (userInfo.avatar) {
            localStorage.setItem('userAvatar', userInfo.avatar);
        }
        
        this.loadUserInfo();
    }

    /**
     * 获取树莓派IP设置
     * @returns {string} IP地址
     */
    getRaspberryPiIP() {
        return localStorage.getItem('raspberryPiIP') || '183.172.187.250';
    }

    /**
     * 设置树莓派IP
     * @param {string} ip IP地址
     */
    setRaspberryPiIP(ip) {
        localStorage.setItem('raspberryPiIP', ip);
    }

    /**
     * 重置所有设置
     */
    resetAllSettings() {
        if (confirm('确定要重置所有设置吗？这将清除所有本地数据。')) {
            localStorage.clear();
            app.showMessage('设置已重置', 'success');
            
            // 重新加载页面
            setTimeout(() => {
                location.reload();
            }, 1000);
        }
    }

    /**
     * 导出设置
     */
    exportSettings() {
        const settings = {
            userAllergens: this.getAllergenSettings(),
            userInfo: this.getUserInfo(),
            raspberryPiIP: this.getRaspberryPiIP(),
            exportTime: new Date().toISOString()
        };
        
        const dataStr = JSON.stringify(settings, null, 2);
        const dataBlob = new Blob([dataStr], { type: 'application/json' });
        
        const link = document.createElement('a');
        link.href = URL.createObjectURL(dataBlob);
        link.download = 'smart-food-cabinet-settings.json';
        link.click();
        
        app.showMessage('设置已导出', 'success');
    }

    /**
     * 导入设置
     */
    importSettings() {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = '.json';
        
        input.onchange = (e) => {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = (e) => {
                    try {
                        const settings = JSON.parse(e.target.result);
                        
                        if (settings.userAllergens) {
                            this.setAllergenSettings(settings.userAllergens);
                        }
                        
                        if (settings.userInfo) {
                            this.setUserInfo(settings.userInfo);
                        }
                        
                        if (settings.raspberryPiIP) {
                            this.setRaspberryPiIP(settings.raspberryPiIP);
                        }
                        
                        app.showMessage('设置已导入', 'success');
                    } catch (error) {
                        app.showMessage('导入失败：文件格式错误', 'error');
                    }
                };
                reader.readAsText(file);
            }
        };
        
        input.click();
    }
}

// 创建设置管理器实例
const settingsManager = new SettingsManager();

// 全局函数
function showTrashPage() {
    settingsManager.showTrashPage();
}

function showFeedback() {
    settingsManager.showFeedback();
}

function logout() {
    settingsManager.logout();
}

function connectToRaspberryPi() {
    settingsManager.connectToRaspberryPi();
}
