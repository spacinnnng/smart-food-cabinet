/**
 * 主应用程序类
 * 负责页面逻辑和用户交互
 */

class SmartFoodCabinetApp {
    constructor() {
        this.currentPage = 'home';
        this.foodList = [];
        this.userAllergens = [];
        this.socialPosts = [];
        this.trashItems = [];
        this.currentNotificationCard = 0;
        this.init();
    }

    /**
     * 初始化应用
     */
    init() {
        this.loadUserData();
        this.setupEventListeners();
        this.connectWebSocket();
        this.loadFoodList();
        this.updateNotifications();
        this.setupNotificationCards();
    }

    /**
     * 加载用户数据
     */
    loadUserData() {
        // 从本地存储加载用户数据
        this.userAllergens = JSON.parse(localStorage.getItem('userAllergens') || '[]');
        this.foodList = JSON.parse(localStorage.getItem('foodList') || '[]');
        this.socialPosts = JSON.parse(localStorage.getItem('socialPosts') || '[]');
        this.trashItems = JSON.parse(localStorage.getItem('trashItems') || '[]');
        
        // 创建测试数据
        if (this.socialPosts.length === 0) {
            this.createTestSocialData();
        }
        
        // 更新过敏原设置界面
        this.updateAllergenSettings();
    }

    /**
     * 创建测试社交数据（仅用于开发测试）
     */
    createTestSocialData() {
        // 仅在开发环境中创建测试数据
        if (window.location.hostname !== 'localhost' && window.location.hostname !== '127.0.0.1') {
            return;
        }
        
        const testPosts = [
            {
                id: 1,
                userName: '美食达人',
                userAvatar: 'images/default-avatar.png',
                title: '今天的早餐',
                content: '今天尝试了新的食谱，味道很棒！推荐给大家试试看。',
                images: [],
                favorites: 3,
                comments: 2,
                isFavorited: false,
                commentList: [
                    {
                        id: 1,
                        content: '看起来很好吃！',
                        time: new Date(Date.now() - 1 * 60 * 60 * 1000).toLocaleString(),
                        user: '用户'
                    },
                    {
                        id: 2,
                        content: '能分享一下食谱吗？',
                        time: new Date(Date.now() - 30 * 60 * 1000).toLocaleString(),
                        user: '用户'
                    }
                ],
                time: new Date(Date.now() - 2 * 60 * 60 * 1000).toLocaleString(),
                createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString()
            },
            {
                id: 2,
                userName: '健康生活',
                userAvatar: 'images/default-avatar.png',
                title: '营养沙拉制作',
                content: '分享一个简单的沙拉制作方法，营养又美味！',
                images: [],
                favorites: 1,
                comments: 0,
                isFavorited: false,
                commentList: [],
                time: new Date(Date.now() - 4 * 60 * 60 * 1000).toLocaleString(),
                createdAt: new Date(Date.now() - 4 * 60 * 60 * 1000).toISOString()
            }
        ];
        
        this.socialPosts = testPosts;
        this.saveUserData();
    }

    /**
     * 保存用户数据
     */
    saveUserData() {
        localStorage.setItem('userAllergens', JSON.stringify(this.userAllergens));
        localStorage.setItem('foodList', JSON.stringify(this.foodList));
        localStorage.setItem('socialPosts', JSON.stringify(this.socialPosts));
        localStorage.setItem('trashItems', JSON.stringify(this.trashItems));
    }

    /**
     * 设置事件监听器
     */
    setupEventListeners() {
        // 设置WebSocket事件监听
        wsManager.setOnConnect(() => {
            try {
                console.log('onConnectCallback开始执行');
                this.showMessage('连接成功', 'success');
                console.log('onConnectCallback执行完成');
            } catch (error) {
                console.error('onConnectCallback执行失败:', error);
                throw error;
            }
        });

        wsManager.setOnDisconnect(() => {
            this.showMessage('连接断开', 'error');
        });

        wsManager.setOnError((error) => {
            this.showMessage('连接错误: ' + error.message, 'error');
        });

        // 注册消息处理器
        this.registerMessageHandlers();
    }

    /**
     * 注册消息处理器
     */
    registerMessageHandlers() {
        // 连接相关
        wsManager.registerHandler('connection', 'success', (message) => {
            console.log('连接确认:', message);
        });

        // 入库流程
        wsManager.registerHandler('inbound_ready', 'success', (message) => {
            console.log('准备完成:', message);
        });

        wsManager.registerHandler('inbound_rfid_result', 'success', (message) => {
            console.log('RFID读取成功:', message);
            this.handleRfidSuccess(message);
        });

        wsManager.registerHandler('inbound_info_process', 'success', (message) => {
            console.log('信息处理完成:', message);
            this.handleInfoProcessSuccess(message);
        });

        wsManager.registerHandler('inbound_info_process', 'images', (message) => {
            console.log('图片处理完成:', message);
            this.handleImagesReady(message);
        });

        wsManager.registerHandler('inbound_upload_success', 'success', (message) => {
            console.log('上传成功确认:', message);
            this.handleUploadSuccess(message);
        });

        wsManager.registerHandler('inbound_end', 'success', (message) => {
            console.log('入库结束:', message);
            this.handleInboundEnd(message);
        });

        wsManager.registerHandler('inbound_cancel', 'success', (message) => {
            console.log('入库取消:', message);
            this.handleInboundCancel(message);
        });

        // 出库流程
        wsManager.registerHandler('outbound_notification', 'success', (message) => {
            console.log('出库通知处理器被调用:', message);
            this.handleOutboundNotification(message);
        });

        // 错误处理
        wsManager.registerHandler('error', 'error', (message) => {
            console.error('收到错误消息:', message);
            this.showMessage(message.data.error_message, 'error');
        });
    }

    /**
     * 连接WebSocket
     */
    async connectWebSocket() {
        try {
            // 使用自动连接方法
            const success = await wsManager.autoConnect();
            if (success) {
                // 启用自动重连
                wsManager.enableAutoReconnect();
                console.log('WebSocket自动连接成功');
            } else {
                console.log('WebSocket自动连接失败，将在后台继续尝试重连');
            }
        } catch (error) {
            console.error('WebSocket连接失败:', error);
            // 不显示错误消息
            console.log('请在设置页面中配置正确的树莓派IP地址');
        }
    }

    /**
     * 设置通知卡片
     */
    setupNotificationCards() {
        const cards = document.querySelectorAll('.notification-card');
        const indicators = document.querySelectorAll('.indicator');
        
        // 添加触摸事件
        let startX = 0;
        let currentX = 0;
        let isDragging = false;
        
        const notificationCards = document.querySelector('.notification-cards');
        
        notificationCards.addEventListener('touchstart', (e) => {
            startX = e.touches[0].clientX;
            isDragging = true;
        });
        
        notificationCards.addEventListener('touchmove', (e) => {
            if (!isDragging) return;
            currentX = e.touches[0].clientX;
        });
        
        notificationCards.addEventListener('touchend', () => {
            if (!isDragging) return;
            isDragging = false;
            
            const diffX = startX - currentX;
            const threshold = 50;
            
            if (Math.abs(diffX) > threshold) {
                if (diffX > 0) {
                    this.nextNotificationCard();
                } else {
                    this.prevNotificationCard();
                }
            }
        });
        
        // 指示器点击事件
        indicators.forEach((indicator, index) => {
            indicator.addEventListener('click', () => {
                this.showNotificationCard(index);
            });
        });
    }

    /**
     * 显示下一个通知卡片
     */
    nextNotificationCard() {
        const totalCards = document.querySelectorAll('.notification-card').length;
        this.currentNotificationCard = (this.currentNotificationCard + 1) % totalCards;
        this.showNotificationCard(this.currentNotificationCard);
    }

    /**
     * 显示上一个通知卡片
     */
    prevNotificationCard() {
        const totalCards = document.querySelectorAll('.notification-card').length;
        this.currentNotificationCard = (this.currentNotificationCard - 1 + totalCards) % totalCards;
        this.showNotificationCard(this.currentNotificationCard);
    }

    /**
     * 显示指定通知卡片
     * @param {number} index 卡片索引
     */
    showNotificationCard(index) {
        const cards = document.querySelectorAll('.notification-card');
        const indicators = document.querySelectorAll('.indicator');
        
        cards.forEach((card, i) => {
            card.classList.toggle('active', i === index);
        });
        
        indicators.forEach((indicator, i) => {
            indicator.classList.toggle('active', i === index);
        });
        
        this.currentNotificationCard = index;
    }

    /**
     * 更新通知
     */
    updateNotifications() {
        this.updateExpiredFoods();
        this.updateAllergenFoods();
        this.updateInboundNotifications();
        this.updateDiaryNotifications();
    }

    /**
     * 更新过期食品通知
     */
    updateExpiredFoods() {
        const expiredFoods = this.getExpiredFoods();
        const container = document.getElementById('expiredList');
        const countElement = document.getElementById('expiredCount');
        
        if (countElement) {
            countElement.textContent = expiredFoods.length;
        }
        
        if (!container) return;

        if (expiredFoods.length === 0) {
            container.innerHTML = '<div class="notification-item">暂无过期食品</div>';
            return;
        }

        const expiredHTML = expiredFoods.map(food => `
            <div class="notification-item">
                <strong>${food.name}</strong><br>
                <small>距离保质期还剩 ${food.days} 天</small>
            </div>
        `).join('');

        // 添加清空按钮
        const clearButton = `
            <div class="notification-clear-section">
                <button class="clear-notifications-btn" onclick="app.clearExpiredFoods()">
                    <span class="clear-icon">🗑️</span>
                    <span class="clear-text">清空所有通知</span>
                </button>
            </div>
        `;

        container.innerHTML = expiredHTML + clearButton;
    }

    /**
     * 更新过敏原食品通知
     */
    updateAllergenFoods() {
        const allergenFoods = this.getAllergenFoods();
        const container = document.getElementById('allergenList');
        const countElement = document.getElementById('allergenCount');
        
        if (countElement) {
            countElement.textContent = allergenFoods.length;
        }
        
        if (!container) return;

        if (allergenFoods.length === 0) {
            container.innerHTML = '<div class="notification-item">暂无过敏原食品</div>';
            return;
        }

        const allergenHTML = allergenFoods.map(food => `
            <div class="notification-item">
                <strong>${food.name}</strong><br>
                <small>可能含有: ${food.allergens.join(', ')}</small>
            </div>
        `).join('');

        // 添加清空按钮
        const clearButton = `
            <div class="notification-clear-section">
                <button class="clear-notifications-btn" onclick="app.clearAllergenFoods()">
                    <span class="clear-icon">🗑️</span>
                    <span class="clear-text">清空所有通知</span>
                </button>
            </div>
        `;

        container.innerHTML = allergenHTML + clearButton;
    }

    /**
     * 更新日记通知
     */
    updateDiaryNotifications() {
        const diaryNotifications = this.getDiaryNotifications();
        const container = document.getElementById('diaryList');
        const countElement = document.getElementById('diaryCount');
        
        if (countElement) {
            countElement.textContent = diaryNotifications.length;
        }
        
        if (!container) return;

        if (diaryNotifications.length === 0) {
            container.innerHTML = '<div class="notification-item">暂无日记通知</div>';
            return;
        }

        const diaryHTML = diaryNotifications.map(notification => {
            const timeAgo = this.getTimeAgo(notification.timestamp);
            let typeIcon = '📝';
            if (notification.type === 'publish') {
                typeIcon = '📝';
            } else if (notification.type === 'comment') {
                typeIcon = '💬';
            } else if (notification.type === 'favorite') {
                typeIcon = '⭐';
            } else if (notification.type === 'unfavorite') {
                typeIcon = '☆';
            } else if (notification.type === 'delete') {
                typeIcon = '🗑️';
            }
            
            return `
                <div class="notification-item ${notification.read ? 'read' : 'unread'}" data-id="${notification.id}">
                    <div class="notification-icon">${typeIcon}</div>
                    <div class="notification-content">
                        <div class="notification-user">${notification.date}</div>
                        <div class="notification-text">${notification.content}</div>
                        <div class="notification-time">${timeAgo}</div>
                    </div>
                </div>
            `;
        }).join('');

        // 添加清空按钮
        const clearButton = `
            <div class="notification-clear-section">
                <button class="clear-notifications-btn" onclick="app.clearDiaryNotifications()">
                    <span class="clear-icon">🗑️</span>
                    <span class="clear-text">清空所有通知</span>
                </button>
            </div>
        `;
        
        container.innerHTML = diaryHTML + clearButton;
    }

    /**
     * 更新出入库通知
     */
    updateInboundNotifications() {
        const inboundNotifications = this.getInboundNotifications();
        const container = document.getElementById('inboundList');
        const countElement = document.getElementById('inboundCount');
        
        if (countElement) {
            countElement.textContent = inboundNotifications.length;
        }
        
        if (!container) return;

        if (inboundNotifications.length === 0) {
            container.innerHTML = '<div class="notification-item">暂无出入库通知</div>';
            return;
        }

        const inboundHTML = inboundNotifications.map(notification => {
            const timeAgo = this.getTimeAgo(notification.timestamp);
            let typeIcon = '📦';
            if (notification.type === 'inbound_success') {
                typeIcon = '✅';
            } else if (notification.type === 'inbound_end') {
                typeIcon = '🎉';
            } else if (notification.type === 'inbound_cancel') {
                typeIcon = '❌';
            } else if (notification.type === 'outbound_success') {
                typeIcon = '📤';
            }
            
            return `
                <div class="notification-item ${notification.read ? 'read' : 'unread'}" data-id="${notification.id}">
                    <div class="notification-icon">${typeIcon}</div>
                    <div class="notification-content">
                        <div class="notification-user">${notification.date}</div>
                        <div class="notification-text">${notification.content}</div>
                        <div class="notification-time">${timeAgo}</div>
                    </div>
                </div>
            `;
        }).join('');

        // 添加清空按钮
        const clearButton = `
            <div class="notification-clear-section">
                <button class="clear-notifications-btn" onclick="app.clearInboundNotifications()">
                    <span class="clear-icon">🗑️</span>
                    <span class="clear-text">清空所有通知</span>
                </button>
            </div>
        `;
        
        container.innerHTML = inboundHTML + clearButton;
    }

    /**
     * 获取入库通知
     */
    getInboundNotifications() {
        // 从本地存储获取入库通知数据
        const notifications = JSON.parse(localStorage.getItem('inboundNotifications') || '[]');
        return notifications;
    }

    /**
     * 添加入库通知
     * @param {string} type 通知类型
     * @param {string} date 日期
     * @param {string} content 通知内容
     */
    addInboundNotification(type, date, content) {
        console.log('addInboundNotification 被调用:', { type, date, content }); // 调试日志
        const notifications = this.getInboundNotifications();
        const newNotification = {
            id: Date.now(), // 使用时间戳作为唯一ID
            type: type,
            date: date,
            content: content,
            timestamp: new Date().toISOString(),
            read: false
        };
        console.log('创建新入库通知:', newNotification); // 调试日志
        
        notifications.unshift(newNotification); // 添加到开头
        
        // 限制通知数量
        if (notifications.length > 50) {
            notifications.splice(50);
        }
        
        // 保存到本地存储
        localStorage.setItem('inboundNotifications', JSON.stringify(notifications));
        
        // 立即更新通知显示
        this.updateInboundNotifications();
        
        return newNotification;
    }

    /**
     * 清空所有入库通知
     */
    clearInboundNotifications() {
        // 显示确认对话框
        const confirmClear = confirm('确定要清空所有出入库通知吗？\n\n清空后将无法恢复！');
        
        if (confirmClear) {
            // 清空本地存储
            localStorage.removeItem('inboundNotifications');
            
            // 立即更新通知显示
            this.updateInboundNotifications();
            
            // 显示成功消息
            this.showMessage('所有出入库通知已清空', 'success');
            
            console.log('所有出入库通知已清空'); // 调试日志
        }
    }

    /**
     * 获取时间差显示
     * @param {string} timestamp ISO时间戳
     * @returns {string} 时间差描述
     */
    getTimeAgo(timestamp) {
        const now = new Date();
        const time = new Date(timestamp);
        const diffMs = now - time;
        const diffMins = Math.floor(diffMs / (1000 * 60));
        const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
        const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));

        if (diffMins < 1) return '刚刚';
        if (diffMins < 60) return `${diffMins}分钟前`;
        if (diffHours < 24) return `${diffHours}小时前`;
        if (diffDays < 7) return `${diffDays}天前`;
        return time.toLocaleDateString();
    }

    /**
     * 获取过期食品
     */
    getExpiredFoods() {
        const now = new Date();
        return this.foodList.filter(food => {
            // 优先使用计算好的到期日期
            if (food.expire_date) {
                const expiryDate = new Date(food.expire_date);
                const remainingDays = Math.ceil((expiryDate - now) / (1000 * 60 * 60 * 24));
                return remainingDays <= 5 && remainingDays > 0;
            }
            
            // 兜底逻辑
            if (!food.production_date || !food.expiry_period) return false;
            
            // 过期计算逻辑
            const productionDate = new Date(food.production_date);
            const expiryDate = new Date(productionDate);
            
            // 解析保质期字符串，支持"2年6个月"、"6个月"、"30天"等格式
            const expiryStr = food.expiry_period;
            let totalDays = 0;
            
            // 提取年
            const yearMatch = expiryStr.match(/(\d+)年/);
            if (yearMatch) {
                totalDays += parseInt(yearMatch[1]) * 365;
            }
            
            // 提取月
            const monthMatch = expiryStr.match(/(\d+)个月/);
            if (monthMatch) {
                totalDays += parseInt(monthMatch[1]) * 30; // 简化处理，每月按30天计算
            }
            
            // 提取天
            const dayMatch = expiryStr.match(/(\d+)天/);
            if (dayMatch) {
                totalDays += parseInt(dayMatch[1]);
            }
            
            // 如果解析成功，使用总天数计算过期日期
            if (totalDays > 0) {
                expiryDate.setDate(expiryDate.getDate() + totalDays);
            } else {
                // 兜底：如果无法解析，返回false
                return false;
            }
            
            const remainingDays = Math.ceil((expiryDate - now) / (1000 * 60 * 60 * 24));
            return remainingDays <= 5 && remainingDays > 0;
        }).map(food => {
            const now = new Date();
            let remainingDays = 0;
            
            // 优先使用计算好的到期日期
            if (food.expire_date) {
                const expiryDate = new Date(food.expire_date);
                remainingDays = Math.ceil((expiryDate - now) / (1000 * 60 * 60 * 24));
            } else {
                // 兜底计算
                const productionDate = new Date(food.production_date);
                remainingDays = Math.ceil((productionDate - now) / (1000 * 60 * 60 * 24));
            }
            
            return {
                ...food,
                days: remainingDays
            };
        });
    }

    /**
     * 获取过敏原食品
     */
    getAllergenFoods() {
        if (this.userAllergens.length === 0) return [];
        
        return this.foodList.filter(food => {
            if (!food.allergens || food.allergens.length === 0) return false;
            return food.allergens.some(allergen => 
                this.userAllergens.includes(allergen)
            );
        });
    }

    /**
     * 获取日记通知
     */
    getDiaryNotifications() {
        // 从本地存储获取日记通知数据
        const notifications = JSON.parse(localStorage.getItem('diaryNotifications') || '[]');
        return notifications;
    }

    /**
     * 添加日记通知
     * @param {string} type 通知类型 ('publish', 'comment', 'favorite', 'unfavorite', 'delete')
     * @param {string} date 日期
     * @param {string} content 通知内容
     */
    addDiaryNotification(type, date, content) {
        console.log('addDiaryNotification 被调用:', { type, date, content }); // 调试日志
        const notifications = this.getDiaryNotifications();
        const newNotification = {
            id: Date.now(), // 使用时间戳作为唯一ID
            type: type,
            date: date,
            content: content,
            timestamp: new Date().toISOString(),
            read: false
        };
        console.log('创建新通知:', newNotification); // 调试日志
        
        notifications.unshift(newNotification); // 添加到开头
        
        // 限制通知数量
        if (notifications.length > 50) {
            notifications.splice(50);
        }
        
        // 保存到本地存储
        localStorage.setItem('diaryNotifications', JSON.stringify(notifications));
        
        // 立即更新通知显示
        this.updateDiaryNotifications();
        
        return newNotification;
    }

    /**
     * 清空所有日记通知
     */
    clearDiaryNotifications() {
        // 显示确认对话框
        const confirmClear = confirm('确定要清空所有日记通知吗？\n\n清空后将无法恢复！');
        
        if (confirmClear) {
            // 清空本地存储
            localStorage.removeItem('diaryNotifications');
            
            // 立即更新通知显示
            this.updateDiaryNotifications();
            
            // 显示成功消息
            this.showMessage('所有通知已清空', 'success');
            
            console.log('所有日记通知已清空'); // 调试日志
        }
    }

    /**
     * 清空所有过期食品通知
     */
    clearExpiredFoods() {
        // 显示确认对话框
        const confirmClear = confirm('确定要清空所有过期食品通知吗？\n\n清空后将无法恢复！');
        
        if (confirmClear) {
            // 清空本地存储
            localStorage.removeItem('expiredFoods');
            
            // 立即更新通知显示
            this.updateExpiredFoods();
            
            // 显示成功消息
            this.showMessage('所有过期食品通知已清空', 'success');
            
            console.log('所有过期食品通知已清空'); // 调试日志
        }
    }

    /**
     * 清空所有过敏原食品通知
     */
    clearAllergenFoods() {
        // 显示确认对话框
        const confirmClear = confirm('确定要清空所有过敏原食品通知吗？\n\n清空后将无法恢复！');
        
        if (confirmClear) {
            // 清空本地存储
            localStorage.removeItem('allergenFoods');
            
            // 立即更新通知显示
            this.updateAllergenFoods();
            
            // 显示成功消息
            this.showMessage('所有过敏原食品通知已清空', 'success');
            
            console.log('所有过敏原食品通知已清空'); // 调试日志
        }
    }

    /**
     * 加载食品列表
     */
    loadFoodList() {
        const foodListContainer = document.getElementById('foodList');
        if (!foodListContainer) return;

        try {
            // 显示加载状态
            foodListContainer.innerHTML = '<div class="empty-state">正在加载食品列表...</div>';
            
            // 直接从本地存储加载食品列表
            this.foodList = JSON.parse(localStorage.getItem('foodList') || '[]');
            
            this.renderFoodList();
            
            // 界面刷新完成提示
            console.log('✅ 界面刷新完成 - 食品列表已更新');
            
        } catch (error) {
            console.error('加载食品列表失败:', error);
            
            // 如果出错，确保从本地存储加载
            this.foodList = JSON.parse(localStorage.getItem('foodList') || '[]');
            this.renderFoodList();
            
            // 界面刷新完成提示（错误恢复后）
            console.log('✅ 界面刷新完成 - 食品列表已更新（错误恢复）');
        }
    }

    /**
     * 渲染食品列表
     */
    renderFoodList() {
        const foodListContainer = document.getElementById('foodList');
        if (!foodListContainer) return;

        if (this.foodList.length === 0) {
            foodListContainer.innerHTML = '<div class="empty-state">暂无食品数据</div>';
            return;
        }

        const foodListHTML = this.foodList.map(food => `
            <div class="food-item" data-food-id="${food.food_id}">
                <div class="food-info">
                    <img src="${food.image || 'images/default-food.png'}" alt="${food.name}" class="food-image">
                    <div class="food-details">
                        <div class="food-name editable" contenteditable="true" data-field="name">${food.name || '未知食品'}</div>
                        <div class="food-meta">净含量: ${food.net_weight || '未知'}</div>
                        <div class="food-meta">生产日期: ${food.production_date || '未知'}</div>
                        <div class="food-meta">保质期: ${food.expiry_period || '未知'}</div>
                        <div class="food-meta">到期日期: ${food.expire_date || '未知'}</div>
                        <div class="food-meta">在库数量: ${food.quantity || 0}</div>
                        ${food.category ? `<div class="food-meta category-meta">识别分类: ${this.formatCategory(food.category)}</div>` : ''}
                        ${this.renderAllergenTags(food.allergens)}
                        <button class="detail-btn" onclick="app.showFoodDetail(${food.food_id})">查看详情</button>
                    </div>
                </div>
            </div>
        `).join('');

        foodListContainer.innerHTML = foodListHTML;
        
        // 添加可编辑字段事件
        this.setupEditableFields();
    }

    /**
     * 设置可编辑字段
     */
    setupEditableFields() {
        const editableFields = document.querySelectorAll('.editable');
        editableFields.forEach(field => {
            // 移除之前的事件监听器
            field.removeEventListener('blur', this.handleFieldEdit);
            
            // 添加新的事件监听器
            field.addEventListener('blur', this.handleFieldEdit.bind(this));
            
            // 添加焦点样式
            field.addEventListener('focus', (e) => {
                e.target.style.background = '#e8f5e8';
                e.target.style.outline = '2px solid #4CAF50';
            });
            
            field.addEventListener('blur', (e) => {
                e.target.style.background = '';
                e.target.style.outline = '';
            });
        });
    }

    /**
     * 处理字段编辑
     * @param {Event} event 事件对象
     */
    handleFieldEdit(event) {
        const foodItem = event.target.closest('.food-item');
        const foodId = parseInt(foodItem.dataset.foodId);
        const fieldName = event.target.dataset.field;
        const newValue = event.target.textContent.trim();
        
        // 更新本地数据
        const food = this.foodList.find(f => f.food_id === foodId);
        if (food) {
            const oldValue = food[fieldName];
            food[fieldName] = newValue;
            
            // 保存到本地存储
            this.saveUserData();
            
            // 显示保存提示
            if (oldValue !== newValue) {
                this.showMessage('已保存', 'success');
            }
            
            console.log(`食品名称已更新: foodId=${foodId}, field=${fieldName}, value=${newValue}`);
        }
    }

    /**
     * 渲染过敏原标签
     */
    renderAllergenTags(allergens) {
        if (!allergens || allergens.length === 0) return '';
        
        const userAllergens = this.userAllergens;
        const matchedAllergens = allergens.filter(allergen => 
            userAllergens.includes(allergen)
        );

        if (matchedAllergens.length === 0) return '';

        return `
            <div class="allergen-tags">
                ${matchedAllergens.map(allergen => 
                    `<span class="allergen-tag">${allergen}</span>`
                ).join('')}
            </div>
        `;
    }

    /**
     * 格式化分类显示
     * @param {string} category 分类值
     * @returns {string} 格式化后的分类显示
     */
    formatCategory(category) {
        const categoryMap = {
            'food': '🍎 食品',
            'drink': '🥤 饮品',
            '无法判断': '❓ 无法判断'
        };
        return categoryMap[category] || category;
    }

    /**
     * 显示食品详情
     */
    showFoodDetail(foodId) {
        const food = this.foodList.find(f => f.food_id === foodId);
        if (!food) return;

        const modal = document.getElementById('food-detail-modal');
        const content = document.getElementById('foodDetailContent');
        
        // 获取详情图片数组，如果没有则使用主图
        const detailImages = food.detailImages || (food.image ? [food.image] : []);
        
        content.innerHTML = `
            <h2>${food.name}</h2>
            <div class="food-detail-info">
                <div class="detail-image-container">
                    <img src="${food.image || 'images/default-food.png'}" alt="${food.name}" class="detail-image" onclick="app.showImageZoom(${food.food_id}, 0)">
                </div>
                <div class="detail-meta">
                    <p><strong>净含量:</strong> ${food.net_weight || '未知'}</p>
                    <p><strong>生产日期:</strong> ${food.production_date || '未知'}</p>
                    <p><strong>保质期:</strong> ${food.expiry_period || '未知'}</p>
                    <p><strong>到期日期:</strong> ${food.expire_date || '未知'}</p>
                    <p><strong>在库数量:</strong> ${food.quantity || 0}</p>
                    ${food.category ? `<p class="category-meta"><strong>识别分类:</strong> ${this.formatCategory(food.category)}</p>` : ''}
                    ${food.allergens ? `<p><strong>过敏原:</strong> ${food.allergens.join(', ')}</p>` : ''}
                    ${food.food_id ? `<p><strong>数据库ID:</strong> ${food.food_id}</p>` : ''}
                </div>
            </div>
            
            <!-- 营养成分表 -->
            ${this.renderNutritionTable(food)}
            
            ${detailImages.length > 1 ? `
                <div class="detail-images-section">
                    <h3>图片信息</h3>
                    <div class="detail-images-carousel">
                        ${detailImages.map((img, index) => `
                            <img src="${img}" alt="详情图片 ${index + 1}" class="detail-thumbnail" onclick="app.showImageZoom(${food.food_id}, ${index})">
                        `).join('')}
                    </div>
                </div>
            ` : ''}
        `;
        
        modal.style.display = 'flex';
        
        // 点击模态框外部关闭
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.style.display = 'none';
            }
        });
    }

    /**
     * 渲染营养成分表
     * @param {Object} food 食品对象
     * @returns {string} 营养成分表HTML
     */
    renderNutritionTable(food) {
        // 检查是否有营养成分数据
        const hasNutritionData = food.calorie_per_unit || food.protein_per_unit || 
                                food.fat_per_unit || food.carbo_per_unit || 
                                food.sugar_per_unit || food.sodium_per_unit;
        
        if (!hasNutritionData) {
            return '<div class="nutrition-section"><h3>营养成分表</h3><p class="no-nutrition-data">暂无营养成分信息</p></div>';
        }
        
        return `
            <div class="nutrition-section">
                <h3>营养成分表</h3>
                <div class="nutrition-table">
                    <div class="nutrition-row">
                        <span class="nutrition-label">能量</span>
                        <span class="nutrition-value">${food.calorie_per_unit ? food.calorie_per_unit + ' kJ' : '未知'}</span>
                    </div>
                    <div class="nutrition-row">
                        <span class="nutrition-label">蛋白质</span>
                        <span class="nutrition-value">${food.protein_per_unit ? food.protein_per_unit + ' g' : '未知'}</span>
                    </div>
                    <div class="nutrition-row">
                        <span class="nutrition-label">脂肪</span>
                        <span class="nutrition-value">${food.fat_per_unit ? food.fat_per_unit + ' g' : '未知'}</span>
                    </div>
                    <div class="nutrition-row">
                        <span class="nutrition-label">碳水化合物</span>
                        <span class="nutrition-value">${food.carbo_per_unit ? food.carbo_per_unit + ' g' : '未知'}</span>
                    </div>
                    <div class="nutrition-row">
                        <span class="nutrition-label">糖</span>
                        <span class="nutrition-value">${food.sugar_per_unit ? food.sugar_per_unit + ' g' : '未知'}</span>
                    </div>
                    <div class="nutrition-row">
                        <span class="nutrition-label">钠</span>
                        <span class="nutrition-value">${food.sodium_per_unit ? food.sodium_per_unit + ' mg' : '未知'}</span>
                    </div>
                </div>
            </div>
        `;
    }

    /**
     * 显示图片放大查看
     * @param {number} foodId 食品ID
     * @param {number} imageIndex 图片索引
     */
    showImageZoom(foodId, imageIndex) {
        const food = this.foodList.find(f => f.food_id === foodId);
        if (!food) return;

        const detailImages = food.detailImages || (food.image ? [food.image] : []);
        if (detailImages.length === 0) return;

        // 创建图片放大弹窗
        const zoomModal = document.createElement('div');
        zoomModal.className = 'image-zoom-modal';
        zoomModal.innerHTML = `
            <div class="image-zoom-container">
                <div class="image-zoom-header">
                    <span class="image-counter">${imageIndex + 1} / ${detailImages.length}</span>
                    <button class="close-zoom-btn" onclick="app.closeImageZoom()">×</button>
                </div>
                <div class="image-zoom-content">
                    <img src="${detailImages[imageIndex]}" alt="放大图片" class="zoom-image" id="zoom-image-${foodId}-${imageIndex}">
                    <button class="zoom-nav-btn zoom-prev" onclick="app.navigateImage(${food.food_id}, ${imageIndex}, -1)">‹</button>
                    <button class="zoom-nav-btn zoom-next" onclick="app.navigateImage(${food.food_id}, ${imageIndex}, 1)">›</button>
                </div>
                <div class="image-zoom-controls">
                    <button class="rotate-btn" onclick="app.rotateImage(${food.food_id}, ${imageIndex})" title="左旋转90度">🔄</button>
                </div>
            </div>
        `;

        document.body.appendChild(zoomModal);
        
        // 点击背景关闭
        zoomModal.addEventListener('click', (e) => {
            if (e.target === zoomModal) {
                this.closeImageZoom();
            }
        });

        // 键盘导航
        this.currentZoomFoodId = foodId;
        this.currentZoomImageIndex = imageIndex;
        this.currentImageRotation = 0; // 初始化旋转角度
        document.addEventListener('keydown', this.handleZoomKeydown);
    }

    /**
     * 旋转图片
     * @param {number} foodId 食品ID
     * @param {number} imageIndex 图片索引
     */
    rotateImage(foodId, imageIndex) {
        const zoomImage = document.querySelector('.zoom-image');
        if (!zoomImage) return;
        
        // 增加旋转角度（左旋转90度）
        this.currentImageRotation = (this.currentImageRotation - 90) % 360;
        
        // 应用旋转样式
        zoomImage.style.transform = `rotate(${this.currentImageRotation}deg)`;
        
        console.log(`图片旋转角度: ${this.currentImageRotation}度`);
    }

    /**
     * 关闭图片放大查看
     */
    closeImageZoom() {
        const zoomModal = document.querySelector('.image-zoom-modal');
        if (zoomModal) {
            zoomModal.remove();
        }
        document.removeEventListener('keydown', this.handleZoomKeydown);
        this.currentZoomFoodId = null;
        this.currentZoomImageIndex = null;
        this.currentImageRotation = 0; // 重置旋转角度
    }

    /**
     * 导航到上一张/下一张图片
     * @param {number} foodId 食品ID
     * @param {number} currentIndex 当前图片索引
     * @param {number} direction 方向（-1为上一张，1为下一张）
     */
    navigateImage(foodId, currentIndex, direction) {
        const food = this.foodList.find(f => f.food_id === foodId);
        if (!food) return;

        const detailImages = food.detailImages || (food.image ? [food.image] : []);
        if (detailImages.length === 0) return;

        let newIndex = currentIndex + direction;
        
        // 循环导航
        if (newIndex < 0) {
            newIndex = detailImages.length - 1;
        } else if (newIndex >= detailImages.length) {
            newIndex = 0;
        }

        // 更新图片和计数器
        const zoomImage = document.querySelector('.zoom-image');
        const imageCounter = document.querySelector('.image-counter');
        
        if (zoomImage) {
            zoomImage.src = detailImages[newIndex];
            // 重置旋转角度，因为切换到了新图片
            this.currentImageRotation = 0;
            zoomImage.style.transform = 'rotate(0deg)';
        }
        if (imageCounter) {
            imageCounter.textContent = `${newIndex + 1} / ${detailImages.length}`;
        }

        // 更新导航按钮的onclick事件
        const prevBtn = document.querySelector('.zoom-prev');
        const nextBtn = document.querySelector('.zoom-next');
        
        if (prevBtn) {
            prevBtn.onclick = () => this.navigateImage(foodId, newIndex, -1);
        }
        if (nextBtn) {
            nextBtn.onclick = () => this.navigateImage(foodId, newIndex, 1);
        }

        this.currentZoomImageIndex = newIndex;
    }

    /**
     * 处理图片放大查看的键盘事件
     * @param {KeyboardEvent} event 键盘事件
     */
    handleZoomKeydown = (event) => {
        if (!this.currentZoomFoodId || this.currentZoomImageIndex === null) return;

        switch (event.key) {
            case 'Escape':
                this.closeImageZoom();
                break;
            case 'ArrowLeft':
                this.navigateImage(this.currentZoomFoodId, this.currentZoomImageIndex, -1);
                break;
            case 'ArrowRight':
                this.navigateImage(this.currentZoomFoodId, this.currentZoomImageIndex, 1);
                break;
        }
    };

    /**
     * 更新过敏原设置
     */
    updateAllergenSettings() {
        const allergenCheckboxes = document.querySelectorAll('.allergen-item input[type="checkbox"]');
        allergenCheckboxes.forEach(checkbox => {
            checkbox.checked = this.userAllergens.includes(checkbox.value);
            
            checkbox.addEventListener('change', (e) => {
                const allergen = e.target.value;
                if (e.target.checked) {
                    if (!this.userAllergens.includes(allergen)) {
                        this.userAllergens.push(allergen);
                    }
                } else {
                    this.userAllergens = this.userAllergens.filter(a => a !== allergen);
                }
                this.saveUserData();
                this.updateNotifications();
                this.loadFoodList();
            });
        });
    }

    /**
     * 处理RFID读取成功
     */
    handleRfidSuccess(message) {
        // 由入库管理器处理
    }

    /**
     * 处理信息处理成功
     */
    handleInfoProcessSuccess(message) {
        // 由入库管理器处理
    }

    /**
     * 处理图片准备完成
     */
    handleImagesReady(message) {
        // 由入库管理器处理
    }

    /**
     * 处理上传成功确认
     */
    handleUploadSuccess(message) {
        console.log('处理上传成功确认:', message);
        // 移除冗余的入库成功提示消息
    }

    /**
     * 处理入库结束
     */
    handleInboundEnd(message) {
        console.log('处理入库结束:', message);
        // 移除冗余的入库流程完成提示消息
    }

    /**
     * 处理入库取消
     */
    handleInboundCancel(message) {
        console.log('处理入库取消:', message);
        this.addInboundNotification('inbound_cancel', new Date().toLocaleDateString(), '入库流程已取消');
    }

    /**
     * 处理出库通知
     */
    handleOutboundNotification(message) {
        console.log('处理出库通知:', message);
        console.log('消息数据:', message.data);
        console.log('状态:', message.data.status);
        
        if (message.data.status === 'delete_food_item') {
            console.log('开始删除食品项:', message.data.food_id);
            
            // 获取食品名称用于通知显示
            const food = this.foodList.find(f => f.food_id == message.data.food_id);
            const foodName = food ? food.name : `ID ${message.data.food_id}`;
            
            // 添加到出入库通知卡片
            this.addInboundNotification('outbound_success', new Date().toLocaleDateString(), `食品 ${foodName} 已出库`);
            
            // 处理食品出库（removeFoodItem内部会显示相应的提示消息）
            this.removeFoodItem(message.data.food_id);
        } else {
            console.warn('未知的出库通知状态:', message.data.status);
        }
    }

    /**
     * 处理食品出库
     * @param {number} foodId 食品ID
     */
    removeFoodItem(foodId) {
        console.log(`尝试删除食品ID: ${foodId}`);
        console.log(`当前食品列表:`, this.foodList);
        console.log(`食品列表长度: ${this.foodList.length}`);
        
        const food = this.foodList.find(f => f.food_id === foodId);
        if (!food) {
            console.warn(`未找到ID为 ${foodId} 的食品`);
            console.log(`所有食品ID:`, this.foodList.map(f => f.food_id));
            this.showMessage(`未找到ID为 ${foodId} 的食品，可能已被删除或数据不同步`, 'warning');
            return;
        }

        const currentQuantity = parseInt(food.quantity) || 0;
        console.log(`食品 ${food.name} 当前数量: ${currentQuantity}`);

        if (currentQuantity > 1) {
            // 数量大于1，减1
            food.quantity = currentQuantity - 1;
            console.log(`食品 ${food.name} 数量减1，新数量: ${food.quantity}`);
            this.showMessage(`食品 ${food.name} 已出库，剩余数量: ${food.quantity}`, 'success');
        } else if (currentQuantity === 1) {
            // 数量等于1，删除整个食品卡片
            console.log(`食品 ${food.name} 数量为1，删除整个食品卡片`);
            
            // 添加到废纸篓
            this.trashItems.push({
                ...food,
                deletedAt: new Date().toISOString()
            });
            
            // 从食品列表中删除
            this.foodList = this.foodList.filter(f => f.food_id !== foodId);
            this.showMessage(`食品 ${food.name} 已完全出库，已从列表中删除`, 'success');
        } else {
            // 数量为0或无效，直接删除
            console.log(`食品 ${food.name} 数量为0或无效，直接删除`);
            
            // 添加到废纸篓
            this.trashItems.push({
                ...food,
                deletedAt: new Date().toISOString()
            });
            
            // 从食品列表中删除
            this.foodList = this.foodList.filter(f => f.food_id !== foodId);
            this.showMessage(`食品 ${food.name} 已从列表中删除`, 'success');
        }

        // 保存数据并更新界面
        this.saveUserData();
        this.loadFoodList();
        this.updateNotifications();
    }

    /**
     * 显示消息
     */
    showMessage(message, type = 'info') {
        // 创建消息元素
        const messageEl = document.createElement('div');
        messageEl.className = `message message-${type}`;
        messageEl.textContent = message;
        messageEl.style.cssText = `
            position: fixed;
            top: 20px;
            left: 50%;
            transform: translateX(-50%);
            background: ${type === 'success' ? '#4CAF50' : type === 'error' ? '#f44336' : '#2196F3'};
            color: white;
            padding: 12px 24px;
            border-radius: 24px;
            font-size: 14px;
            z-index: 3000;
            box-shadow: 0 4px 12px rgba(0,0,0,0.2);
        `;
        
        // 添加到页面
        document.body.appendChild(messageEl);
        
        // 自动删除消息
        setTimeout(() => {
            messageEl.remove();
        }, 3000);
    }
}

// 创建应用实例
const app = new SmartFoodCabinetApp();
