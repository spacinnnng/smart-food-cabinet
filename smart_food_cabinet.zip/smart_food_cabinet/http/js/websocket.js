/**
 * WebSocket通信管理类
 * 负责与树莓派的WebSocket通信
 */

class WebSocketManager {
    constructor() {
        this.ws = null;
        this.isConnected = false;
        this.reconnectAttempts = 0;
        this.maxReconnectAttempts = 5;         // 最大重连次数
        this.reconnectInterval = 5000;         // 增加重连间隔到5秒
        this.heartbeatInterval = null;         // 心跳定时器
        this.heartbeatTimeout = null;          // 心跳超时定时器
        this.lastPongTime = Date.now();        // 最后一次收到pong的时间
        this.messageHandlers = new Map();
        this.pendingResponses = new Map();
        
        // 连接状态回调
        this.onConnectCallback = null;
        this.onDisconnectCallback = null;
        this.onErrorCallback = null;
        
        // 自动重连相关
        this.autoReconnectEnabled = true;      // 是否启用自动重连
        this.savedIP = null;                   // 保存的IP地址
        this.savedPort = 5001;                 // 保存的端口
        this.reconnectTimer = null;            // 重连定时器
    }

    /**
     * 连接WebSocket
     * @param {string} ip 服务器IP地址
     * @param {number} port 服务器端口
     * @returns {Promise} 连接Promise
     */
    connect(ip = '183.172.188.44', port = 5001) {
        return new Promise((resolve, reject) => {
            try {
                // 检查连接状态
                if (this.ws) {
                    if (this.ws.readyState === WebSocket.OPEN) {
                        console.log('检测到现有连接，先断开');
                        this.ws.close();
                    } else if (this.ws.readyState === WebSocket.CONNECTING) {
                        console.log('正在连接中，等待当前连接完成');
                        reject(new Error('正在连接中，请稍后再试'));
                        return;
                    }
                }
                
                // 保存连接参数用于自动重连
                this.savedIP = ip;
                this.savedPort = port;
                
                const url = `ws://${ip}:${port}`;
                console.log('正在连接WebSocket:', url);
                
                this.ws = new WebSocket(url);
                
                this.ws.onopen = () => {
                    console.log('WebSocket连接已建立');
                    this.isConnected = true;
                    this.reconnectAttempts = 0;
                    this.lastPongTime = Date.now();
                    this.updateConnectionStatus(true);
                    
                    // 启动心跳机制
                    this.startHeartbeat();
                    
                    if (this.onConnectCallback) {
                        try {
                            console.log('调用onConnectCallback');
                            this.onConnectCallback();
                            console.log('onConnectCallback执行完成');
                        } catch (error) {
                            console.error('onConnectCallback执行失败:', error);
                            reject(error);
                            return;
                        }
                    }
                    
                    resolve();
                };
                
                this.ws.onmessage = (event) => {
                    // 检查是否是二进制数据（图片）
                    if (event.data instanceof ArrayBuffer) {
                        this.handleBinaryMessage(event.data);
                    } else if (event.data instanceof Blob) {
                        // 处理Blob格式的图片数据
                        this.handleBlobMessage(event.data);
                    } else {
                        this.handleMessage(event.data);
                    }
                };
                
                this.ws.onclose = (event) => {
                    console.log('WebSocket连接已关闭:', event);
                    console.log('关闭代码:', event.code);
                    console.log('关闭原因:', event.reason);
                    console.log('是否正常关闭:', event.wasClean);
                    this.isConnected = false;
                    this.updateConnectionStatus(false);
                    
                    // 停止心跳机制
                    this.stopHeartbeat();
                    
                    if (this.onDisconnectCallback) {
                        this.onDisconnectCallback(event);
                    }
                    
                    // 自动重连
                    if (this.autoReconnectEnabled && this.reconnectAttempts < this.maxReconnectAttempts) {
                        this.attemptReconnect();
                    } else if (this.reconnectAttempts >= this.maxReconnectAttempts) {
                        console.log('已达到最大重连次数，停止自动重连');
                        this.showReconnectMessage();
                    }
                };
                
                this.ws.onerror = (error) => {
                    console.error('WebSocket错误:', error);
                    this.isConnected = false;
                    this.updateConnectionStatus(false);
                    
                    if (this.onErrorCallback) {
                        this.onErrorCallback(error);
                    }
                    
                    reject(error);
                };
                
            } catch (error) {
                console.error('WebSocket连接失败:', error);
                reject(error);
            }
        });
    }

    /**
     * 尝试重连
     */
    attemptReconnect() {
        if (!this.autoReconnectEnabled) {
            console.log('自动重连已禁用');
            return;
        }
        
        this.reconnectAttempts++;
        console.log(`尝试重连 (${this.reconnectAttempts}/${this.maxReconnectAttempts})`);
        
        // 清除之前的重连定时器
        if (this.reconnectTimer) {
            clearTimeout(this.reconnectTimer);
        }
        
        // 指数退避策略
        const backoffDelay = Math.min(this.reconnectInterval * Math.pow(2, this.reconnectAttempts - 1), 30000);
        console.log(`重连延迟: ${backoffDelay}ms`);
        
        this.reconnectTimer = setTimeout(() => {
            if (this.savedIP && this.savedPort) {
                console.log(`开始重连到 ${this.savedIP}:${this.savedPort}`);
                this.connect(this.savedIP, this.savedPort).catch(error => {
                    console.error('重连失败:', error);
                    // 重连失败后继续尝试
                    if (this.reconnectAttempts < this.maxReconnectAttempts) {
                        this.attemptReconnect();
                    } else {
                        console.log('已达到最大重连次数，停止自动重连');
                        this.showReconnectMessage();
                    }
                });
            } else {
                console.error('没有保存的连接参数，无法重连');
                this.showReconnectMessage();
            }
        }, backoffDelay);
    }

    /**
     * 发送消息
     * @param {object} message 消息对象
     * @returns {boolean} 是否发送成功
     */
    send(message) {
        if (!this.isConnected || !this.ws) {
            console.error('WebSocket未连接');
            return false;
        }
        
        try {
            const messageStr = typeof message === 'string' ? message : JSON.stringify(message);
            this.ws.send(messageStr);
            console.log('发送消息:', message);
            return true;
        } catch (error) {
            console.error('发送消息失败:', error);
            return false;
        }
    }

    /**
     * 发送JSON消息
     * @param {string} type 消息类型
     * @param {object} data 消息数据
     * @returns {boolean} 是否发送成功
     */
    sendJSON(type, data = {}) {
        const message = {
            type: type,
            data: data,
            timestamp: new Date().toISOString()
        };
        return this.send(message);
    }

    /**
     * 发送二进制数据
     * @param {ArrayBuffer} data 二进制数据
     * @returns {boolean} 是否发送成功
     */
    sendBinary(data) {
        if (!this.isConnected || !this.ws) {
            console.error('WebSocket未连接');
            return false;
        }
        
        try {
            this.ws.send(data);
            console.log('发送二进制数据:', data.byteLength, 'bytes');
            return true;
        } catch (error) {
            console.error('发送二进制数据失败:', error);
            return false;
        }
    }

    /**
     * 处理接收到的二进制消息（图片）
     * @param {ArrayBuffer} data 二进制数据
     */
    handleBinaryMessage(data) {
        try {
            // 将ArrayBuffer转换为Blob
            const blob = new Blob([data], { type: 'image/jpeg' });
            const imageUrl = URL.createObjectURL(blob);
            
            console.log('收到图片数据:', data.byteLength, 'bytes');
            
            // 通知应用处理图片
            if (this.onImageReceived) {
                this.onImageReceived(imageUrl, blob);
            }
            
        } catch (error) {
            console.error('二进制消息处理失败:', error);
        }
    }

    /**
     * 处理接收到的Blob消息（图片）
     * @param {Blob} blob 图片Blob数据
     */
    handleBlobMessage(blob) {
        try {
            // 直接使用Blob创建图片URL
            const imageUrl = URL.createObjectURL(blob);
            
            console.log('收到Blob图片数据:', blob.size, 'bytes, 类型:', blob.type);
            
            // 通知应用处理图片
            if (this.onImageReceived) {
                this.onImageReceived(imageUrl, blob);
            }
            
        } catch (error) {
            console.error('Blob消息处理失败:', error);
        }
    }

    /**
     * 处理接收到的消息
     * @param {string} data 消息数据
     */
    handleMessage(data) {
        try {
            const message = JSON.parse(data);
            const { type, action, data: messageData, timestamp } = message;
            
            console.log('收到消息:', message);
            console.log('消息类型:', type, '动作:', action);
            
            // 处理心跳响应
            if (type === 'pong') {
                this.handleHeartbeat(message);
                return;
            }
            
            // 处理待响应的消息
            if (this.pendingResponses.has(type)) {
                const { resolve, reject } = this.pendingResponses.get(type);
                this.pendingResponses.delete(type);
                
                if (action === 'error') {
                    reject(new Error(messageData.error_message || '操作失败'));
                } else {
                    resolve(message);
                }
            }
            
            // 处理注册的消息处理器
            const handlerKey = `${type}_${action}`;
            console.log('查找处理器:', handlerKey);
            console.log('已注册的处理器:', Array.from(this.messageHandlers.keys()));
            
            if (this.messageHandlers.has(handlerKey)) {
                console.log('找到处理器，开始执行:', handlerKey);
                this.messageHandlers.get(handlerKey)(message);
                console.log('处理器执行完成:', handlerKey);
            } else {
                console.warn('未找到对应的消息处理器:', handlerKey);
            }
            
        } catch (error) {
            console.error('消息解析失败:', error);
            console.error('原始数据:', data);
        }
    }

    /**
     * 等待特定类型的响应
     * @param {string} type 消息类型
     * @param {number} timeout 超时时间（毫秒）
     * @returns {Promise} 响应Promise
     */
    waitForResponse(type, timeout = 10000) {
        return new Promise((resolve, reject) => {
            const timer = setTimeout(() => {
                this.pendingResponses.delete(type);
                reject(new Error('请求超时'));
            }, timeout);
            
            this.pendingResponses.set(type, {
                resolve: (message) => {
                    clearTimeout(timer);
                    resolve(message);
                },
                reject: (error) => {
                    clearTimeout(timer);
                    reject(error);
                }
            });
        });
    }

    /**
     * 注册消息处理器
     * @param {string} type 消息类型
     * @param {string} action 动作类型
     * @param {function} handler 处理函数
     */
    registerHandler(type, action, handler) {
        const key = `${type}_${action}`;
        this.messageHandlers.set(key, handler);
    }

    /**
     * 断开连接
     */
    disconnect() {
        // 禁用自动重连
        this.autoReconnectEnabled = false;
        
        // 清除重连定时器
        if (this.reconnectTimer) {
            clearTimeout(this.reconnectTimer);
            this.reconnectTimer = null;
        }
        
        if (this.ws) {
            this.ws.close();
            this.ws = null;
        }
        this.isConnected = false;
        this.updateConnectionStatus(false);
    }
    
    /**
     * 启用自动重连
     */
    enableAutoReconnect() {
        this.autoReconnectEnabled = true;
        this.reconnectAttempts = 0;
        console.log('自动重连已启用');
    }
    
    /**
     * 禁用自动重连
     */
    disableAutoReconnect() {
        this.autoReconnectEnabled = false;
        if (this.reconnectTimer) {
            clearTimeout(this.reconnectTimer);
            this.reconnectTimer = null;
        }
        console.log('自动重连已禁用');
    }
    
    /**
     * 显示重连提示消息
     */
    showReconnectMessage() {
        if (typeof app !== 'undefined' && app.showMessage) {
            app.showMessage('连接已断开，请检查网络连接或手动重连', 'warning');
        }
    }
    
    /**
     * 从本地存储自动连接
     */
    async autoConnect() {
        try {
            const savedIP = localStorage.getItem('raspberryPiIP');
            if (savedIP) {
                console.log('从本地存储自动连接:', savedIP);
                await this.connect(savedIP, 5001);
                return true;
            } else {
                console.log('没有保存的IP地址，使用默认IP');
                await this.connect('183.172.188.44', 5001);
                return true;
            }
        } catch (error) {
            console.error('自动连接失败:', error);
            return false;
        }
    }

    /**
     * 获取连接状态
     * @returns {boolean} 是否已连接
     */
    getConnectionStatus() {
        return this.isConnected;
    }

    /**
     * 更新连接状态显示
     * @param {boolean} connected 是否已连接
     */
    updateConnectionStatus(connected) {
        const statusDot = document.getElementById('statusDot');
        const statusText = document.getElementById('statusText');
        
        if (statusDot && statusText) {
            if (connected) {
                statusDot.classList.add('connected');
                statusText.textContent = '已连接';
            } else {
                statusDot.classList.remove('connected');
                statusText.textContent = '未连接';
            }
        }
    }

    /**
     * 设置连接成功回调
     * @param {function} callback 回调函数
     */
    setOnConnect(callback) {
        this.onConnectCallback = callback;
    }

    /**
     * 设置断开连接回调
     * @param {function} callback 回调函数
     */
    setOnDisconnect(callback) {
        this.onDisconnectCallback = callback;
    }

    /**
     * 设置错误回调
     * @param {function} callback 回调函数
     */
    setOnError(callback) {
        this.onErrorCallback = callback;
    }

    /**
     * 启动心跳机制
     */
    startHeartbeat() {
        // 清除之前的心跳定时器
        this.stopHeartbeat();
        
        // 每30秒发送一次心跳
        this.heartbeatInterval = setInterval(() => {
            if (this.isConnected && this.ws) {
                try {
                    // 发送ping消息
                    this.ws.send(JSON.stringify({
                        type: 'ping',
                        timestamp: Date.now()
                    }));
                    
                    // 设置心跳超时检测
                    this.heartbeatTimeout = setTimeout(() => {
                        const timeSinceLastPong = Date.now() - this.lastPongTime;
                        if (timeSinceLastPong > 60000) { // 60秒没有收到pong
                            console.warn('心跳超时，主动断开连接');
                            this.ws.close();
                        }
                    }, 30000); // 30秒后检查
                    
                } catch (error) {
                    console.error('发送心跳失败:', error);
                }
            }
        }, 30000); // 每30秒发送一次心跳
    }

    /**
     * 停止心跳机制
     */
    stopHeartbeat() {
        if (this.heartbeatInterval) {
            clearInterval(this.heartbeatInterval);
            this.heartbeatInterval = null;
        }
        if (this.heartbeatTimeout) {
            clearTimeout(this.heartbeatTimeout);
            this.heartbeatTimeout = null;
        }
    }

    /**
     * 处理心跳响应
     */
    handleHeartbeat(data) {
        if (data.type === 'pong') {
            this.lastPongTime = Date.now();
            console.log('收到心跳响应');
            
            // 清除心跳超时定时器
            if (this.heartbeatTimeout) {
                clearTimeout(this.heartbeatTimeout);
                this.heartbeatTimeout = null;
            }
        }
    }

    // 入库流程相关方法
    /**
     * 设置食品数量
     * @param {number} foodNumber 食品数量
     * @returns {Promise} 响应Promise
     */
    setFoodNumber(foodNumber) {
        return new Promise((resolve, reject) => {
            if (!this.sendJSON('inbound_food_number', { food_number: foodNumber })) {
                reject(new Error('发送消息失败'));
                return;
            }
            
            this.waitForResponse('inbound_ready')
                .then(resolve)
                .catch(reject);
        });
    }

    /**
     * 启动RFID读取
     * @returns {Promise} 响应Promise
     */
    startRfidReading() {
        return new Promise((resolve, reject) => {
            if (!this.sendJSON('inbound_rfid_reading')) {
                reject(new Error('发送消息失败'));
                return;
            }
            
            this.waitForResponse('inbound_rfid_result')
                .then(resolve)
                .catch(reject);
        });
    }

    /**
     * 启动信息处理
     * @returns {Promise} 响应Promise
     */
    startInfoProcess() {
        return new Promise((resolve, reject) => {
            if (!this.sendJSON('inbound_info_process')) {
                reject(new Error('发送消息失败'));
                return;
            }
            
            // 设置120秒超时
            this.waitForResponse('inbound_info_process', 120000)
                .then(resolve)
                .catch(reject);
        });
    }

    /**
     * 确认上传成功
     * @returns {Promise} 响应Promise
     */
    confirmUploadSuccess() {
        return new Promise((resolve, reject) => {
            if (!this.sendJSON('inbound_upload_success')) {
                reject(new Error('发送消息失败'));
                return;
            }
            
            this.waitForResponse('inbound_upload_success')
                .then(resolve)
                .catch(reject);
        });
    }

    /**
     * 结束入库流程
     * @returns {Promise} 响应Promise
     */
    endInbound() {
        return new Promise((resolve, reject) => {
            if (!this.sendJSON('inbound_end')) {
                reject(new Error('发送消息失败'));
                return;
            }
            
            this.waitForResponse('inbound_end')
                .then(resolve)
                .catch(reject);
        });
    }

    /**
     * 取消入库流程
     * @returns {Promise} 响应Promise
     */
    cancelInbound() {
        return new Promise((resolve, reject) => {
            if (!this.sendJSON('inbound_cancel')) {
                reject(new Error('发送消息失败'));
                return;
            }
            
            this.waitForResponse('inbound_cancel')
                .then(resolve)
                .catch(reject);
        });
    }

    // 食品列表基于本地存储管理
}

// 创建全局WebSocket管理器实例
const wsManager = new WebSocketManager();
