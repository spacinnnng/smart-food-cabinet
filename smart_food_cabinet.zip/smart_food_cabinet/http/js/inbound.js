/**
 * 入库流程管理类
 * 专门处理入库相关的逻辑
 */

class InboundManager {
    constructor() {
        this.currentStep = 1;
        this.uploadedImages = [];
        this.shareImages = []; // 分享图片数组
        this.foodQuantity = 1;
        this.rfidResult = null;
        this.processingResult = null;
        this.expectedImageCount = 0;
        this.receivedImages = [];
        this.init();
    }

    /**
     * 初始化入库管理器
     */
    init() {
        this.setupEventListeners();
        this.registerMessageHandlers();
        
        // 设置图片接收回调
        wsManager.onImageReceived = (imageUrl, imageBlob) => {
            this.handleImageReceived(imageUrl, imageBlob);
        };
    }

    /**
     * 设置事件监听器
     */
    setupEventListeners() {
        // 图片选择事件
        const imageInput = document.getElementById('imageInput');
        if (imageInput) {
            imageInput.addEventListener('change', (e) => {
                this.handleImageUpload(e);
            });
        }

        // 分享图片选择事件
        const shareImageInput = document.getElementById('shareImageInput');
        if (shareImageInput) {
            shareImageInput.addEventListener('change', (e) => {
                this.handleShareImageUpload(e);
            });
        }
    }

    /**
     * 注册消息处理器
     */
    registerMessageHandlers() {
        wsManager.registerHandler('inbound_rfid_result', 'success', (message) => {
            this.handleRfidResult(message);
        });

        wsManager.registerHandler('inbound_rfid_result', 'timeout', (message) => {
            this.handleRfidResult(message);
        });

        wsManager.registerHandler('inbound_info_process', 'success', (message) => {
            this.handleInfoProcessResult(message);
        });

        wsManager.registerHandler('inbound_info_process', 'images', (message) => {
            this.handleImagesReady(message);
        });
    }

    /**
     * 开始入库流程
     */
    start() {
        if (!wsManager.getConnectionStatus()) {
            app.showMessage('请先连接WebSocket', 'error');
            return;
        }

        this.reset();
        this.showInboundPages();
        this.showStep(1);
    }

    /**
     * 重置入库流程
     */
    reset() {
        this.currentStep = 1;
        this.uploadedImages = [];
        this.foodQuantity = 1;
        this.rfidResult = null;
        this.processingResult = null;
    }

    /**
     * 显示入库页面
     */
    showInboundPages() {
        const inboundContainer = document.getElementById('inbound-pages');
        if (inboundContainer) {
            inboundContainer.style.display = 'flex';
        }
    }

    /**
     * 隐藏入库页面
     */
    hideInboundPages() {
        const inboundContainer = document.getElementById('inbound-pages');
        if (inboundContainer) {
            inboundContainer.style.display = 'none';
        }
    }

    /**
     * 显示指定步骤
     * @param {number} step 步骤编号
     */
    showStep(step) {
        // 隐藏所有步骤
        const steps = document.querySelectorAll('.inbound-page');
        steps.forEach(stepEl => {
            stepEl.classList.remove('active');
        });

        // 显示当前步骤
        const currentStepEl = document.getElementById(this.getStepId(step));
        if (currentStepEl) {
            currentStepEl.classList.add('active');
        }

        this.currentStep = step;
    }

    /**
     * 获取步骤ID
     * @param {number} step 步骤编号
     * @returns {string} 步骤ID
     */
    getStepId(step) {
        const stepIds = {
            1: 'data-prep-page',
            2: 'rfid-reading-page',
            3: 'info-processing-page',
            4: 'success-page',
            5: 'failed-page'
        };
        return stepIds[step] || 'data-prep-page';
    }

    /**
     * 选择图片
     */
    selectImages() {
        const imageInput = document.getElementById('imageInput');
        if (imageInput) {
            imageInput.click();
        }
    }

    /**
     * 处理图片上传
     * @param {Event} event 文件选择事件
     */
    handleImageUpload(event) {
        const newFiles = Array.from(event.target.files);
        
        // 检查总数是否超过限制
        if (this.uploadedImages.length + newFiles.length > 6) {
            app.showMessage('最多只能选择6张图片', 'error');
            return;
        }

        // 追加新文件到现有列表
        this.uploadedImages = [...this.uploadedImages, ...newFiles];
        this.updateImagePreview();
        
        // 清空input值，允许重复选择相同文件
        event.target.value = '';
    }

    /**
     * 更新图片预览
     */
    updateImagePreview() {
        const imageGrid = document.getElementById('imageGrid');
        if (!imageGrid) return;

        // 清空现有内容
        imageGrid.innerHTML = '';

        // 添加已选择的图片
        this.uploadedImages.forEach((file, index) => {
            const imageItem = document.createElement('div');
            imageItem.className = 'image-item';
            imageItem.innerHTML = `
                <img src="${URL.createObjectURL(file)}" alt="预览图片 ${index + 1}">
                <button class="remove-image" onclick="inboundManager.removeImage(${index})">×</button>
            `;
            imageGrid.appendChild(imageItem);
        });

        // 如果还有空间，添加上传按钮
        if (this.uploadedImages.length < 6) {
            const uploadItem = document.createElement('div');
            uploadItem.className = 'upload-item';
            uploadItem.onclick = () => this.selectImages();
            uploadItem.innerHTML = `
                <span class="upload-icon">+</span>
                <span class="upload-text">添加图片</span>
            `;
            imageGrid.appendChild(uploadItem);
        }
    }

    /**
     * 移除图片
     * @param {number} index 图片索引
     */
    removeImage(index) {
        this.uploadedImages.splice(index, 1);
        this.updateImagePreview();
    }

    /**
     * 进入RFID读取步骤
     */
    async proceedToRfid() {
        if (this.uploadedImages.length === 0) {
            app.showMessage('请选择至少一张图片', 'error');
            return;
        }

        // 检查WebSocket连接状态
        if (!wsManager.isConnected) {
            app.showMessage('WebSocket连接已断开，正在尝试重连...', 'warning');
            try {
                await wsManager.connect();
                // 等待连接稳定
                await new Promise(resolve => setTimeout(resolve, 1000));
            } catch (error) {
                app.showMessage('无法连接到服务器，请检查网络连接', 'error');
                return;
            }
        }

        const quantityInput = document.getElementById('foodQuantity');
        if (quantityInput) {
            this.foodQuantity = parseInt(quantityInput.value) || 1;
        }

        try {
            app.showMessage('上传图片中...', 'info');

            // 上传图片（带重试机制）
            for (let i = 0; i < this.uploadedImages.length; i++) {
                const file = this.uploadedImages[i];
                
                try {
                    const imageData = await this.fileToArrayBuffer(file);
                    console.log(`开始上传图片 ${i + 1}/${this.uploadedImages.length}: ${file.name}`);
                    
                    // 重试上传图片（最多3次）
                    let uploadSuccess = false;
                    for (let retry = 0; retry < 3; retry++) {
                        try {
                            // 检查WebSocket连接状态
                            if (!wsManager.isConnected) {
                                throw new Error('WebSocket连接已断开');
                            }
                            
                            // 发送图片数据
                            if (!wsManager.sendBinary(imageData)) {
                                throw new Error('图片上传失败');
                            }

                            // 等待确认（增加超时时间到60秒）
                            const response = await wsManager.waitForResponse('inbound_ready', 60000);
                            console.log(`图片 ${i + 1}/${this.uploadedImages.length} 上传成功:`, response);
                            uploadSuccess = true;
                            break;
                        } catch (error) {
                            console.warn(`图片 ${i + 1} 上传失败 (尝试 ${retry + 1}/3):`, error.message);
                            if (retry < 2) {
                                // 等待1秒后重试
                                await new Promise(resolve => setTimeout(resolve, 1000));
                            }
                        }
                    }
                    
                    if (!uploadSuccess) {
                        throw new Error(`图片 ${i + 1} 上传失败，已重试3次`);
                    }
                } catch (error) {
                    if (error.message.includes('文件过大') || error.message.includes('文件为空')) {
                        throw new Error(`图片 ${i + 1} 处理失败: ${error.message}`);
                    } else {
                        throw new Error(`图片 ${i + 1} 上传失败: ${error.message}`);
                    }
                }
            }

            // 设置食品数量（带重试机制）
            let setQuantitySuccess = false;
            for (let retry = 0; retry < 3; retry++) {
                try {
                    await wsManager.setFoodNumber(this.foodQuantity);
                    console.log(`食品数量设置成功: ${this.foodQuantity}`);
                    setQuantitySuccess = true;
                    break;
                } catch (error) {
                    console.warn(`设置食品数量失败 (尝试 ${retry + 1}/3):`, error.message);
                    if (retry < 2) {
                        await new Promise(resolve => setTimeout(resolve, 1000));
                    }
                }
            }
            
            if (!setQuantitySuccess) {
                throw new Error('设置食品数量失败，已重试3次');
            }

            app.showMessage('数据准备完成', 'success');
            
            // 进入RFID读取步骤
            this.showStep(2);
            this.startRfidReading();

        } catch (error) {
            app.showMessage('数据准备失败: ' + error.message, 'error');
            console.error('入库流程错误:', error);
        }
    }

    /**
     * 开始RFID读取
     */
    startRfidReading() {
        wsManager.startRfidReading().catch(error => {
            app.showMessage('RFID读取失败: ' + error.message, 'error');
        });
    }

    /**
     * 处理RFID读取结果
     * @param {object} message 消息对象
     */
    handleRfidResult(message) {
        this.rfidResult = message.data;
        
        const rfidProgress = document.getElementById('rfidProgress');
        const rfidProgressBar = document.getElementById('rfidProgressBar');
        
        if (message.action === 'success') {
            if (rfidProgress) {
                rfidProgress.innerHTML = `
                    <div class="success-message">
                        <h4>RFID读取成功！</h4>
                        <p>标签数量: ${message.data.tag_count}</p>
                        <p>标签列表: ${message.data.rfid_list}</p>
                    </div>
                `;
            }
            if (rfidProgressBar) {
                rfidProgressBar.style.width = '100%';
            }
        } else if (message.action === 'timeout') {
            if (rfidProgress) {
                rfidProgress.innerHTML = `
                    <div class="warning-message">
                        <h4>RFID读取超时</h4>
                        <p>已识别标签数量: ${message.data.tag_count}</p>
                        <p>标签列表: ${message.data.rfid_list}</p>
                    </div>
                `;
            }
            if (rfidProgressBar) {
                rfidProgressBar.style.width = '80%';
            }
        }

        // 自动进入信息处理步骤
        setTimeout(() => {
            this.showStep(3);
            this.startInfoProcess();
        }, 2000);
    }

    /**
     * 开始信息处理
     */
    startInfoProcess() {
        wsManager.startInfoProcess().catch(error => {
            app.showMessage('信息处理失败: ' + error.message, 'error');
        });
    }

    /**
     * 处理信息处理结果
     * @param {object} message 消息对象
     */
    handleInfoProcessResult(message) {
        this.processingResult = message.data;
        
        if (message.action === 'success') {
            console.log('信息处理完成:', message.data.db_data_list);
            // 自动进入成功步骤
            setTimeout(() => {
                this.showStep(4);
                this.startCountdown();
            }, 1000);
        } else if (message.action === 'images') {
            console.log('图片处理完成:', message.data.image_count);
        }
    }

    /**
     * 处理图片准备完成
     * @param {object} message 消息对象
     */
    handleImagesReady(message) {
        console.log('图片处理完成:', message.data.image_count);
        this.expectedImageCount = message.data.image_count;
        this.receivedImages = [];
    }

    /**
     * 处理接收到的图片
     * @param {string} imageUrl 图片URL
     * @param {Blob} imageBlob 图片Blob
     */
    async handleImageReceived(imageUrl, imageBlob) {
        console.log('收到图片:', imageUrl);
        
        // 将Blob转换为base64格式，以便持久化保存
        const base64Image = await this.blobToBase64(imageBlob);
        
        this.receivedImages.push({
            url: imageUrl,
            blob: imageBlob,
            base64: base64Image
        });
        
        // 如果收到了所有图片，处理图片数据
        if (this.receivedImages.length === this.expectedImageCount) {
            this.processReceivedImages();
        }
    }

    /**
     * 将Blob转换为base64格式
     * @param {Blob} blob 图片Blob
     * @returns {Promise<string>} base64格式的图片数据
     */
    blobToBase64(blob) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => resolve(reader.result);
            reader.onerror = reject;
            reader.readAsDataURL(blob);
        });
    }

    /**
     * 处理接收到的所有图片
     */
    processReceivedImages() {
        console.log('开始处理接收到的图片:', this.receivedImages.length);
        
        // 图片数据已经保存在 this.receivedImages 中
        // 在入库完成时会通过 saveInboundDataToLocal() 方法一起保存到食品数据中
        console.log('图片数据已准备就绪，等待入库完成时保存');
    }

    /**
     * 开始倒计时
     */
    startCountdown() {
        let countdown = 3;
        const countdownElement = document.getElementById('countdown');
        
        const timer = setInterval(() => {
            if (countdownElement) {
                countdownElement.textContent = `${countdown}秒后将自动跳转返回首页`;
            }
            countdown--;
            
            if (countdown < 0) {
                clearInterval(timer);
                this.completeInbound();
            }
        }, 1000);
    }

    /**
     * 完成入库
     */
    async completeInbound() {
        try {
            // 确认上传成功
            await wsManager.confirmUploadSuccess();
            
            // 结束入库流程
            await wsManager.endInbound();
            
            // 将入库数据保存到本地食品列表
            this.saveInboundDataToLocal();
            
            // 添加入库通知
            if (this.processingResult && this.processingResult.db_data_list) {
                const dbData = this.processingResult.db_data_list;
                const foodName = dbData.name || '未知食品';
                const foodNumber = dbData.food_number || 1;
                const today = new Date().toLocaleDateString();
                
                app.addInboundNotification('inbound_success', today, `成功入库${foodNumber}件${foodName}`);
            } else {
                const today = new Date().toLocaleDateString();
                app.addInboundNotification('inbound_success', today, '成功入库食品');
            }
            
            app.showMessage('入库完成！', 'success');
            this.hideInboundPages();
            
            // 刷新食品列表显示
            app.loadFoodList();
            
            // 更新通知
            app.updateNotifications();

        } catch (error) {
            app.showMessage('完成入库失败: ' + error.message, 'error');
        }
    }

    /**
     * 将入库数据保存到本地食品列表
     */
    saveInboundDataToLocal() {
        if (!this.processingResult || !this.processingResult.db_data_list) {
            console.warn('没有处理结果数据，无法保存到本地');
            return;
        }

        const dbData = this.processingResult.db_data_list;
        const rfidData = this.rfidResult;
        
        // 构建食品数据对象
        const foodData = {
            food_id: dbData.food_id || null, // 从数据库获取的food_id
            name: dbData.name || '未知食品',
            net_weight: `${dbData.net_value || 0}${dbData.net_unit || ''}`,
            production_date: dbData.production_date || '',
            expiry_period: this.formatShelfLife(dbData),
            expire_date: dbData.expire_date || '', // 添加到期日期字段
            quantity: dbData.food_number || 1,
            rfid_list: rfidData ? rfidData.rfid_list : '',
            category: dbData.category || '',
            allergens: this.parseAllergens(dbData),
            createdAt: new Date().toISOString(),
            // 营养成分数据
            calorie_per_unit: dbData.calorie_per_unit || null,
            protein_per_unit: dbData.protein_per_unit || null,
            fat_per_unit: dbData.fat_per_unit || null,
            carbo_per_unit: dbData.carbo_per_unit || null,
            sugar_per_unit: dbData.sugar_per_unit || null,
            sodium_per_unit: dbData.sodium_per_unit || null,
            // 图片数据
            image: this.receivedImages.length > 0 ? this.receivedImages[0].base64 : null,
            detailImages: this.receivedImages.map(img => img.base64)
        };

        // 添加到食品列表
        app.foodList.push(foodData);
        
        // 保存到本地存储
        app.saveUserData();
        
        console.log('入库数据已保存到本地:', foodData);
    }

    /**
     * 格式化保质期信息
     * @param {Object} dbData 数据库数据
     * @returns {string} 格式化后的保质期字符串
     */
    formatShelfLife(dbData) {
        const year = dbData.shelf_life_year || 0;
        const month = dbData.shelf_life_month || 0;
        const day = dbData.shelf_life_day || 0;
        
        const parts = [];
        if (year > 0) parts.push(`${year}年`);
        if (month > 0) parts.push(`${month}个月`);
        if (day > 0) parts.push(`${day}天`);
        
        return parts.length > 0 ? parts.join('') : '未知';
    }

    /**
     * 解析过敏原信息
     * @param {Object} dbData 数据库数据
     * @returns {Array} 过敏原数组
     */
    parseAllergens(dbData) {
        const allergens = [];
        const allergenFields = [
            { field: 'gluten_valid', name: '麸质' },
            { field: 'cara_valid', name: '甲壳类' },
            { field: 'fish_valid', name: '鱼类' },
            { field: 'egg_valid', name: '蛋类' },
            { field: 'peanut_valid', name: '花生' },
            { field: 'soy_valid', name: '大豆' },
            { field: 'dairy_valid', name: '乳制品' },
            { field: 'nut_valid', name: '坚果' }
        ];

        allergenFields.forEach(({ field, name }) => {
            if (dbData[field] === 1) {
                allergens.push(name);
            }
        });

        return allergens;
    }

    /**
     * 取消入库
     */
    async cancel() {
        try {
            await wsManager.cancelInbound();
            app.showMessage('入库已取消', 'success');
            this.hideInboundPages();
        } catch (error) {
            app.showMessage('取消失败: ' + error.message, 'error');
        }
    }

    /**
     * 重试入库
     */
    retry() {
        this.showStep(1);
    }

    /**
     * 压缩图片
     * @param {File} file 原始图片文件
     * @param {number} maxWidth 最大宽度
     * @param {number} maxHeight 最大高度
     * @param {number} quality 压缩质量 (0-1)
     * @returns {Promise<File>} 压缩后的文件
     */
    compressImage(file, maxWidth = 1920, maxHeight = 1080, quality = 0.8) {
        return new Promise((resolve, reject) => {
            const canvas = document.createElement('canvas');
            const ctx = canvas.getContext('2d');
            const img = new Image();
            
            img.onload = () => {
                // 计算压缩后的尺寸
                let { width, height } = img;
                
                if (width > maxWidth || height > maxHeight) {
                    const ratio = Math.min(maxWidth / width, maxHeight / height);
                    width *= ratio;
                    height *= ratio;
                }
                
                // 设置canvas尺寸
                canvas.width = width;
                canvas.height = height;
                
                // 绘制压缩后的图片
                ctx.drawImage(img, 0, 0, width, height);
                
                // 转换为Blob
                canvas.toBlob((blob) => {
                    if (blob) {
                        // 创建新的File对象
                        const compressedFile = new File([blob], file.name, {
                            type: 'image/jpeg',
                            lastModified: Date.now()
                        });
                        
                        console.log(`图片压缩完成: ${(file.size / 1024).toFixed(2)}KB → ${(compressedFile.size / 1024).toFixed(2)}KB`);
                        resolve(compressedFile);
                    } else {
                        reject(new Error('图片压缩失败'));
                    }
                }, 'image/jpeg', quality);
            };
            
            img.onerror = () => {
                reject(new Error('图片加载失败'));
            };
            
            // 加载图片
            const reader = new FileReader();
            reader.onload = (e) => {
                img.src = e.target.result;
            };
            reader.onerror = () => {
                reject(new Error('文件读取失败'));
            };
            reader.readAsDataURL(file);
        });
    }

    /**
     * 文件转ArrayBuffer（带自动压缩）
     * @param {File} file 文件对象
     * @returns {Promise<ArrayBuffer>} ArrayBuffer
     */
    async fileToArrayBuffer(file) {
        // 检查文件大小 - 大幅降低限制以支持WebSocket实际传输能力
        const maxSize = 500 * 1024; // 500KB - WebSocket实际传输上限
        const compressThreshold = 300 * 1024; // 300KB，超过此大小开始压缩
        
        if (file.size === 0) {
            throw new Error('文件为空');
        }
        
        console.log(`准备处理文件: ${file.name}, 大小: ${(file.size / 1024).toFixed(2)}KB`);
        
        let processedFile = file;
        
        // 如果文件过大，尝试压缩
        if (file.size > maxSize * 20) { // 允许原始文件最大10MB
            throw new Error(`文件过大: ${(file.size / 1024 / 1024).toFixed(2)}MB，最大支持10MB原始文件`);
        }
        
        // 如果文件较大，进行压缩（针对WebSocket传输优化）
        if (file.size > compressThreshold) {
            try {
                console.log('文件较大，开始压缩...');
                
                // 多级压缩策略 - 针对WebSocket传输优化
                const compressionLevels = [
                    { width: 1280, height: 720, quality: 0.6, name: '中等压缩' },
                    { width: 1024, height: 576, quality: 0.5, name: '较强压缩' },
                    { width: 800, height: 450, quality: 0.4, name: '强压缩' },
                    { width: 640, height: 360, quality: 0.3, name: '极强压缩' },
                    { width: 480, height: 270, quality: 0.2, name: '极限压缩' }
                ];
                
                for (let i = 0; i < compressionLevels.length; i++) {
                    const level = compressionLevels[i];
                    console.log(`尝试${level.name}...`);
                    
                    processedFile = await this.compressImage(file, level.width, level.height, level.quality);
                    
                    if (processedFile.size <= maxSize) {
                        console.log(`${level.name}成功，最终大小: ${(processedFile.size / 1024).toFixed(2)}KB`);
                        break;
                    }
                    
                    if (i === compressionLevels.length - 1) {
                        throw new Error(`即使极限压缩后文件仍然过大: ${(processedFile.size / 1024 / 1024).toFixed(2)}MB`);
                    }
                }
            } catch (error) {
                throw new Error(`图片压缩失败: ${error.message}`);
            }
        }
        
        // 转换为ArrayBuffer
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => {
                console.log(`文件处理完成: ${reader.result.byteLength} bytes`);
                resolve(reader.result);
            };
            reader.onerror = (error) => {
                console.error('文件读取失败:', error);
                reject(error);
            };
            reader.readAsArrayBuffer(processedFile);
        });
    }

    // 分享相关功能
    /**
     * 选择分享图片
     */
    selectShareImages() {
        const shareImageInput = document.getElementById('shareImageInput');
        if (shareImageInput) {
            shareImageInput.click();
        }
    }

    /**
     * 处理分享图片上传
     * @param {Event} event 文件选择事件
     */
    handleShareImageUpload(event) {
        const newFiles = Array.from(event.target.files);
        
        // 获取当前已选择的图片数量
        const currentImages = document.querySelectorAll('#shareImageGrid .image-item').length;
        
        // 检查总数是否超过限制
        if (currentImages + newFiles.length > 4) {
            app.showMessage('最多只能选择4张图片', 'error');
            return;
        }

        // 获取现有文件列表（从DOM中重建）
        const existingFiles = this.getExistingShareImages();
        const allFiles = [...existingFiles, ...newFiles];
        
        this.updateShareImagePreview(allFiles);
        
        // 清空input值，允许重复选择相同文件
        event.target.value = '';
    }

    /**
     * 获取现有的分享图片文件列表
     * @returns {Array<File>} 现有文件列表
     */
    getExistingShareImages() {
        // 从DOM中获取现有图片的src，重建File对象
        const existingImages = document.querySelectorAll('#shareImageGrid .image-item img');
        const files = [];
        
        existingImages.forEach((img, index) => {
            // 从URL.createObjectURL创建的URL中无法直接获取原始File对象
            // 这里我们使用一个简单的方法：存储文件引用
            if (this.shareImages && this.shareImages[index]) {
                files.push(this.shareImages[index]);
            }
        });
        
        return files;
    }

    /**
     * 更新分享图片预览
     * @param {Array<File>} files 文件数组
     */
    updateShareImagePreview(files) {
        const shareImageGrid = document.getElementById('shareImageGrid');
        if (!shareImageGrid) return;

        // 保存文件引用
        this.shareImages = files;

        // 清空现有内容
        shareImageGrid.innerHTML = '';

        // 添加已选择的图片
        files.forEach((file, index) => {
            const imageItem = document.createElement('div');
            imageItem.className = 'image-item';
            imageItem.innerHTML = `
                <img src="${URL.createObjectURL(file)}" alt="分享图片 ${index + 1}">
                <button class="remove-image" onclick="inboundManager.removeShareImage(${index})">×</button>
            `;
            shareImageGrid.appendChild(imageItem);
        });

        // 如果还有空间，添加上传按钮
        if (files.length < 4) {
            const uploadItem = document.createElement('div');
            uploadItem.className = 'upload-item';
            uploadItem.onclick = () => this.selectShareImages();
            uploadItem.innerHTML = `
                <span class="upload-icon">+</span>
                <span class="upload-text">添加图片</span>
            `;
            shareImageGrid.appendChild(uploadItem);
        }
    }

    /**
     * 移除分享图片
     * @param {number} index 图片索引
     */
    removeShareImage(index) {
        if (this.shareImages && this.shareImages.length > index) {
            this.shareImages.splice(index, 1);
            this.updateShareImagePreview(this.shareImages);
        }
    }
}

// 创建入库管理器实例
const inboundManager = new InboundManager();

// 全局函数
function startInbound() {
    inboundManager.start();
}

function selectImages() {
    inboundManager.selectImages();
}

function proceedToRfid() {
    inboundManager.proceedToRfid();
}

function cancelInbound() {
    inboundManager.cancel();
}

function retryInbound() {
    inboundManager.retry();
}

function selectShareImages() {
    inboundManager.selectShareImages();
}

function handleImageUpload(event) {
    inboundManager.handleImageUpload(event);
}

function handleShareImageUpload(event) {
    inboundManager.handleShareImageUpload(event);
}
