/**
 * 社交功能管理类
 * 负责社交分享、点赞、评论等功能
 */

class SocialManager {
    constructor() {
        this.shareImages = [];
        this.init();
    }

    /**
     * 初始化社交管理器
     */
    init() {
        this.setupEventListeners();
    }

    /**
     * 设置事件监听器
     */
    setupEventListeners() {
        // 设置社交功能相关的事件监听器
    }


    /**
     * 提交分享
     */
    submitShare() {
        const diaryTitle = document.getElementById('diaryTitle');
        const shareText = document.getElementById('shareText');
        const title = diaryTitle ? diaryTitle.value.trim() : '';
        const content = shareText ? shareText.value.trim() : '';
        
        // 检查是否至少有一项内容（标题、文字内容或图片）
        if (!title && !content && this.shareImages.length === 0) {
            app.showMessage('请至少填写标题、内容或上传图片中的一项', 'error');
            return;
        }

        const newPost = {
            id: Date.now(),
            userName: localStorage.getItem('userName') || '体验用户',
            userAvatar: localStorage.getItem('userAvatar') || 'images/default-avatar.png',
            title: title || null,
            content: content,
            images: this.shareImages,
            likes: 0,
            comments: 0,
            time: new Date().toLocaleString(),
            createdAt: new Date().toISOString()
        };

        // 添加到日记列表
        app.socialPosts.unshift(newPost);
        app.saveUserData();

        // 添加日记发布通知
        const today = new Date().toLocaleDateString();
        app.addDiaryNotification('publish', today, `你记录了一条日记【${title || '无标题日记'}】`);

        // 清空表单
        this.clearShareForm();

        // 返回日记页面
        pageManager.showPage('diary');

        app.showMessage('日记发布成功！', 'success');
    }

    /**
     * 清空分享表单
     */
    clearShareForm() {
        // 清空标题
        const diaryTitle = document.getElementById('diaryTitle');
        if (diaryTitle) {
            diaryTitle.value = '';
        }

        // 清空文本
        const shareText = document.getElementById('shareText');
        if (shareText) {
            shareText.value = '';
        }

        // 清空图片
        this.shareImages = [];
        this.updateShareImagePreview([]);
    }

    /**
     * 更新分享图片预览
     * @param {Array} images 图片数组（base64字符串或File对象）
     */
    updateShareImagePreview(images) {
        const shareImageGrid = document.getElementById('shareImageGrid');
        if (!shareImageGrid) return;

        // 清空现有内容
        shareImageGrid.innerHTML = '';

        // 添加已选择的图片
        images.forEach((image, index) => {
            const imageItem = document.createElement('div');
            imageItem.className = 'image-item';
            
            // 判断是base64字符串还是File对象
            const imageSrc = typeof image === 'string' ? image : URL.createObjectURL(image);
            
            imageItem.innerHTML = `
                <img src="${imageSrc}" alt="分享图片 ${index + 1}">
                <button class="remove-image" onclick="socialManager.removeShareImage(${index})">×</button>
            `;
            shareImageGrid.appendChild(imageItem);
        });

        // 如果还有空间，添加上传按钮
        if (images.length < 4) {
            const uploadItem = document.createElement('div');
            uploadItem.className = 'upload-item';
            uploadItem.onclick = () => this.selectShareImages();
            uploadItem.innerHTML = `
                <span class="upload-icon">+</span>
                <span class="upload-text">添加图片</span>
            `;
            shareImageGrid.appendChild(uploadItem);
        }
    }

    /**
     * 选择分享图片
     */
    selectShareImages() {
        const shareImageInput = document.getElementById('shareImageInput');
        if (shareImageInput) {
            shareImageInput.click();
        }
    }

    /**
     * 处理分享图片上传
     * @param {Event} event 文件选择事件
     */
    async handleShareImageUpload(event) {
        const newFiles = Array.from(event.target.files);
        
        // 检查总数是否超过限制
        if (this.shareImages.length + newFiles.length > 4) {
            app.showMessage('最多只能选择4张图片', 'error');
            return;
        }

        // 将新图片转换为base64格式并追加到现有列表
        const newBase64Images = await this.convertFilesToBase64(newFiles);
        this.shareImages = [...this.shareImages, ...newBase64Images];
        this.updateShareImagePreview(this.shareImages);
        
        // 清空input值，允许重复选择相同文件
        event.target.value = '';
    }

    /**
     * 压缩图片
     * @param {File} file 原始图片文件
     * @param {number} maxWidth 最大宽度
     * @param {number} maxHeight 最大高度
     * @param {number} quality 压缩质量 (0-1)
     * @returns {Promise<File>} 压缩后的文件
     */
    compressImage(file, maxWidth = 1920, maxHeight = 1080, quality = 0.8) {
        return new Promise((resolve, reject) => {
            const canvas = document.createElement('canvas');
            const ctx = canvas.getContext('2d');
            const img = new Image();
            
            img.onload = () => {
                // 计算压缩后的尺寸
                let { width, height } = img;
                
                if (width > maxWidth || height > maxHeight) {
                    const ratio = Math.min(maxWidth / width, maxHeight / height);
                    width *= ratio;
                    height *= ratio;
                }
                
                // 设置canvas尺寸
                canvas.width = width;
                canvas.height = height;
                
                // 绘制压缩后的图片
                ctx.drawImage(img, 0, 0, width, height);
                
                // 转换为Blob
                canvas.toBlob((blob) => {
                    if (blob) {
                        // 创建新的File对象
                        const compressedFile = new File([blob], file.name, {
                            type: 'image/jpeg',
                            lastModified: Date.now()
                        });
                        
                        console.log(`图片压缩完成: ${(file.size / 1024).toFixed(2)}KB → ${(compressedFile.size / 1024).toFixed(2)}KB`);
                        resolve(compressedFile);
                    } else {
                        reject(new Error('图片压缩失败'));
                    }
                }, 'image/jpeg', quality);
            };
            
            img.onerror = () => {
                reject(new Error('图片加载失败'));
            };
            
            // 加载图片
            const reader = new FileReader();
            reader.onload = (e) => {
                img.src = e.target.result;
            };
            reader.onerror = () => {
                reject(new Error('文件读取失败'));
            };
            reader.readAsDataURL(file);
        });
    }

    /**
     * 将文件转换为base64格式（带自动压缩）
     * @param {Array} files 文件数组
     * @returns {Array} base64字符串数组
     */
    async convertFilesToBase64(files) {
        const maxSize = 500 * 1024; // 500KB，超过此大小开始压缩
        const compressThreshold = 300 * 1024; // 300KB，超过此大小开始压缩
        
        return Promise.all(files.map(async (file) => {
            let processedFile = file;
            
            // 如果文件较大，进行压缩
            if (file.size > compressThreshold) {
                try {
                    console.log(`压缩分享图片: ${file.name}, 大小: ${(file.size / 1024).toFixed(2)}KB`);
                    
                    // 多级压缩策略 - 优化图片传输效率
                    const compressionLevels = [
                        { width: 1280, height: 720, quality: 0.6, name: '中等压缩' },
                        { width: 1024, height: 576, quality: 0.5, name: '较强压缩' },
                        { width: 800, height: 450, quality: 0.4, name: '强压缩' },
                        { width: 640, height: 360, quality: 0.3, name: '极强压缩' },
                        { width: 480, height: 270, quality: 0.2, name: '极限压缩' }
                    ];
                    
                    for (let i = 0; i < compressionLevels.length; i++) {
                        const level = compressionLevels[i];
                        console.log(`尝试${level.name}...`);
                        
                        processedFile = await this.compressImage(file, level.width, level.height, level.quality);
                        
                        if (processedFile.size <= maxSize) {
                            console.log(`${level.name}成功，最终大小: ${(processedFile.size / 1024).toFixed(2)}KB`);
                            break;
                        }
                        
                        if (i === compressionLevels.length - 1) {
                            console.warn(`即使极限压缩后文件仍然过大: ${(processedFile.size / 1024 / 1024).toFixed(2)}MB，使用极限压缩结果`);
                        }
                    }
                } catch (error) {
                    console.warn(`图片压缩失败，使用原文件: ${error.message}`);
                    processedFile = file;
                }
            }
            
            return new Promise((resolve, reject) => {
                const reader = new FileReader();
                reader.onload = () => resolve(reader.result);
                reader.onerror = reject;
                reader.readAsDataURL(processedFile);
            });
        }));
    }

    /**
     * 移除分享图片
     * @param {number} index 图片索引
     */
    removeShareImage(index) {
        this.shareImages.splice(index, 1);
        this.updateShareImagePreview(this.shareImages);
    }

    /**
     * 点赞帖子
     * @param {number} postId 帖子ID
     */
    likePost(postId) {
        const post = app.socialPosts.find(p => p.id === postId);
        if (post) {
            post.likes = (post.likes || 0) + 1;
            app.saveUserData();
            pageManager.loadSocialContent();
            
            // 添加点赞通知
            const currentUser = localStorage.getItem('userName') || '当前用户';
            app.addSocialNotification('like', '其他用户', `点赞了你的分享"${post.content.substring(0, 20)}${post.content.length > 20 ? '...' : ''}"`, postId);
            
            app.showMessage('点赞成功！', 'success');
        }
    }

    /**
     * 评论帖子
     * @param {number} postId 帖子ID
     */
    commentPost(postId) {
        const comment = prompt('请输入评论内容：');
        if (comment && comment.trim()) {
            const post = app.socialPosts.find(p => p.id === postId);
            if (post) {
                post.comments = (post.comments || 0) + 1;
                app.saveUserData();
                pageManager.loadSocialContent();
                
                // 添加评论通知
                const currentUser = localStorage.getItem('userName') || '当前用户';
                app.addSocialNotification('comment', '其他用户', `评论了你的分享"${post.content.substring(0, 20)}${post.content.length > 20 ? '...' : ''}": ${comment.substring(0, 30)}${comment.length > 30 ? '...' : ''}`, postId);
                
                app.showMessage('评论成功！', 'success');
            }
        }
    }

    /**
     * 获取当前评分
     * @returns {number} 当前评分
     */
    getCurrentRating() {
        return this.currentRating;
    }

    /**
     * 获取分享图片
     * @returns {Array} 分享图片数组
     */
    getShareImages() {
        return this.shareImages;
    }
}

// 创建社交管理器实例
const socialManager = new SocialManager();

// 全局函数
function submitShare() {
    socialManager.submitShare();
}

function selectShareImages() {
    socialManager.selectShareImages();
}

async function handleShareImageUpload(event) {
    await socialManager.handleShareImageUpload(event);
}
