#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
智能食品柜主程序
负责协调入库和出库流程，管理WebSocket服务器和硬件监控
"""

import threading
import logging
import sys
import os
import signal

# 添加项目根目录到Python路径，以便导入其他模块
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# 导入配置和模块
from config import (
    setup_logging_if_needed, DATABASE_PATH, CONFIG_ERRORS,
    db_data_list, food_number, cleanup_error_images
)

# 直接导入模块文件，避免__init__.py的导入问题
from modules.database.data_manager import DatabaseManager
from modules.websocket.websocket import start_websocket_server, start_websocket_and_web_server

# 条件导入RFID模块（仅在树莓派上可用）
try:
    from modules.rfid.rfid_out import RFIDOutboundManager
    RFID_AVAILABLE = True
except ImportError as e:
    print(f"⚠️ RFID模块不可用: {e}")
    print("💡 提示：RFID功能需要在树莓派上运行")
    RFIDOutboundManager = None
    RFID_AVAILABLE = False

# 配置日志
logger = logging.getLogger(__name__)

class SmartFoodCabinetMain:
    """
    智能食品柜主程序类
    负责协调所有子系统的运行
    """
    
    def __init__(self):
        """初始化主程序"""
        self.is_running = False
        self.websocket_server_task = None
        self.outbound_manager = None
        self.outbound_thread = None
        
        logger.info("智能食品柜主程序初始化完成")
    
    def check_database(self):
        """
        检查数据库是否存在，如果不存在则创建
        """
        try:
            logger.info("检查数据库状态...")
            
            # 检查数据库文件是否存在
            if not os.path.exists(DATABASE_PATH):
                logger.info(f"数据库文件不存在，正在创建: {DATABASE_PATH}")
                
                # 创建数据库目录（如果不存在）
                db_dir = os.path.dirname(DATABASE_PATH)
                if db_dir and not os.path.exists(db_dir):
                    os.makedirs(db_dir, exist_ok=True)
                    logger.info(f"创建数据库目录: {db_dir}")
                
                # 创建数据库和表
                with DatabaseManager() as db_manager:
                    logger.info("数据库和表结构创建成功")
            else:
                logger.info(f"数据库文件已存在: {DATABASE_PATH}")
                
                # 验证数据库连接
                with DatabaseManager() as db_manager:
                    logger.info("数据库连接验证成功")
            
            return True
            
        except Exception as e:
            logger.error(f"数据库检查失败: {e}")
            return False
    
    def start_websocket_server_async(self):
        """
        启动WebSocket服务器（异步）
        """
        try:
            import asyncio
            logger.info("启动WebSocket服务器...")
            
            # 创建新的事件循环用于WebSocket服务器
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            
            # 启动WebSocket服务器
            loop.run_until_complete(start_websocket_server())
            
        except Exception as e:
            logger.error(f"WebSocket服务器启动失败: {e}")
    
    def start_websocket_and_web_server_async(self):
        """
        启动WebSocket和HTTP服务器（异步）
        """
        try:
            import asyncio
            logger.info("启动WebSocket和HTTP服务器...")
            
            # 创建新的事件循环用于服务器
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            
            # 启动WebSocket和HTTP服务器
            loop.run_until_complete(start_websocket_and_web_server())
            
        except Exception as e:
            logger.error(f"WebSocket和HTTP服务器启动失败: {e}")
    
    def start_websocket_and_web_server_thread(self):
        """
        在单独线程中启动WebSocket和HTTP服务器
        """
        try:
            self.websocket_server_task = threading.Thread(
                target=self.start_websocket_and_web_server_async,
                name="WebSocketAndWebServer",
                daemon=True
            )
            self.websocket_server_task.start()
            logger.info("WebSocket和HTTP服务器线程已启动")
            
        except Exception as e:
            logger.error(f"启动WebSocket和HTTP服务器线程失败: {e}")
    
    def start_outbound_monitoring(self):
        """
        启动出库监控流程
        """
        try:
            logger.info("启动出库监控流程...")
            
            # 检查RFID模块是否可用
            if not RFID_AVAILABLE:
                logger.warning("RFID模块不可用，跳过出库监控流程")
                return
            
            # 创建出库管理器
            self.outbound_manager = RFIDOutboundManager()
            
            # 在单独线程中启动出库监控
            self.outbound_thread = threading.Thread(
                target=self.outbound_manager.start_outbound_monitoring_with_feedback,
                args=(False,),  # test_mode=False，正常模式
                name="OutboundMonitoring",
                daemon=True
            )
            self.outbound_thread.start()
            
            logger.info("出库监控线程已启动")
            
        except Exception as e:
            logger.error(f"启动出库监控失败: {e}")
    
    def cleanup_resources(self):
        """
        清理所有资源
        """
        try:
            logger.info("开始清理资源...")
            
            # 停止出库监控
            if self.outbound_manager:
                logger.info("停止出库监控...")
                self.outbound_manager.cleanup()
                self.outbound_manager = None
            
            # 等待出库监控线程结束
            if self.outbound_thread and self.outbound_thread.is_alive():
                logger.info("等待出库监控线程结束...")
                self.outbound_thread.join(timeout=5.0)
                if self.outbound_thread.is_alive():
                    logger.warning("出库监控线程未能在5秒内结束")
            
            # 清空全局数据
            db_data_list.clear()
            global food_number
            food_number = 1
            
            logger.info("资源清理完成")
            
        except Exception as e:
            logger.error(f"清理资源失败: {e}")
    
    def signal_handler(self, signum, frame):
        """
        信号处理器，用于优雅退出
        """
        logger.info(f"收到信号 {signum}，开始优雅退出...")
        self.stop()
    
    def start(self):
        """
        启动主程序
        """
        try:
            logger.info("=" * 60)
            logger.info("智能食品柜系统启动中...")
            logger.info("=" * 60)
            
            # 检查配置错误
            if CONFIG_ERRORS:
                logger.error("配置错误，无法启动系统:")
                for error in CONFIG_ERRORS:
                    logger.error(f"  - {error}")
                return False
            
            # 检查数据库
            if not self.check_database():
                logger.error("数据库检查失败，无法启动系统")
                return False
            
            # 清理错误图片文件
            cleaned_count = cleanup_error_images()
            if cleaned_count > 0:
                logger.info(f"系统启动时清理了 {cleaned_count} 个错误图片文件")
            
            # 设置信号处理器
            signal.signal(signal.SIGINT, self.signal_handler)
            signal.signal(signal.SIGTERM, self.signal_handler)
            
            # 启动WebSocket和HTTP服务器（处理入库流程和网页服务）
            self.start_websocket_and_web_server_thread()
            
            # 启动出库监控流程
            self.start_outbound_monitoring()
            
            self.is_running = True
            logger.info("智能食品柜系统启动成功！")
            logger.info("系统正在运行，等待用户操作...")
            logger.info("输入 'quit' 或按 Ctrl+C 退出程序")
            
            return True
            
        except Exception as e:
            logger.error(f"启动系统失败: {e}")
            self.cleanup_resources()
            return False
    
    def stop(self):
        """
        停止主程序
        """
        if not self.is_running:
            return
        
        logger.info("正在停止智能食品柜系统...")
        self.is_running = False
        
        # 清理资源
        self.cleanup_resources()
        
        logger.info("智能食品柜系统已停止")
    
    def run(self):
        """
        运行主程序主循环
        """
        if not self.start():
            logger.error("系统启动失败")
            return
        
        try:
            # 主循环：等待用户输入或系统信号
            while self.is_running:
                try:
                    # 检查线程状态
                    if self.websocket_server_task and not self.websocket_server_task.is_alive():
                        logger.error("WebSocket服务器线程异常退出")
                        break
                    
                    if self.outbound_thread and not self.outbound_thread.is_alive():
                        logger.error("出库监控线程异常退出")
                        break
                    
                    # 等待用户输入（非阻塞）
                    import select
                    import sys
                    
                    if sys.stdin in select.select([sys.stdin], [], [], 0.1)[0]:
                        user_input = input().strip().lower()
                        
                        if user_input == 'quit':
                            logger.info("用户输入 'quit'，开始退出...")
                            break
                        elif user_input == 'status':
                            self.print_status()
                        elif user_input == 'help':
                            self.print_help()
                        else:
                            logger.info(f"未知命令: {user_input}，输入 'help' 查看帮助")
                    
                except KeyboardInterrupt:
                    logger.info("收到键盘中断信号")
                    break
                except Exception as e:
                    logger.error(f"主循环异常: {e}")
                    break
        
        finally:
            self.stop()
    
    def print_status(self):
        """
        打印系统状态
        """
        logger.info("=" * 40)
        logger.info("系统状态:")
        logger.info(f"  运行状态: {'运行中' if self.is_running else '已停止'}")
        logger.info(f"  WebSocket和HTTP服务器: {'运行中' if self.websocket_server_task and self.websocket_server_task.is_alive() else '已停止'}")
        logger.info(f"  出库监控: {'运行中' if self.outbound_thread and self.outbound_thread.is_alive() else '已停止'}")
        logger.info(f"  数据库路径: {DATABASE_PATH}")
        logger.info(f"  全局数据: {len(db_data_list)} 项")
        logger.info("=" * 40)
    
    def print_help(self):
        """
        打印帮助信息
        """
        logger.info("=" * 40)
        logger.info("可用命令:")
        logger.info("  quit    - 退出程序")
        logger.info("  status  - 显示系统状态")
        logger.info("  help    - 显示此帮助信息")
        logger.info("=" * 40)


def main():
    """
    主函数入口
    """
    # 配置日志系统
    setup_logging_if_needed()
    
    # 创建并运行主程序
    app = SmartFoodCabinetMain()
    app.run()


if __name__ == "__main__":
    main()
